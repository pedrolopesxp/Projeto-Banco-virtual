<?php
// www/index.php

// Inicia a sessão PHP
session_start();

// Inclui o arquivo de conexão com o banco de dados
require_once __DIR__ . '/inc/db_connection.php';

// Inclui funções utilitárias
require_once __DIR__ . '/inc/functions.php';

// Lógica para verificar se o usuário está logado
$loggedIn = false;
$userName = '';
if (isset($_SESSION['user_id'])) {
    $loggedIn = true;
    try {
        $stmt = $pdo->prepare("SELECT nm_usuario FROM tb_usuario WHERE id_usuario = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
        if ($user) {
            $userName = htmlspecialchars($user['nm_usuario']);
        }
    } catch (PDOException $e) {
        // Loga o erro, mas não exibe para o usuário em produção
        error_log("Erro ao buscar nome do usuário: " . $e->getMessage());
        set_message("Erro ao carregar suas informações. Tente novamente.", "error");
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bank Lopes - Seu Banco Digital de Criptomoedas</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Bank Lopes</div>
            <nav>
                <ul>
                    <li><a href="index.php">Início</a></li>
                    <li><a href="#funcionalidades">Funcionalidades</a></li>
                    <li><a href="#sobre">Sobre Nós</a></li>
                    <?php if ($loggedIn): ?>
                        <li>Olá, <?= $userName ?></li>
                        <li><a href="pages/dashboard.php" class="button primary">Dashboard</a></li>
                        <li><a href="pages/logout.php" class="button secondary">Sair</a></li>
                    <?php else: ?>
                        <li><a href="pages/login.php" class="button primary">Login</a></li>
                        <li><a href="pages/register.php" class="button secondary">Abrir Conta</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="hero">
            <div class="container">
                <h1>Bank Lopes: Sua Liberdade Financeira Digital</h1>
                <p>Gerencie seus Bitcoins, faça PIX e use cartões de forma simples e segura. Tudo em um só lugar.</p>
                <?php if (!$loggedIn): ?>
                    <a href="pages/register.php" class="button hero-button">Crie sua conta agora!</a>
                <?php endif; ?>
                <?php display_messages(); ?>
            </div>
        </section>

        <section id="funcionalidades" class="features">
            <div class="container">
                <h2>O que oferecemos?</h2>
                <div class="feature-grid">
                    <div class="feature-item">
                        <!-- Imagem de ícone Bitcoin (placeholder) -->
                        <h3><img src="https://placehold.co/40x40/4CAF50/FFFFFF?text=BTC" alt="Ícone Bitcoin"> Carteira Bitcoin Integrada</h3>
                        <p>Envie e receba Bitcoins para qualquer endereço, visualize seu saldo e histórico de transações.</p>
                    </div>
                    <div class="feature-item">
                        <!-- Imagem de ícone PIX (placeholder) -->
                        <h3><img src="https://placehold.co/40x40/4CAF50/FFFFFF?text=PIX" alt="Ícone PIX"> Pagamentos PIX</h3>
                        <p>Realize e receba pagamentos instantâneos via PIX, 24 horas por dia, 7 dias por semana.</p>
                    </div>
                    <div class="feature-item">
                        <!-- Imagem de ícone Cartão (placeholder) -->
                        <h3><img src="https://placehold.co/40x40/4CAF50/FFFFFF?text=Card" alt="Ícone Cartão"> Cartões Virtuais e Físicos</h3>
                        <p>Crie cartões virtuais para compras online e solicite seu cartão físico para o dia a dia.</p>
                    </div>
                    <div class="feature-item">
                        <!-- Imagem de ícone Segurança (placeholder) -->
                        <h3><img src="https://placehold.co/40x40/4CAF50/FFFFFF?text=Secure" alt="Ícone Segurança"> Segurança de Ponta</h3>
                        <p>Seus dados e suas transações protegidos com as mais avançadas tecnologias de segurança.</p>
                    </div>
                </div>
            </div>
        </section>

        <section id="sobre" class="about">
            <div class="container">
                <h2>Sobre o Bank Lopes</h2>
                <p>Nossa missão é democratizar o acesso ao universo das criptomoedas e facilitar as transações financeiras digitais para todos. O Bank Lopes é um banco virtual inovador, que une a praticidade das transações tradicionais com a segurança e o potencial do Bitcoin.</p>
                <p>Com uma plataforma intuitiva e robusta, você tem controle total sobre suas finanças, seja para gerenciar seu saldo em reais ou para explorar o mundo das criptomoedas. Nosso suporte está sempre disponível para te ajudar em cada passo.</p>
            </div>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="pages/admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>
</body>
</html>
