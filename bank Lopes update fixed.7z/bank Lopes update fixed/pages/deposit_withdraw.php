<?php
// www/pages/deposit_withdraw.php

session_start();
// ATIVAR EXIBIÇÃO DE ERROS PARA DEBUGGING (REMOVER EM PRODUÇÃO!)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php'; // Garante que functions.php seja carregado

// Verifica se o usuário está logado.
if (!isset($_SESSION['user_id'])) {
    set_message("Você precisa estar logado para depositar ou sacar.", "error");
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$userName = htmlspecialchars($_SESSION['user_name'] ?? 'Usuário');

$current_real_balance = 0;
$current_bitcoin_balance = 0;
$user_pix_keys = []; // Inicializa array para chaves PIX do usuário

try {
    $stmt_balance = $pdo->prepare("SELECT vl_saldo_bitcoin, vl_saldo_real FROM tb_conta WHERE id_usuario = ?");
    $stmt_balance->execute([$user_id]);
    $account_data = $stmt_balance->fetch(PDO::FETCH_ASSOC);
    if ($account_data) {
        $current_bitcoin_balance = $account_data['vl_saldo_bitcoin'];
        $current_real_balance = $account_data['vl_saldo_real'];
    }

    // Busca as chaves PIX do usuário (ainda útil para depósitos, ou se a opção "minha chave" for reintroduzida)
    $stmt_pix_keys = $pdo->prepare("SELECT id_informacao, ch_chave_pix, tp_tipo_chave, ds_rotulo FROM tb_informacao_pix WHERE id_informacao = ? ORDER BY dt_criacao DESC");
    $stmt_pix_keys->execute([$user_id]);
    $user_pix_keys = $stmt_pix_keys->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log("Erro ao buscar saldos e chaves PIX para depósito/saque: " . $e->getMessage());
    set_message("Erro ao carregar seus saldos e chaves PIX. Por favor, tente novamente.", "error");
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = trim(isset($_POST['action']) ? $_POST['action'] : ''); // 'deposit' ou 'withdraw'
    $currency = trim(isset($_POST['currency']) ? $_POST['currency'] : ''); // 'BRL' ou 'BTC'
    $amount = floatval(str_replace(',', '.', trim(isset($_POST['amount']) ? $_POST['amount'] : '0')));
    $method = trim(isset($_POST['method']) ? $_POST['method'] : ''); // 'PIX', 'TED', 'Bitcoin', etc.

    // Campos adicionais para métodos específicos
    $deposit_user_pix_key_id = filter_input(INPUT_POST, 'deposit_user_pix_key_id', FILTER_VALIDATE_INT); // Para depósito via PIX (chave do usuário usada para enviar)

    // Campos para saque PIX para outra pessoa (agora sempre esperados para saque PIX)
    $recipient_pix_key_type = trim(isset($_POST['recipient_pix_key_type']) ? $_POST['recipient_pix_key_type'] : '');
    $recipient_pix_key_value = trim(isset($_POST['recipient_pix_key_value']) ? $_POST['recipient_pix_key_value'] : '');
    $recipient_name = trim(isset($_POST['recipient_name']) ? $_POST['recipient_name'] : '');


    $bank_name = trim(isset($_POST['bank_name']) ? $_POST['bank_name'] : '');
    $agency_number = trim(isset($_POST['agency_number']) ? $_POST['agency_number'] : '');
    $account_number = trim(isset($_POST['account_number']) ? $_POST['account_number'] : '');
    $account_type = trim(isset($_POST['account_type']) ? $_POST['account_type'] : '');
    $holder_name = trim(isset($_POST['holder_name']) ? $_POST['holder_name'] : '');
    $holder_cpf_cnpj = trim(isset($_POST['holder_cpf_cnpj']) ? $_POST['holder_cpf_cnpj'] : '');
    $bitcoin_address = trim(isset($_POST['bitcoin_address']) ? $_POST['bitcoin_address'] : '');


    if ($amount <= 0) {
        set_message("A quantidade deve ser maior que zero.", "error");
    } elseif (empty($action) || empty($currency) || empty($method)) {
        set_message("Por favor, preencha todos os campos obrigatórios.", "error");
    } else {
        // Validação adicional para campos específicos do método
        $method_details = ''; // Para armazenar detalhes para a descrição da transação

        if ($method === 'PIX') {
            if ($action === 'withdraw') { // Para saque PIX, agora sempre para outra pessoa
                if (empty($recipient_pix_key_type) || empty($recipient_pix_key_value) || empty($recipient_name)) {
                    set_message("Por favor, preencha todos os dados da chave PIX do destinatário.", "error");
                } else {
                    $method_details = "Saque para " . htmlspecialchars($recipient_name) . " via PIX. Tipo da Chave: " . htmlspecialchars($recipient_pix_key_type) . ", Chave: " . htmlspecialchars($recipient_pix_key_value);
                }
            } else { // $action === 'deposit' via PIX
                $selected_deposit_pix_key_info = '';
                if (!empty($deposit_user_pix_key_id)) {
                    // Busca os detalhes da chave PIX do usuário que ele informou ter usado para enviar
                    $stmt_deposit_pix_key = $pdo->prepare("SELECT ch_chave_pix, tp_tipo_chave, ds_rotulo FROM tb_informacao_pix WHERE id_informacao = ? AND id_usuario = ?");
                    $stmt_deposit_pix_key->execute([$deposit_user_pix_key_id, $user_id]);
                    $deposit_pix_key_data = $stmt_deposit_pix_key->fetch(PDO::FETCH_ASSOC);
                    if ($deposit_pix_key_data) {
                        $rotulo_display = !empty($deposit_pix_key_data['ds_rotulo']) ? " (" . htmlspecialchars($deposit_pix_key_data['ds_rotulo']) . ")" : "";
                        $selected_deposit_pix_key_info = " (Sua chave usada: " . htmlspecialchars($deposit_pix_key_data['ch_chave_pix']) . " - " . htmlspecialchars($deposit_pix_key_data['tp_tipo_chave']) . $rotulo_display . ")";
                    }
                }
                $method_details = "Depósito via PIX para o banco (Chave Aleatória Simulada)" . $selected_deposit_pix_key_info;
            }
        } elseif ($method === 'TED') {
            if (empty($bank_name) || empty($agency_number) || empty($account_number) || empty($account_type) || empty($holder_name) || empty($holder_cpf_cnpj)) {
                set_message("Por favor, preencha todos os dados bancários para TED.", "error");
            } else {
                $method_details = "TED para " . htmlspecialchars($holder_name) . " (CPF/CNPJ: " . htmlspecialchars($holder_cpf_cnpj) . ") Banco: " . htmlspecialchars($bank_name) . ", Ag: " . htmlspecialchars($agency_number) . ", Cc: " . htmlspecialchars($account_number) . " (" . htmlspecialchars($account_type) . ")";
            }
        } elseif ($method === 'Transferência Bitcoin') {
            if ($action === 'withdraw') { // Para saque, o usuário precisa fornecer o endereço
                if (empty($bitcoin_address)) {
                    set_message("Por favor, informe o endereço Bitcoin de destino para o saque.", "error");
                } else {
                    $method_details = "Endereço BTC para saque: " . htmlspecialchars($bitcoin_address);
                }
            } else { // Para depósito, o endereço é simulado como fornecido pelo sistema
                $method_details = "Endereço BTC para depósito: " . htmlspecialchars($bitcoin_address); // Irá capturar o valor do campo hidden
            }
        }

        // Se houver erros de validação de método, não prosseguir
        if (!empty(get_message('error'))) {
            // Re-busca os saldos para que a página exiba os valores corretos após o erro
            try {
                $stmt_balance = $pdo->prepare("SELECT vl_saldo_bitcoin, vl_saldo_real FROM tb_conta WHERE id_usuario = ?");
                $stmt_balance->execute([$user_id]);
                $account_data = $stmt_balance->fetch(PDO::FETCH_ASSOC);
                if ($account_data) {
                    $current_bitcoin_balance = $account_data['vl_saldo_bitcoin'];
                    $current_real_balance = $account_data['vl_saldo_real'];
                }
            } catch (PDOException $e) {
                error_log("Erro ao re-buscar saldos após erro de validação: " . $e->getMessage());
            }
            // Não fazer redirect aqui para que a mensagem de erro seja exibida na página atual.
            // A execução continuará para renderizar o HTML.
        } else { // Somente prossegue com a transação se não houver mensagens de erro prévias
            try {
                $pdo->beginTransaction();

                $status = 'Pendente'; // Status inicial para a maioria das operações
                $transaction_type = '';
                $message_text = ''; // Renomeado para evitar conflito com a função set_message
                $taxa = 0; // Por padrão, taxa zero, buscaria de tb_taxa em um sistema real

                if ($action === 'deposit') {
                    $transaction_type = 'Depósito';
                    if ($currency === 'BRL') {
                        $new_balance = $current_real_balance + $amount;
                        $stmt_update_balance = $pdo->prepare("UPDATE tb_conta SET vl_saldo_real = ? WHERE id_usuario = ?");
                        $stmt_update_balance->execute([$new_balance, $user_id]);
                        $message_text = "Depósito de R$ " . number_format($amount, 2, ',', '.') . " realizado com sucesso via " . htmlspecialchars($method) . ". " . $method_details;
                        $status = 'Concluída'; // Depósito em Reais pode ser instantâneo dependendo do método
                    } elseif ($currency === 'BTC') {
                        $new_balance = $current_bitcoin_balance + $amount;
                        $stmt_update_balance = $pdo->prepare("UPDATE tb_conta SET vl_saldo_bitcoin = ? WHERE id_usuario = ?");
                        $stmt_update_balance->execute([$new_balance, $user_id]);
                        $message_text = "Depósito de " . number_format($amount, 8, ',', '.') . " BTC realizado com sucesso. " . $method_details;
                        $status = 'Concluída'; // Simulado como concluído
                    }
                } elseif ($action === 'withdraw') {
                    $transaction_type = 'Saque';
                    if ($currency === 'BRL') {
                        if ($amount > $current_real_balance) {
                            set_message("Saldo em Reais insuficiente para saque.", "error");
                            $pdo->rollBack();
                        } else {
                            $new_balance = $current_real_balance - $amount;
                            $stmt_update_balance = $pdo->prepare("UPDATE tb_conta SET vl_saldo_real = ? WHERE id_usuario = ?");
                            $stmt_update_balance->execute([$new_balance, $user_id]);
                            $message_text = "Solicitação de saque de R$ " . number_format($amount, 2, ',', '.') . " via " . htmlspecialchars($method) . " enviada. Aguardando processamento. " . $method_details;
                            $status = 'Pendente'; // Saque geralmente é pendente
                        }
                    } elseif ($currency === 'BTC') {
                        if ($amount > $current_bitcoin_balance) {
                            set_message("Saldo em Bitcoin insuficiente para saque.", "error");
                            $pdo->rollBack();
                        } else {
                            $new_balance = $current_bitcoin_balance - $amount;
                            $stmt_update_balance = $pdo->prepare("UPDATE tb_conta SET vl_saldo_bitcoin = ? WHERE id_usuario = ?");
                            $stmt_update_balance->execute([$new_balance, $user_id]);
                            $message_text = "Solicitação de saque de " . number_format($amount, 8, ',', '.') . " BTC enviada. Aguardando processamento. " . $method_details;
                            $status = 'Pendente'; // Saque BTC geralmente é pendente
                        }
                    }
                }

                // Se não houver erro de saldo (ou outros erros de validação antes do commit), registra a transação e commita
                if (empty(get_message('error'))) { // Verifica se set_message('error') foi chamado
                    $stmt_log_transaction = $pdo->prepare("
                        INSERT INTO tb_transacao (tp_tipo, tp_metodo_pagamento, id_remetente, vl_quantidade_real, vl_quantidade_bitcoin, vl_taxa, ds_status, dt_transacao, ds_descricao)
                        VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), ?)
                    ");
                    $stmt_log_transaction->execute([
                        $transaction_type,
                        $method,
                        $user_id,
                        ($currency === 'BRL' ? $amount : 0),
                        ($currency === 'BTC' ? $amount : 0),
                        $taxa,
                        $status,
                        $method_details
                    ]);
                    set_message($message_text, "success"); // Usa a variável renomeada
                    $pdo->commit();

                    header("Location: " . get_base_url() . "/pages/dashboard.php");
                    exit();
                } else {
                    $pdo->rollBack();
                }

            } catch (PDOException $e) {
                $pdo->rollBack();
                error_log("Erro PDO na operação de depósito/saque: " . $e->getMessage());
                set_message("Ocorreu um erro na sua solicitação: " . $e->getMessage(), "error");
            }
        }
    }
    // Após o POST, busca novamente os saldos para exibir no formulário caso haja um erro e a página recarregue
    // Isso já está feito no início do script para o carregamento inicial, mas podemos garantir que é feito após qualquer POST.
    try {
        $stmt_balance = $pdo->prepare("SELECT vl_saldo_bitcoin, vl_saldo_real FROM tb_conta WHERE id_usuario = ?");
        $stmt_balance->execute([$user_id]);
        $account_data = $stmt_balance->fetch(PDO::FETCH_ASSOC);
        if ($account_data) {
            $current_bitcoin_balance = $account_data['vl_saldo_bitcoin'];
            $current_real_balance = $account_data['vl_saldo_real'];
        }
    } catch (PDOException $e) {
        error_log("Erro ao re-buscar saldos após POST: " . $e->getMessage());
    }
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Depositar/Sacar - Bank Lopes</title>
    <!-- Inclui Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        /* Estilos base ajustados para o Tailwind */
        body {
            font-family: 'Inter', sans-serif;
            @apply bg-gray-50 text-gray-800; /* Cores de fundo e texto mais suaves */
        }
        .container {
            @apply max-w-6xl mx-auto px-4 py-6;
        }

        /* Header (Mantido do style.css ou ajustado com Tailwind) */
        header {
            @apply bg-green-600 text-white shadow-md py-4; /* Verde mais escuro, sombra sutil */
        }
        header .container {
            @apply flex justify-between items-center;
        }
        .logo {
            @apply text-2xl font-bold;
        }
        nav ul {
            @apply flex space-x-6;
        }
        nav ul li a {
            @apply text-white hover:text-green-200 transition duration-300;
        }
        .button.secondary {
            @apply bg-white text-green-600 px-4 py-2 rounded-lg font-semibold hover:bg-gray-100 transition duration-300;
        }

        /* Seção principal do formulário */
        .form-container {
            @apply bg-white p-8 rounded-xl shadow-lg max-w-2xl mx-auto my-10 lg:max-w-4xl; /* Fundo branco, cantos arredondados, sombra maior. Aumentado para lg:max-w-4xl */
        }
        .form-container h2 {
            @apply text-3xl font-bold text-center mb-6 text-green-700;
        }

        /* Saldo atual */
        .current-balances {
            @apply bg-green-50 p-5 rounded-lg mb-6 text-center text-lg font-medium text-green-800 border border-green-200;
        }
        .current-balances strong {
            @apply text-green-700 font-bold;
        }

        /* Botões de abas */
        .tab-buttons {
            @apply flex justify-center gap-4 mb-8;
        }
        .tab-buttons .button {
            @apply px-6 py-3 rounded-lg font-semibold text-lg transition duration-300 ease-in-out;
            @apply bg-gray-100 text-green-700 border border-gray-200 hover:bg-gray-200;
        }
        .tab-buttons .button.active {
            @apply bg-green-600 text-white shadow-md border-green-600;
        }

        /* Seções do formulário (depósito/saque) */
        .form-section {
            @apply hidden border border-gray-200 p-6 rounded-lg bg-gray-50;
        }
        .form-section.active {
            @apply block;
        }
        .form-section h3 {
            @apply text-2xl font-semibold text-green-700 mb-5;
        }

        /* Campos de formulário */
        .deposit-withdraw-form-grid {
            @apply grid grid-cols-1 md:grid-cols-2 gap-6;
        }
        label {
            @apply block text-sm font-medium text-gray-700 mb-1;
        }
        input[type="text"],
        input[type="number"],
        input[type="email"],
        input[type="tel"],
        select {
            @apply w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition duration-200;
        }
        .button.primary {
            @apply bg-green-600 text-white px-6 py-3 rounded-lg font-semibold text-lg hover:bg-green-700 transition duration-300 w-full mt-6 shadow-md;
        }

        /* Detalhes do método (PIX, TED, Bitcoin) */
        .method-details {
            @apply mt-6 p-6 border border-blue-200 bg-blue-50 rounded-lg shadow-inner;
            display: none; /* Inicia oculto */
        }
        .method-details h4 {
            @apply text-xl font-semibold text-blue-800 mb-4;
        }
        .method-details p {
            @apply text-gray-700 mb-3;
        }
        .method-details strong {
            @apply text-blue-700;
        }
        .method-details button {
            @apply bg-blue-600 text-white px-4 py-2 rounded-md font-medium hover:bg-blue-700 transition duration-200 ml-2;
        }
        .method-details small {
            @apply block text-sm text-gray-500 mt-2;
        }

        /* Mensagens de alerta */
        .alert {
            @apply p-4 rounded-lg text-sm font-medium mb-4;
        }
        .alert.error {
            @apply bg-red-100 text-red-700 border border-red-200;
        }
        .alert.success {
            @apply bg-green-100 text-green-700 border border-green-200;
        }
        .alert.info {
            @apply bg-blue-100 text-blue-700 border border-blue-200;
        }

        /* Footer */
        footer {
            @apply text-center py-6 text-gray-500 text-sm;
        }
        footer a {
            @apply text-green-600 hover:underline;
        }

        /* Modal (Estilos Tailwind) */
        .modal {
            @apply fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50;
        }
        .modal-content {
            @apply bg-white p-8 rounded-lg shadow-xl text-center max-w-sm w-full;
        }
        .modal-content h3 {
            @apply text-xl font-bold text-gray-800 mb-5;
        }
        .modal-buttons {
            @apply flex justify-center gap-4;
        }
        .modal-buttons .button {
            @apply px-5 py-2 rounded-lg font-semibold transition duration-200;
        }
        .modal-buttons .button.confirm {
            @apply bg-red-500 text-white hover:bg-red-600;
        }
        .modal-buttons .button.cancel {
            @apply bg-gray-300 text-gray-800 hover:bg-gray-400;
        }

        /* Ajustes responsivos */
        @media (max-width: 768px) {
            nav ul {
                @apply flex-col space-x-0 space-y-2;
            }
            header .container {
                @apply flex-col text-center;
            }
            .tab-buttons .button {
                @apply w-full;
            }
            .deposit-withdraw-form-grid {
                @apply grid-cols-1;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Bank Lopes</div>
            <nav>
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li>Olá, <?= $userName ?></li>
                    <li><a href="logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="form-container">
            <h2>Depositar / Sacar</h2>
            <?php display_messages(); ?>

            <div class="current-balances">
                <p>Saldo em Reais: <strong>R$ <?= htmlspecialchars(number_format($current_real_balance, 2, ',', '.')) ?></strong></p>
                <p>Saldo em Bitcoin: <strong><?= htmlspecialchars(number_format($current_bitcoin_balance, 8, ',', '.')) ?> BTC</strong></p>
            </div>

            <div class="tab-buttons">
                <button type="button" class="button active" onclick="showSection('deposit-form', this)">Depositar</button>
                <button type="button" class="button" onclick="showSection('withdraw-form', this)">Sacar</button>
            </div>

            <!-- Formulário de Depósito -->
            <div id="deposit-form" class="form-section active">
                <h3>Novo Depósito</h3>
                <form action="deposit_withdraw.php" method="POST">
                    <input type="hidden" name="action" value="deposit">
                    <div class="deposit-withdraw-form-grid">
                        <div>
                            <label for="deposit_currency">Moeda:</label>
                            <select id="deposit_currency" name="currency" required onchange="updateDepositMethods(this.value)">
                                <option value="">Selecione a Moeda</option>
                                <option value="BRL">Reais (BRL)</option>
                                <option value="BTC">Bitcoin (BTC)</option>
                            </select>
                        </div>
                        <div>
                            <label for="deposit_amount">Quantidade:</label>
                            <input type="number" step="0.01" id="deposit_amount" name="amount" placeholder="Valor a depositar" required min="0.01">
                        </div>
                        <div>
                            <label for="deposit_method">Método de Depósito:</label>
                            <select id="deposit_method" name="method" required onchange="showMethodDetails('deposit')">
                                <option value="">Selecione o Método</option>
                                <!-- Opções serão carregadas por JS -->
                            </select>
                        </div>
                    </div>

                    <!-- Detalhes do Método de Depósito (dinâmicos) -->
                    <div id="deposit_method_details" class="method-details">
                        <!-- Conteúdo será injetado por JavaScript -->
                    </div>

                    <button type="submit" class="button primary">Confirmar Depósito</button>
                </form>
            </div>

            <!-- Formulário de Saque -->
            <div id="withdraw-form" class="form-section">
                <h3>Novo Saque</h3>
                <form action="deposit_withdraw.php" method="POST">
                    <input type="hidden" name="action" value="withdraw">
                    <div class="deposit-withdraw-form-grid">
                        <div>
                            <label for="withdraw_currency">Moeda:</label>
                            <select id="withdraw_currency" name="currency" required onchange="updateWithdrawMethods(this.value)">
                                <option value="">Selecione a Moeda</option>
                                <option value="BRL">Reais (BRL)</option>
                                <option value="BTC">Bitcoin (BTC)</option>
                            </select>
                        </div>
                        <div>
                            <label for="withdraw_amount">Quantidade:</label>
                            <input type="number" step="0.01" id="withdraw_amount" name="amount" placeholder="Valor a sacar" required min="0.01">
                        </div>
                        <div>
                            <label for="withdraw_method">Método de Saque:</label>
                            <select id="withdraw_method" name="method" required onchange="showMethodDetails('withdraw')">
                                <option value="">Selecione o Método</option>
                                <!-- Opções serão carregadas por JS -->
                            </select>
                        </div>
                    </div>

                    <!-- Detalhes do Método de Saque (dinâmicos) -->
                    <div id="withdraw_method_details" class="method-details">
                        <!-- Conteúdo será injetado por JavaScript -->
                    </div>

                    <button type="submit" class="button primary">Confirmar Saque</button>
                </form>
            </div>

            <p class="text-center mt-8"><a href="dashboard.php" class="text-green-600 hover:underline">Voltar para o Dashboard</a></p>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>

    <!-- Custom Modal for Confirmations and Notifications -->
    <div id="customModal" class="modal" style="display: none;">
        <div class="modal-content">
            <h3 id="modalMessage"></h3>
            <div class="modal-buttons">
                <button class="button confirm" id="modalConfirmBtn">Confirmar</button>
                <button class="button cancel" id="modalCancelBtn">Cancelar</button>
            </div>
        </div>
    </div>

    <script>
        // Variável global para armazenar as chaves PIX do usuário, populada via PHP
        const userPixKeys = <?= json_encode($user_pix_keys); ?>; // Esta variável ainda pode ser útil para outras partes, mas não para o saque PIX direto agora.

        document.addEventListener('DOMContentLoaded', function() {
            // Inicializa as opções de método ao carregar a página
            updateDepositMethods(document.getElementById('deposit_currency').value);
            updateWithdrawMethods(document.getElementById('withdraw_currency').value);

            // Garante que a seção ativa é mostrada no carregamento
            showSection(document.querySelector('.form-section.active').id, document.querySelector('.tab-buttons .button.active'));
        });

        // --- Funções do Modal Customizado ---
        let currentModalCallback = null;

        function showNotification(message, type = 'info') {
            const modal = document.getElementById('customModal');
            const modalMessage = document.getElementById('modalMessage');
            const modalConfirmBtn = document.getElementById('modalConfirmBtn');
            const modalCancelBtn = document.getElementById('modalCancelBtn');

            modalMessage.textContent = message;
            modalConfirmBtn.style.display = 'none'; // Esconde o botão de confirmação para notificação simples
            modalCancelBtn.textContent = 'OK'; // Muda o texto para OK
            modalCancelBtn.onclick = hideModal; // Fecha o modal ao clicar em OK
            
            currentModalCallback = null; // Limpa o callback
            modal.style.display = 'flex';
        }

        function showModal(message, confirmCallback) {
            const modal = document.getElementById('customModal');
            const modalMessage = document.getElementById('modalMessage');
            const modalConfirmBtn = document.getElementById('modalConfirmBtn');
            const modalCancelBtn = document.getElementById('modalCancelBtn');

            modalMessage.textContent = message;
            currentModalCallback = confirmCallback;

            modalConfirmBtn.style.display = 'inline-block'; // Mostra o botão de confirmação para confirmação real
            modalCancelBtn.textContent = 'Cancelar'; // Restaura o texto do botão de cancelar
            
            modalConfirmBtn.onclick = function() {
                hideModal();
                if (currentModalCallback) {
                    currentModalCallback(true);
                }
            };

            modalCancelBtn.onclick = function() {
                hideModal();
                if (currentModalCallback) {
                    currentModalCallback(false);
                }
            };

            modal.style.display = 'flex'; // Exibe o modal
        }

        function hideModal() {
            const modal = document.getElementById('customModal');
            modal.style.display = 'none'; // Oculta o modal
            currentModalCallback = null; // Limpa o callback
        }
        // --- Fim das Funções do Modal Customizado ---

        function showSection(sectionId, clickedButton) {
            // Esconde todas as seções de formulário
            document.querySelectorAll('.form-section').forEach(section => {
                section.classList.remove('active');
            });
            // Remove a classe 'active' de todos os botões de tab
            document.querySelectorAll('.tab-buttons .button').forEach(button => {
                button.classList.remove('active');
            });

            // Mostra a seção selecionada
            document.getElementById(sectionId).classList.add('active');

            // Ativa o botão clicado
            if (clickedButton) {
                clickedButton.classList.add('active');
            }

            // Reseta e atualiza os métodos de pagamento quando a seção muda
            if (sectionId === 'deposit-form') {
                document.getElementById('deposit_currency').value = ''; // Reseta a moeda
                updateDepositMethods(''); // Limpa os métodos
                hideMethodDetails('deposit'); // Esconde detalhes
            } else if (sectionId === 'withdraw-form') {
                document.getElementById('withdraw_currency').value = ''; // Reseta a moeda
                updateWithdrawMethods(''); // Limpa os métodos
                hideMethodDetails('withdraw'); // Esconde detalhes
            }
        }

        // Mapeamento de métodos por moeda
        const methods = {
            'BRL_deposit': [
                { value: 'PIX', text: 'PIX' },
                { value: 'TED', text: 'TED/DOC' }
            ],
            'BRL_withdraw': [
                { value: 'PIX', text: 'PIX' },
                { value: 'TED', text: 'TED/DOC' }
            ],
            'BTC_deposit': [
                { value: 'Transferência Bitcoin', text: 'Transferência Bitcoin' }
            ],
            'BTC_withdraw': [
                { value: 'Transferência Bitcoin', text: 'Transferência Bitcoin' }
            ]
        };

        function updateDepositMethods(currency) {
            const selectMethod = document.getElementById('deposit_method');
            selectMethod.innerHTML = '<option value="">Selecione o Método</option>'; // Limpa as opções

            const availableMethods = methods[`${currency}_deposit`];
            if (availableMethods) {
                availableMethods.forEach(method => {
                    const option = document.createElement('option');
                    option.value = method.value;
                    option.textContent = method.text;
                    selectMethod.appendChild(option);
                });
            }
            showMethodDetails('deposit'); // Atualiza os detalhes do método após carregar as opções
        }

        function updateWithdrawMethods(currency) {
            const selectMethod = document.getElementById('withdraw_method');
            selectMethod.innerHTML = '<option value="">Selecione o Método</option>'; // Limpa as opções

            const availableMethods = methods[`${currency}_withdraw`];
            if (availableMethods) {
                availableMethods.forEach(method => {
                    const option = document.createElement('option');
                    option.value = method.value;
                    option.textContent = method.text;
                    selectMethod.appendChild(option);
                });
            }
            showMethodDetails('withdraw'); // Atualiza os detalhes do método após carregar as opções
        }

        function showMethodDetails(formType) {
            const methodDetailsDiv = document.getElementById(`${formType}_method_details`);
            const selectedMethod = document.getElementById(`${formType}_method`).value;
            methodDetailsDiv.innerHTML = ''; // Limpa o conteúdo anterior
            methodDetailsDiv.style.display = 'none'; // Esconde por padrão

            if (selectedMethod === 'PIX') {
                methodDetailsDiv.style.display = 'block';
                if (formType === 'deposit') {
                    // Chave PIX do Bank Lopes para Depósito (simulada)
                    const bankPixKey = {
                        chave: 'abracadabra-1234-abcd-5678-fedcba098765',
                        tipo: 'Aleatória (Banco Lopes)'
                    };

                    let pixKeyOptions = userPixKeys.map(key => {
                        let displayText = key.ch_chave_pix; // Começa com o valor da chave
                        
                        // Adiciona o rótulo em parênteses, se existir e não for vazio.
                        if (key.ds_rotulo && key.ds_rotulo.trim() !== '') {
                            displayText += ` (${key.ds_rotulo})`;
                        }

                        return `<option value="${key.id_informacao}">${displayText}</option>`;
                    }).join('');

                    methodDetailsDiv.innerHTML = `
                        <div class="mb-4">
                            <h4 class="text-lg font-semibold text-gray-800 mb-2">Informar Chave PIX de Origem (Opcional)</h4>
                            <p class="text-gray-600 mb-3">Selecione qual das suas chaves PIX você utilizará no seu outro banco para fazer este depósito:</p>
                            <label for="deposit_user_pix_key_id" class="block text-sm font-medium text-gray-700 mb-1">Minha Chave PIX (para referência):</label>
                            <select id="deposit_user_pix_key_id" name="deposit_user_pix_key_id" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition duration-200">
                                <option value="">Selecione uma chave (Opcional)</option>
                                ${pixKeyOptions}
                            </select>
                        </div>
                        <div class="bg-blue-100 p-4 rounded-lg border border-blue-200">
                            <h4 class="text-lg font-semibold text-blue-800 mb-2">Chave PIX do Bank Lopes para Depósito</h4>
                            <p class="text-gray-700 mb-3">Por favor, realize a transferência PIX do seu outro banco para a seguinte chave do Bank Lopes:</p>
                            <p class="text-lg mb-2"><strong>Tipo:</strong> <span class="font-normal">${bankPixKey.tipo}</span></p>
                            <p class="text-lg font-bold text-blue-700 break-words mb-3">
                                <span id="bank_pix_key_display">${bankPixKey.chave}</span> 
                                <button type="button" onclick="copyToClipboard('${bankPixKey.chave}')" class="ml-3 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50">Copiar Chave</button>
                            </p>
                            <small class="text-gray-500 block">(Esta é uma chave simulada. Em um sistema real, seria uma chave PIX única do banco para depósito.)</small>
                        </div>
                    `;
                } else if (formType === 'withdraw') {
                    // Saque PIX para outra pessoa (sempre visível agora)
                    methodDetailsDiv.innerHTML = `
                        <div id="other_person_pix_key_section">
                            <h4 class="text-lg font-semibold text-gray-800 mb-4">Dados da Chave PIX do Destinatário</h4>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label for="recipient_pix_key_type" class="block text-sm font-medium text-gray-700 mb-1">Tipo da Chave:</label>
                                    <select id="recipient_pix_key_type" name="recipient_pix_key_type" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition duration-200" required>
                                        <option value="">Selecione o Tipo</option>
                                        <option value="CPF">CPF</option>
                                        <option value="CNPJ">CNPJ</option>
                                        <option value="Email">E-mail</option>
                                        <option value="Telefone">Telefone</option>
                                        <option value="Aleatória">Aleatória</option>
                                    </select>
                                </div>
                                <div>
                                    <label for="recipient_pix_key_value" class="block text-sm font-medium text-gray-700 mb-1">Chave PIX:</label>
                                    <input type="text" id="recipient_pix_key_value" name="recipient_pix_key_value" placeholder="Informe a chave PIX do destinatário" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition duration-200" required>
                                </div>
                            </div>
                            <div class="mt-4">
                                <label for="recipient_name" class="block text-sm font-medium text-gray-700 mb-1">Nome Completo do Destinatário:</label>
                                <input type="text" id="recipient_name" name="recipient_name" placeholder="Nome do titular da conta" class="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500 transition duration-200" required>
                            </div>
                        </div>
                    `;
                }
            } else if (selectedMethod === 'TED') {
                methodDetailsDiv.style.display = 'block';
                methodDetailsDiv.innerHTML = `
                    <h4 class="text-lg font-semibold text-gray-800 mb-4">Dados Bancários para TED/DOC do Destinatário</h4>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label for="bank_name">Nome do Banco:</label>
                            <input type="text" id="bank_name" name="bank_name" placeholder="Ex: Banco do Brasil" required>
                        </div>
                        <div>
                            <label for="agency_number">Número da Agência:</label>
                            <input type="text" id="agency_number" name="agency_number" placeholder="Ex: 1234" required>
                        </div>
                        <div>
                            <label for="account_number">Número da Conta:</label>
                            <input type="text" id="account_number" name="account_number" placeholder="Ex: 56789-0" required>
                        </div>
                        <div>
                            <label for="account_type">Tipo de Conta:</label>
                            <select id="account_type" name="account_type" required>
                                <option value="">Selecione o Tipo</option>
                                <option value="Conta Corrente">Conta Corrente</option>
                                <option value="Conta Poupança">Conta Poupança</option>
                            </select>
                        </div>
                    </div>
                    <div class="mt-4">
                        <label for="holder_name">Nome Completo do Titular:</label>
                        <input type="text" id="holder_name" name="holder_name" placeholder="Nome como aparece no banco" required>
                    </div>
                    <div class="mt-4">
                        <label for="holder_cpf_cnpj">CPF ou CNPJ do Titular:</label>
                        <input type="text" id="holder_cpf_cnpj" name="holder_cpf_cnpj" placeholder="Somente números" required>
                    </div>
                `;
            } else if (selectedMethod === 'Transferência Bitcoin') {
                methodDetailsDiv.style.display = 'block';
                if (formType === 'deposit') {
                    // Endereço Bitcoin do Bank Lopes para Depósito (simulado)
                    const bankBitcoinAddress = 'bc1qsimulatedbankaddressxyz1234567890'; // Simulado
                    methodDetailsDiv.innerHTML = `
                        <div class="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                            <h4 class="text-lg font-semibold text-yellow-800 mb-2">Endereço Bitcoin do Bank Lopes para Depósito</h4>
                            <p class="text-gray-700 mb-3">Por favor, envie seus Bitcoins para o seguinte endereço do Bank Lopes:</p>
                            <p class="text-lg font-bold text-yellow-700 break-words mb-3">
                                <span id="bank_bitcoin_address_display">${bankBitcoinAddress}</span>
                                <button type="button" onclick="copyToClipboard('${bankBitcoinAddress}')" class="ml-3 px-4 py-2 bg-yellow-600 text-white rounded-md hover:bg-yellow-700 transition duration-200 focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:ring-opacity-50">Copiar Endereço</button>
                            </p>
                            <input type="hidden" name="bitcoin_address" value="${bankBitcoinAddress}">
                            <small class="text-gray-500 block">(Este é um endereço simulado. Em um sistema real, seria um endereço único do banco para depósito.)</small>
                        </div>
                    `;
                } else if (formType === 'withdraw') {
                    methodDetailsDiv.innerHTML = `
                        <div class="form-group">
                            <label for="bitcoin_address" class="block text-sm font-medium text-gray-700 mb-1">Endereço Bitcoin de Destino:</label>
                            <input type="text" id="bitcoin_address" name="bitcoin_address" placeholder="Informe o endereço Bitcoin para onde sacar" required>
                        </div>
                    `;
                }
            }
        }

        // Função para copiar texto para a área de transferência
        function copyToClipboard(text) {
            const tempInput = document.createElement('input');
            tempInput.value = text;
            document.body.appendChild(tempInput);
            tempInput.select();
            tempInput.setSelectionRange(0, 99999);
            document.execCommand('copy');
            document.body.removeChild(tempInput);
            showNotification('Copiado para a área de transferência: ' + text, 'success');
        }
    </script>
</body>
</html>
