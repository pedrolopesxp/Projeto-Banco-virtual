<?php
// www/pages/admin_system_settings.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

// Verifica se o administrador está logado. Se não, redireciona para a página de login do admin.
if (!isset($_SESSION['admin_id'])) {
    set_message("Você precisa estar logado como administrador para acessar esta área.", "error");
    redirect('admin_login.php');
}

$admin_name = htmlspecialchars($_SESSION['admin_name'] ?? 'Administrador');
$admin_level = htmlspecialchars($_SESSION['admin_level'] ?? 'Nível Desconhecido');

$settings = [];
try {
    // Buscar todas as configurações do sistema
    $stmt = $pdo->query("SELECT ch_chave, vl_valor, ds_descricao FROM tb_configuracao_sistema ORDER BY ch_chave ASC");
    $settings = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Erro ao buscar configurações do sistema: " . $e->getMessage());
    set_message("Ocorreu um erro ao carregar as configurações do sistema.", "error");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Lógica para salvar as configurações
    // NOTA: Esta é uma implementação básica. Em um sistema real, você validaria cada campo
    // e trataria os tipos de dados (booleanos, números, etc.) adequadamente.
    try {
        $pdo->beginTransaction();
        foreach ($_POST as $key => $value) {
            // Supondo que o name do input no formulário seja o ch_chave
            // e que o valor seja o vl_valor
            // Evitar salvar 'action' e 'id_taxa' se vierem de um formulário de taxas
            if ($key !== 'action' && $key !== 'id_taxa') { // Adicionado esta verificação
                $stmt = $pdo->prepare("INSERT INTO tb_configuracao_sistema (ch_chave, vl_valor) VALUES (?, ?) ON DUPLICATE KEY UPDATE vl_valor = ?, dt_atualizacao = CURRENT_TIMESTAMP");
                $stmt->execute([$key, $value, $value]);
            }
        }
        $pdo->commit();
        set_message("Configurações salvas com sucesso!", "success");
        redirect('admin_system_settings.php');
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("Erro ao salvar configurações: " . $e->getMessage());
        set_message("Ocorreu um erro ao salvar as configurações: " . $e->getMessage(), "error"); // Exibir mensagem para depuração
    }
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurações do Sistema - Admin - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        /* Estilos específicos para esta página */
        .admin-form-container {
            background-color: var(--secondary-color);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
            margin-top: 40px;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }
        .admin-form-container h2 {
            text-align: left;
            margin-bottom: 30px;
            color: var(--primary-dark-color);
            font-size: 2em;
        }
        .settings-form-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 20px;
        }
        .setting-item {
            display: flex;
            flex-direction: column;
            margin-bottom: 15px;
        }
        .setting-item label {
            font-weight: bold;
            color: var(--text-color);
            margin-bottom: 5px;
        }
        .setting-item input[type="text"],
        .setting-item textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-size: 1em;
            box-sizing: border-box;
        }
        .setting-item p.description {
            font-size: 0.9em;
            color: #666;
            margin-top: 5px;
        }
        .admin-form-container button[type="submit"] {
            margin-top: 20px;
            padding: 15px 25px;
            font-size: 1.1em;
            border-radius: 10px;
            background-color: var(--primary-color);
            color: var(--secondary-color);
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
            box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
        }
        .admin-form-container button[type="submit"]:hover {
            background-color: var(--primary-dark-color);
            transform: translateY(-2px);
        }

        @media (min-width: 600px) {
            .settings-form-grid {
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            }
        }
        @media (max-width: 768px) {
            .admin-form-container {
                padding: 20px;
            }
            .admin-form-container h2 {
                font-size: 1.8em;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Bank Lopes</div>
            <nav>
                <ul>
                    <li><a href="admin_dashboard.php">Dashboard Admin</a></li>
                    <li>Olá, Admin <?= $admin_name ?> (Nível: <?= $admin_level ?>)</li>
                    <li><a href="logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="form-container admin-form-container">
            <h2>Configurações do Sistema</h2>
            <?php display_messages(); ?>

            <form action="admin_system_settings.php" method="POST">
                <div class="settings-form-grid">
                    <?php if (!empty($settings)): ?>
                        <?php foreach ($settings as $setting): ?>
                            <div class="setting-item">
                                <label for="<?= htmlspecialchars($setting['ch_chave']) ?>"><?= htmlspecialchars(ucwords(str_replace('_', ' ', $setting['ch_chave']))) ?>:</label>
                                <input type="text" id="<?= htmlspecialchars($setting['ch_chave']) ?>" name="<?= htmlspecialchars($setting['ch_chave']) ?>" value="<?= htmlspecialchars($setting['vl_valor']) ?>">
                                <?php if (!empty($setting['ds_descricao'])): ?>
                                    <p class="description"><?= htmlspecialchars($setting['ds_descricao']) ?></p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>Nenhuma configuração encontrada. Adicione manualmente no banco de dados para que apareçam aqui.</p>
                        <!-- Exemplo de como adicionar algumas configurações iniciais manualmente para teste no Navicat: -->
                        <!-- INSERT INTO tb_configuracao_sistema (ch_chave, vl_valor, ds_descricao) VALUES ('taxa_padrao_pix', '0.01', 'Taxa percentual padrão para transações PIX.'), ('min_saque_brl', '10.00', 'Valor mínimo para saque em Reais.'); -->
                    <?php endif; ?>
                </div>
                <button type="submit">Salvar Configurações</button>
            </form>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>
</body>
</html>
