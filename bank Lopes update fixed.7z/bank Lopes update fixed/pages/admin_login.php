<?php
// www/pages/admin_login.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

// Verifica se o administrador já está logado
if (isset($_SESSION['admin_id'])) {
    // Redireciona para o painel de administração
    set_message("Você já está logado como administrador.", "info");
    redirect('admin_dashboard.php'); // Redireciona para o dashboard admin
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Correção: Usar isset() com operador ternário para compatibilidade com PHP < 7.0
    $email = trim(isset($_POST['email']) ? $_POST['email'] : '');
    $password = trim(isset($_POST['password']) ? $_POST['password'] : '');

    if (empty($email) || empty($password)) {
        set_message("Por favor, preencha todos os campos.", "error");
    } elseif (!is_valid_email($email)) {
        set_message("Formato de e-mail inválido.", "error");
    } else {
        try {
            $stmt = $pdo->prepare("SELECT id_admin, nm_admin, ds_senha_hash, ds_nivel_acesso FROM tb_admin WHERE ds_email = ?");
            $stmt->execute([$email]);
            $admin = $stmt->fetch();

            if ($admin && verify_password($password, $admin['ds_senha_hash'])) {
                $_SESSION['admin_id'] = $admin['id_admin'];
                $_SESSION['admin_name'] = $admin['nm_admin'];
                $_SESSION['admin_level'] = $admin['ds_nivel_acesso'];

                set_message("Login de administrador realizado com sucesso! Bem-vindo(a), " . htmlspecialchars($admin['nm_admin']) . ".", "success");
                redirect('admin_dashboard.php'); // Redireciona para o dashboard admin
            } else {
                set_message("E-mail ou senha de administrador incorretos.", "error");
            }
        } catch (PDOException $e) {
            error_log("Erro no login do admin: " . $e->getMessage());
            set_message("Ocorreu um erro no servidor. Por favor, tente novamente mais tarde.", "error");
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Área Administrativa - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Bank Lopes</div>
            <nav>
                <ul>
                    <li><a href="../index.php">Início</a></li>
                    <li><a href="login.php" class="button primary">Login do Usuário</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="form-container">
            <h2>Login da Área Administrativa</h2>
            <?php display_messages(); ?>
            <form action="admin_login.php" method="POST">
                <input type="email" name="email" placeholder="E-mail do Administrador" required autocomplete="email">
                <input type="password" name="password" placeholder="Senha do Administrador" required autocomplete="current-password">
                <button type="submit" class="button primary">Entrar como Admin</button>
                <p><a href="../index.php">Voltar para a página inicial</a></p>
            </form>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>
</body>
</html>
