<?php
// www/pages/send_bitcoin.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

// Verifica se o usuário está logado.
if (!isset($_SESSION['user_id'])) {
    set_message("Você precisa estar logado para enviar Bitcoin.", "error");
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$userName = htmlspecialchars($_SESSION['user_name'] ?? 'Usuário');

// Lógica para obter o saldo atual do usuário em Bitcoin
$current_bitcoin_balance = 0;
try {
    $stmt_balance = $pdo->prepare("SELECT vl_saldo_bitcoin FROM tb_conta WHERE id_usuario = ?");
    $stmt_balance->execute([$user_id]);
    $account_data = $stmt_balance->fetch(PDO::FETCH_ASSOC);
    if ($account_data) {
        $current_bitcoin_balance = $account_data['vl_saldo_bitcoin'];
    }
} catch (PDOException $e) {
    error_log("Erro ao buscar saldo BTC para envio: " . $e->getMessage());
    set_message("Erro ao carregar seu saldo Bitcoin. Tente novamente.", "error");
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $address = trim(isset($_POST['address']) ? $_POST['address'] : '');
    $amount_btc = floatval(str_replace(',', '.', trim(isset($_POST['amount_btc']) ? $_POST['amount_btc'] : '0')));

    if (empty($address) || $amount_btc <= 0) {
        set_message("Por favor, preencha o endereço e a quantidade de Bitcoin.", "error");
    } elseif ($amount_btc > $current_bitcoin_balance) {
        set_message("Saldo de Bitcoin insuficiente.", "error");
    } else {
        try {
            $pdo->beginTransaction();

            // Simulação de taxa de mineração (apenas para demonstração)
            $mining_fee = 0.00005000; // Exemplo: 5000 satoshis

            if (($amount_btc + $mining_fee) > $current_bitcoin_balance) {
                 set_message("Saldo insuficiente para cobrir o valor e a taxa de mineração.", "error");
                 $pdo->rollBack();
            } else {
                // Atualizar saldo da conta do remetente
                $new_balance = $current_bitcoin_balance - ($amount_btc + $mining_fee);
                $stmt_update_sender = $pdo->prepare("UPDATE tb_conta SET vl_saldo_bitcoin = ? WHERE id_usuario = ?");
                $stmt_update_sender->execute([$new_balance, $user_id]);

                // Registrar transação na tb_transacao
                $stmt_log_transaction = $pdo->prepare("
                    INSERT INTO tb_transacao (tp_tipo, tp_metodo_pagamento, id_remetente, ds_endereco_bitcoin_destino, vl_quantidade_bitcoin, vl_taxa, ds_status)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt_log_transaction->execute([
                    'Transferência',
                    'Bitcoin',
                    $user_id,
                    $address,
                    $amount_btc,
                    $mining_fee,
                    'Concluída' // Em um ambiente real, seria 'Processando' até N confirmações
                ]);
                $transaction_id = $pdo->lastInsertId();

                // Registrar na tb_transacao_bitcoin (simulação de hash de transação)
                $mock_tx_hash = 'TX' . uniqid() . bin2hex(random_bytes(16)); // Hash aleatório
                $stmt_log_btc_transaction = $pdo->prepare("
                    INSERT INTO tb_transacao_bitcoin (id_transacao, ds_hash_transacao, vl_taxa_mineracao, nr_confirmacoes)
                    VALUES (?, ?, ?, ?)
                ");
                $stmt_log_btc_transaction->execute([$transaction_id, $mock_tx_hash, $mining_fee, 0]);


                set_message("Bitcoin enviado com sucesso para " . htmlspecialchars($address) . "!", "success");
                $pdo->commit();
                redirect('dashboard.php'); // Redireciona para o dashboard após sucesso
            }
        } catch (PDOException $e) {
            $pdo->rollBack();
            error_log("Erro ao enviar Bitcoin: " . $e->getMessage());
            set_message("Ocorreu um erro ao enviar Bitcoin: " . $e->getMessage(), "error");
        }
    }
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enviar Bitcoin - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Bank Lopes</div>
            <nav>
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li>Olá, <?= $userName ?></li>
                    <li><a href="logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="form-container">
            <h2>Enviar Bitcoin</h2>
            <?php display_messages(); ?>
            <p>Seu saldo atual: <strong><?= htmlspecialchars(number_format($current_bitcoin_balance, 8, ',', '.')) ?> BTC</strong></p>

            <form action="send_bitcoin.php" method="POST">
                <div class="form-group">
                    <label for="address">Endereço de Destino (Bitcoin):</label>
                    <input type="text" id="address" name="address" placeholder="Ex: 1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa" required>
                </div>
                <div class="form-group">
                    <label for="amount_btc">Quantidade (BTC):</label>
                    <input type="number" step="0.00000001" id="amount_btc" name="amount_btc" placeholder="Ex: 0.00125" required min="0.00000001">
                </div>
                <button type="submit" class="button primary">Enviar Bitcoin</button>
            </form>
            <p><a href="dashboard.php">Voltar para o Dashboard</a></p>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>
</body>
</html>
