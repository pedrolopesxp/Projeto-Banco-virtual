<?php
// www/pages/recover_password.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');

    if (empty($email)) {
        set_message("Por favor, digite seu e-mail.", "error");
    } elseif (!is_valid_email($email)) {
        set_message("Formato de e-mail inválido.", "error");
    } else {
        try {
            $stmt = $pdo->prepare("SELECT id_usuario FROM tb_usuario WHERE ds_email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user) {
                $user_id = $user['id_usuario'];
                $token = generate_token(64); // Gera um token longo e seguro
                $expiration_time = date('Y-m-d H:i:s', strtotime('+1 hour')); // Token válido por 1 hora

                // Inserir o token de recuperação no banco de dados
                $insert_token_stmt = $pdo->prepare("INSERT INTO tb_recuperacao_senha (id_usuario, ds_token, dt_expiracao) VALUES (?, ?, ?)");
                $insert_token_stmt->execute([$user_id, $token, $expiration_time]);

                // Em um sistema real, você enviaria este link por e-mail para o usuário.
                // Exemplo de link de recuperação (assumindo que você teria uma página reset_password.php):
                $reset_link = "http://seu_dominio.com/pages/reset_password.php?token=" . $token;

                set_message("Um link de recuperação de senha foi enviado para o seu e-mail (se cadastrado).", "success");
                // Para demonstração, exiba o link (REMOVER EM PRODUÇÃO):
                set_message("DEMO: Link de recuperação: <a href='#' onclick='alert(\"" . htmlspecialchars($reset_link) . "\")'>Clique aqui para ver o link</a>", "info");

            } else {
                set_message("Seu e-mail não foi encontrado em nosso sistema.", "error");
            }
        } catch (PDOException $e) {
            error_log("Erro na recuperação de senha: " . $e->getMessage());
            set_message("Ocorreu um erro no servidor. Por favor, tente novamente mais tarde.", "error");
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Senha - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Bank Lopes</div>
            <nav>
                <ul>
                    <li><a href="../index.php">Início</a></li>
                    <li><a href="login.php" class="button primary">Login</a></li>
                    <li><a href="register.php" class="button secondary">Abrir Conta</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="form-container">
            <h2>Recuperar Senha</h2>
            <?php display_messages(); ?>
            <form action="recover_password.php" method="POST">
                <p>Digite seu e-mail para recuperar sua senha.</p>
                <input type="email" name="email" placeholder="Seu E-mail" required autocomplete="email">
                <button type="submit" class="button primary">Enviar Link de Recuperação</button>
                <p><a href="login.php">Voltar para o Login</a></p>
            </form>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>
</body>
</html>
