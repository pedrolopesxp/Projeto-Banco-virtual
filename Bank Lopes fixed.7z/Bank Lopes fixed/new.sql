-- Criação do banco de dados (se não existir)
CREATE DATABASE IF NOT EXISTS new;

-- Uso do banco de dados
USE New;

-- Tabela de Administradores
CREATE TABLE IF NOT EXISTS tb_admin (
    id_admin INT AUTO_INCREMENT PRIMARY KEY,
    nm_admin VARCHAR(100) NOT NULL,
    ds_email VARCHAR(100) NOT NULL UNIQUE,
    ds_senha_hash VARCHAR(255) NOT NULL,
    ds_nivel_acesso ENUM('SuperAdmin', 'Financeiro', 'Suporte') DEFAULT 'Suporte',
    dt_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de Usuários
CREATE TABLE IF NOT EXISTS tb_usuario (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nm_usuario VARCHAR(100) NOT NULL,
    ds_email VARCHAR(100) NOT NULL UNIQUE,
    ds_cpf VARCHAR(14) NOT NULL UNIQUE,
    ds_senha_hash VARCHAR(255) NOT NULL,
    dt_nascimento DATE NOT NULL,
    ds_telefone VARCHAR(20),
    ds_endereco TEXT,
    ds_cidade VARCHAR(100) NOT NULL,
    ds_estado VARCHAR(100) NOT NULL,
    ds_pais_origem VARCHAR(100) DEFAULT 'Brasil',
    dt_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    dt_ultimo_acesso TIMESTAMP NULL,
    ds_status ENUM('Ativo', 'Inativo', 'Bloqueado') DEFAULT 'Ativo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de Contas
CREATE TABLE IF NOT EXISTS tb_conta (
    id_conta INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    nr_conta VARCHAR(20) NOT NULL UNIQUE,
    vl_saldo_bitcoin DECIMAL(18,8) DEFAULT 0,
    vl_saldo_real DECIMAL(10,2) DEFAULT 0,
    dt_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de Endereços Bitcoin
CREATE TABLE IF NOT EXISTS tb_endereco_bitcoin (
    id_endereco INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    ds_endereco VARCHAR(255) NOT NULL UNIQUE, -- Ajustado para 255 para acomodar endereços mais longos
    ds_qr_code TEXT, -- Armazenar o QR Code (base64 ou link)
    ds_rotulo VARCHAR(50),
    tp_tipo ENUM('Recebimento', 'Troco', 'Depósito', 'Transferência') NOT NULL,
    -- vl_saldo DECIMAL(18,8) DEFAULT 0, -- Removido, saldo é controlado na tb_conta
    dt_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    dt_ultima_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabela de Transações Gerais
CREATE TABLE IF NOT EXISTS tb_transacao (
    id_transacao INT AUTO_INCREMENT PRIMARY KEY,
    -- ENUM tp_tipo atualizado para incluir 'Estorno PIX'
    tp_tipo ENUM('Depósito', 'Saque', 'Transferência', 'Compra', 'Venda', 'PIX Recebido', 'PIX Enviado', 'TED Recebido', 'TED Enviado', 'Estorno PIX') NOT NULL,
    tp_metodo_pagamento ENUM('PIX', 'Cartão de Crédito', 'Cartão de Débito', 'TED', 'Poupança', 'Bitcoin', 'QR Code', 'Transferência Bitcoin') NOT NULL,
    id_remetente INT, -- Pode ser NULL para depósitos ou saques externos
    id_destinatario INT, -- Pode ser NULL para saques externos
    ds_endereco_bitcoin_origem VARCHAR(100),
    ds_endereco_bitcoin_destino VARCHAR(100),
    vl_quantidade_bitcoin DECIMAL(18,8),
    vl_quantidade_real DECIMAL(10,2),
    vl_taxa DECIMAL(18,8),
    ds_status ENUM('Pendente', 'Concluída', 'Falha', 'Aprovada', 'Recusada', 'Processando', 'Cancelada') DEFAULT 'Pendente',
    dt_transacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    dt_confirmacao TIMESTAMP NULL,
    ds_descricao TEXT NULL, -- COLUNA: Descrição detalhada da transação
    id_transacao_original INT NULL, -- NOVA COLUNA: Referência para a transação original em caso de estorno
    FOREIGN KEY (id_remetente) REFERENCES tb_usuario(id_usuario) ON DELETE SET NULL,
    FOREIGN KEY (id_destinatario) REFERENCES tb_usuario(id_usuario) ON DELETE SET NULL,
    FOREIGN KEY (id_transacao_original) REFERENCES tb_transacao(id_transacao) ON DELETE SET NULL -- Chave estrangeira para o estorno
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de Transações Bitcoin (detalhes específicos de blockchain)
CREATE TABLE IF NOT EXISTS tb_transacao_bitcoin (
    id_transacao_bitcoin INT AUTO_INCREMENT PRIMARY KEY,
    id_transacao INT NOT NULL, -- Link para a transação geral
    ds_hash_transacao VARCHAR(64) NOT NULL UNIQUE,
    nr_confirmacoes INT DEFAULT 0,
    vl_taxa_mineracao DECIMAL(18,8),
    dt_confirmacao TIMESTAMP NULL,
    FOREIGN KEY (id_transacao) REFERENCES tb_transacao(id_transacao) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de Logs de Atividades
CREATE TABLE IF NOT EXISTS tb_log_atividade (
    id_log INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT, -- Pode ser NULL para atividades do sistema
    tp_tipo_atividade VARCHAR(50) NOT NULL,
    ds_descricao TEXT,
    ds_endereco_ip VARCHAR(45),
    dt_atividade TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de Configurações do Sistema
CREATE TABLE IF NOT EXISTS tb_configuracao_sistema (
    id_configuracao INT AUTO_INCREMENT PRIMARY KEY,
    ch_chave VARCHAR(50) NOT NULL UNIQUE,
    vl_valor TEXT,
    ds_descricao TEXT,
    dt_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de Taxas
CREATE TABLE IF NOT EXISTS tb_taxa (
    id_taxa INT AUTO_INCREMENT PRIMARY KEY,
    tp_tipo_operacao VARCHAR(50) NOT NULL, -- Ex: 'Compra BTC', 'Venda BTC', 'Saque BRL', 'PIX'
    vl_percentual DECIMAL(5,2) NOT NULL,
    vl_valor_fixo DECIMAL(10,2) DEFAULT 0.00, -- Adicionado para taxas fixas
    vl_valor_minimo DECIMAL(10,2),
    vl_valor_maximo DECIMAL(10,2),
    dt_inicio DATE NOT NULL,
    dt_fim DATE NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de Limites de Transações
CREATE TABLE IF NOT EXISTS tb_limite_transacao (
    id_limite INT AUTO_INCREMENT PRIMARY KEY,
    tp_tipo_limite VARCHAR(50) NOT NULL, -- Ex: 'Saque Diário BRL', 'Compra Máxima BTC'
    vl_valor_limite DECIMAL(18,8) NOT NULL,
    tp_periodo ENUM('Diário', 'Semanal', 'Mensal', 'Anual', 'Única') NOT NULL,
    hr_inicio TIME NULL,
    hr_fim TIME NULL,
    dt_inicio DATE NOT NULL,
    dt_fim DATE NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de histórico de preços de criptomoedas
CREATE TABLE IF NOT EXISTS tb_historico_preco (
    id_historico INT AUTO_INCREMENT PRIMARY KEY,
    tp_moeda VARCHAR(10) NOT NULL, -- Ex: 'BTC', 'ETH', 'BRL' (para cotação)
    vl_preco DECIMAL(18,8) NOT NULL,
    dt_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de extrato da conta (movimentações do saldo)
CREATE TABLE IF NOT EXISTS tb_extrato_conta (
    id_extrato INT AUTO_INCREMENT PRIMARY KEY,
    id_conta INT NOT NULL,
    tp_tipo_operacao ENUM('Crédito', 'Débito', 'PIX Recebido', 'PIX Enviado', 'TED Recebido', 'TED Enviado', 'Compra', 'Venda', 'Taxa') NOT NULL,
    ds_descricao TEXT,
    vl_valor DECIMAL(18,8) NOT NULL,
    vl_saldo_anterior DECIMAL(18,8) NOT NULL,
    vl_saldo_atual DECIMAL(18,8) NOT NULL,
    dt_operacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_conta) REFERENCES tb_conta(id_conta) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de ordens de trade (para compra/venda de cripto)
CREATE TABLE IF NOT EXISTS tb_ordem_trade (
    id_ordem INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    tp_tipo ENUM('Compra', 'Venda') NOT NULL,
    tp_moeda_base VARCHAR(10) NOT NULL, -- Ex: 'BTC'
    tp_moeda_cotacao VARCHAR(10) NOT NULL, -- Ex: 'BRL'
    vl_quantidade DECIMAL(18,8) NOT NULL,
    vl_preco_limite DECIMAL(18,8) NULL, -- Preço limite para ordens limitadas
    vl_preco_executado DECIMAL(18,8) NULL, -- Preço real da execução
    vl_quantidade_executada DECIMAL(18,8) DEFAULT 0,
    ds_status ENUM('Aberta', 'Executada', 'Cancelada', 'Parcialmente Executada') DEFAULT 'Aberta',
    dt_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    dt_execucao TIMESTAMP NULL,
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de informações de PIX (chaves Pix cadastradas pelo usuário para RECEBER pagamentos)
CREATE TABLE IF NOT EXISTS tb_informacao_pix (
    id_informacao INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    ch_chave_pix VARCHAR(255) NOT NULL UNIQUE,
    tp_tipo_chave ENUM('CPF', 'CNPJ', 'E-mail', 'Telefone', 'Aleatória') NOT NULL,
    ds_rotulo VARCHAR(100) NULL, -- COLUNA ADICIONADA: Rótulo/Nome amigável para a chave PIX
    dt_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    -- Adiciona a coluna 'bo_principal' diretamente aqui
    bo_principal TINYINT(1) NOT NULL DEFAULT 0,
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de informações de cartão (para pagamentos feitos pelo usuário com cartão)
-- AVISO DE SEGURANÇA: NUNCA ARMAZENE O CVV (CÓDIGO DE SEGURANÇA) DE UM CARTÃO.
-- Use um provedor de pagamento PCI-DSS compliant para tokenização.
CREATE TABLE IF NOT EXISTS tb_informacao_cartao (
    id_informacao INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    tp_tipo ENUM('Crédito', 'Débito', 'Virtual') NOT NULL,
    nr_cartao_tokenizado VARCHAR(255) NOT NULL, -- Armazenar token do provedor de pagamento
    nm_titular VARCHAR(100) NOT NULL,
    dt_validade DATE NOT NULL, -- Formato YYYY-MM-DD
    ds_bandeira VARCHAR(50) NOT NULL,
    ds_status ENUM('Ativo', 'Inativo') DEFAULT 'Ativo' NOT NULL, -- COLUNA PARA STATUS DO CARTÃO
    dt_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de informações bancárias (TED e Poupança - para SAQUES ou DEPÓSITOS via TED/DOC)
CREATE TABLE IF NOT EXISTS tb_informacao_bancaria (
    id_informacao INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    tp_tipo_conta ENUM('Corrente', 'Poupança') NOT NULL,
    nm_banco VARCHAR(100) NOT NULL,
    nr_agencia VARCHAR(10) NOT NULL,
    nr_conta VARCHAR(20) NOT NULL,
    nm_titular VARCHAR(100) NOT NULL,
    ds_cpf_cnpj VARCHAR(14) NOT NULL, -- CPF ou CNPJ do titular da conta bancária
    dt_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de limites PIX por usuário (limites personalizados de envio/recebimento)
CREATE TABLE IF NOT EXISTS tb_limite_pix_usuario (
    id_limite INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    vl_limite_diario DECIMAL(10,2) NOT NULL,
    vl_limite_noturno DECIMAL(10,2) NOT NULL,
    dt_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de notificações
CREATE TABLE IF NOT EXISTS tb_notificacao (
    id_notificacao INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    tp_tipo ENUM('Alerta', 'Info', 'Sucesso', 'Erro', 'PIX Enviado', 'PIX Recebido', 'Transação Bitcoin', 'Bitcoin Recebido', 'TED Enviado', 'TED Recebido', 'Cartão Aprovado', 'Cartão Recusado', 'Trade Executado', 'Trade Cancelado', 'Mensagem do Admin') NOT NULL,
    ds_mensagem TEXT NOT NULL,
    bl_lida TINYINT(1) DEFAULT 0,
    dt_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela para controle de sessões de usuário (para login e persistência)
CREATE TABLE IF NOT EXISTS tb_sessao (
    id_sessao INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    ds_token VARCHAR(255) NOT NULL UNIQUE, -- Token de sessão (pode ser um JWT ou string aleatória)
    dt_expiracao DATETIME NOT NULL,
    dt_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela para tokens de recuperação de senha
CREATE TABLE IF NOT EXISTS tb_recuperacao_senha (
    id_recuperacao INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    ds_token VARCHAR(255) NOT NULL UNIQUE,
    dt_expiracao DATETIME NOT NULL,
    bl_usado TINYINT(1) DEFAULT 0, -- Indica se o token já foi usado
    dt_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela para gerenciar Cobranças PIX geradas pelo sistema
CREATE TABLE IF NOT EXISTS tb_pix_cobranca_gerada (
    id_cobranca_pix INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL, -- Usuário que gerou a cobrança (para depósito) ou que será cobrado
    ds_transaction_id_provider VARCHAR(255) NOT NULL UNIQUE, -- ID único da transação fornecido pelo gateway de pagamento (Ex: E2E ID do Pix)
    vl_valor_cobrado DECIMAL(10, 2) NOT NULL,
    ds_status ENUM('Pendente', 'Concluída', 'Cancelada', 'Expirada', 'Em Processamento') NOT NULL DEFAULT 'Pendente',
    ds_qr_code_data TEXT, -- Dados do QR Code (base64 da imagem ou URL do QR Code)
    ds_copy_paste_code TEXT, -- O código "Copia e Cola" do Pix
    dt_criacao DATETIME DEFAULT CURRENT_TIMESTAMP,
    dt_expiracao DATETIME NOT NULL, -- Prazo de validade do QR Code/Cobrança
    dt_confirmacao DATETIME NULL, -- Data e hora em que o pagamento foi confirmado pelo webhook/provedor
    ds_info_pagador TEXT NULL, -- Alterado de JSON para TEXT para compatibilidade com Navicat 8
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela para gerenciar PIX Automático (Agendamento)
CREATE TABLE IF NOT EXISTS tb_pix_agendado (
    id_agendamento INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL, -- Usuário que criou o agendamento
    ch_chave_pix_destino VARCHAR(255) NOT NULL, -- Chave PIX do destinatário
    tp_tipo_chave_destino ENUM('CPF', 'CNPJ', 'E-mail', 'Telefone', 'Aleatória') NOT NULL, -- Tipo da chave do destinatário
    vl_valor DECIMAL(10,2) NOT NULL, -- Valor a ser enviado
    ds_descricao_agendamento TEXT, -- Descrição para este agendamento
    dt_primeira_execucao DATETIME NOT NULL, -- Data e hora da primeira execução
    tp_frequencia ENUM('Diário', 'Semanal', 'Mensal', 'Anual', 'Única') NOT NULL, -- Frequência de execução
    dt_proxima_execucao DATETIME NOT NULL, -- Próxima data e hora de execução agendada
    dt_fim_agendamento DATETIME NULL, -- Data e hora de encerramento do agendamento (opcional)
    ds_status_agendamento ENUM('Ativo', 'Pausado', 'Concluído', 'Cancelado', 'Falha') DEFAULT 'Ativo' NOT NULL, -- Status do agendamento
    dt_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- Data de criação do agendamento
    dt_ultima_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, -- Última atualização
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE -- Chave estrangeira para o usuário
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Exemplo de adição de dados de teste (opcional, para administradores)
-- Lembre-se de substituir 'sua_senha_hash_aqui' por uma senha real hasheada (e.g., password_hash() no PHP)
-- INSERT INTO tb_admin (nm_admin, ds_email, ds_senha_hash, ds_nivel_acesso) VALUES
-- ('Admin Principal', 'admin@banklopes.com', '$2y$10$iM.D8yWzN9P7T3pA7z0R4.uQ.sZ9B5c2mX4.Q9P5K5Q.j7P2uQ.sQ.lQ.gQ.kQ.hQ.fQ.eQ.dQ.cQ.bQ.aQ.s', 'SuperAdmin');
