<?php
// www/pages/my_cards.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

// Exibição de erros para depuração (MUITO IMPORTANTE: REMOVER EM PRODUÇÃO!)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Verifica se o usuário está logado.
if (!isset($_SESSION['user_id'])) {
    set_message("Você precisa estar logado para ver seus cartões.", "error");
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$userName = htmlspecialchars($_SESSION['user_name'] ?? 'Usuário');

// Lógica para EXCLUIR ou ATUALIZAR STATUS de um cartão
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $card_id = filter_var($_POST['card_id'] ?? null, FILTER_VALIDATE_INT);

    if (!$card_id) {
        set_message("ID do cartão inválido.", "error");
        redirect('my_cards.php');
    }

    try {
        $pdo->beginTransaction();

        // Verifica se o cartão pertence ao usuário logado para evitar exclusão indevida
        $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM tb_informacao_cartao WHERE id_informacao = ? AND id_usuario = ?");
        $stmt_check->execute([$card_id, $user_id]);
        if ($stmt_check->fetchColumn() === 0) {
            set_message("Você não tem permissão para gerenciar este cartão ou ele não existe.", "error");
            $pdo->rollBack();
            redirect('my_cards.php');
        }

        if ($_POST['action'] === 'delete_card') {
            $stmt_delete = $pdo->prepare("DELETE FROM tb_informacao_cartao WHERE id_informacao = ? AND id_usuario = ?");
            $stmt_delete->execute([$card_id, $user_id]);
            set_message("Cartão excluído com sucesso!", "success");
        } elseif ($_POST['action'] === 'toggle_status') {
            $current_status = $_POST['current_status'] ?? 'Ativo';
            $new_status = ($current_status === 'Ativo') ? 'Inativo' : 'Ativo';

            $stmt_update_status = $pdo->prepare("UPDATE tb_informacao_cartao SET ds_status = ? WHERE id_informacao = ? AND id_usuario = ?");
            $stmt_update_status->execute([$new_status, $card_id, $user_id]);
            set_message("Status do cartão alterado para " . ($new_status === 'Ativo' ? 'Ativo' : 'Inativo') . "!", "success");
        }
        $pdo->commit();
        redirect('my_cards.php'); // Redireciona para atualizar a lista após qualquer ação
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("Erro ao gerenciar cartão (PDO): " . $e->getMessage());
        set_message("Ocorreu um erro ao processar sua solicitação: " . $e->getMessage(), "error");
        redirect('my_cards.php');
    }
}


$cards = [];
try {
    // Adicionando 'ds_status' à seleção
    // NOTA DE SEGURANÇA: NUNCA SELECIONE O CVV OU O NÚMERO COMPLETO DO CARTÃO AQUI!
    // A coluna 'nr_cartao_tokenizado' já armazena apenas os últimos 4 dígitos mascarados para segurança.
    $stmt_cards = $pdo->prepare("SELECT id_informacao, tp_tipo, nr_cartao_tokenizado, nm_titular, dt_validade, ds_bandeira, ds_status FROM tb_informacao_cartao WHERE id_usuario = ? ORDER BY dt_cadastro DESC");
    $stmt_cards->execute([$user_id]);
    $cards = $stmt_cards->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Erro ao buscar cartões: " . $e->getMessage());
    set_message("Ocorreu um erro ao carregar seus cartões.", "error");
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meus Cartões - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .cards-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-top: 30px;
        }
        .card-item {
            background-color: var(--secondary-color);
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            text-align: left;
            border-left: 5px solid var(--primary-color); /* Detalhe visual */
            position: relative; /* Para posicionar os botões de ação */
        }
        .card-item h3 {
            color: var(--primary-dark-color);
            margin-bottom: 15px;
            font-size: 1.5em;
            display: flex;
            align-items: center;
        }
        .card-item h3 svg {
            margin-right: 10px;
        }
        .card-item p {
            font-size: 1em;
            color: var(--text-color);
            margin-bottom: 8px;
        }
        .card-item p strong {
            color: #333;
        }
        .card-actions-buttons {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-top: 30px;
            justify-content: center;
        }
        .card-actions-buttons .button {
            padding: 12px 25px;
            font-size: 1em;
            flex-grow: 1;
            max-width: 250px;
            text-align: center;
        }
        .card-item-actions { /* Contêiner para os botões de ação do cartão */
            position: absolute;
            top: 15px;
            right: 15px;
            display: flex;
            gap: 10px; /* Espaçamento entre os botões */
            z-index: 10; /* Garante que fiquem acima de outros elementos */
        }
        .card-item-actions button {
            background: none;
            border: none;
            cursor: pointer;
            padding: 0;
            line-height: 1;
            transition: color 0.2s ease;
        }
        .card-item-actions button svg {
            width: 24px;
            height: 24px;
        }
        .card-item-actions .delete-button {
            color: #dc3545; /* Vermelho para exclusão */
        }
        .card-item-actions .delete-button:hover {
            color: #c82333;
        }
        .card-item-actions .status-button {
            color: var(--primary-color); /* Verde para ativo/inativo */
        }
        .card-item-actions .status-button.inactive {
            color: #ffc107; /* Amarelo para inativo, ou cinza */
        }
        .card-item-actions .status-button:hover {
            filter: brightness(0.8);
        }

        /* Estilos para mensagens (alerta) */
        .alert {
            padding: 12px 20px;
            margin-bottom: 20px;
            border-radius: 10px;
            text-align: left;
            font-weight: 500;
            font-size: 0.9em;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .alert.error {
            background-color: #ffe6e6;
            color: #cc0000;
            border: 1px solid #ffcccc;
        }
        .alert.success {
            background-color: #e6ffe6;
            color: #008000;
            border: 1px solid #ccffcc;
        }
        .alert.info {
            background-color: #e6f7ff;
            color: #0066cc;
            border: 1px solid #cceeff;
        }

        .security-note { /* Estilo para a nota de segurança */
            font-size: 0.9em; /* Levemente maior */
            color: #666;
            margin-top: 20px;
            padding: 15px; /* Maior padding */
            background-color: #fff3cd; /* Cor de alerta mais suave (amarelo claro) */
            border-left: 4px solid #ffc107; /* Cor de alerta (amarelo) */
            border-radius: 5px;
            line-height: 1.5;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        .security-note strong {
            color: #856404; /* Cor mais escura para o negrito do alerta */
        }


        @media (max-width: 768px) {
            .card-item {
                padding: 20px;
            }
            .card-item h3 {
                font-size: 1.3em;
            }
            .card-actions-buttons .button {
                width: 100%;
                max-width: unset;
            }
            .card-item-actions {
                top: 10px;
                right: 10px;
                gap: 5px;
            }
            .security-note {
                font-size: 0.8em;
                padding: 10px;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Bank Lopes</div>
            <nav>
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li>Olá, <?= $userName ?></li>
                    <li><a href="logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="form-container">
            <h2>Meus Cartões</h2>
            <?php display_messages(); ?>

            <div class="security-note">
                <strong>Nota de Segurança Importante:</strong> Para sua máxima proteção e para aderir aos padrões de segurança internacionais da indústria de pagamentos (como PCI-DSS), o **código de segurança (CVV)** e o **número completo do cartão** **NÃO SÃO E NUNCA SERÃO ARMAZENADOS OU EXIBIDOS** neste sistema. Apenas os últimos 4 dígitos são mostrados para sua referência. A segurança dos seus dados é nossa prioridade.
            </div>

            <?php if (!empty($cards)): ?>
                <div class="cards-grid">
                    <?php foreach ($cards as $card): ?>
                        <div class="card-item">
                            <div class="card-item-actions">
                                <!-- Botão/Formulário para Alterar Status -->
                                <form action="my_cards.php" method="POST" onsubmit="return confirm('Tem certeza que deseja alterar o status deste cartão?');">
                                    <input type="hidden" name="action" value="toggle_status">
                                    <input type="hidden" name="card_id" value="<?= htmlspecialchars($card['id_informacao']) ?>">
                                    <input type="hidden" name="current_status" value="<?= htmlspecialchars($card['ds_status']) ?>">
                                    <button type="submit" class="status-button <?= ($card['ds_status'] === 'Inativo') ? 'inactive' : '' ?>" title="Alterar Status (<?= htmlspecialchars($card['ds_status']) ?>)">
                                        <?php if ($card['ds_status'] === 'Ativo'): ?>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-check-circle"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="m9 11 3 3L22 4"/></svg>
                                        <?php else: ?>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-minus-circle"><circle cx="12" cy="12" r="10"/><path d="M8 12h8"/></svg>
                                        <?php endif; ?>
                                    </button>
                                </form>

                                <!-- Formulário para exclusão do cartão -->
                                <form action="my_cards.php" method="POST" onsubmit="return confirm('Tem certeza que deseja excluir este cartão? Esta ação é irreversível.');">
                                    <input type="hidden" name="action" value="delete_card">
                                    <input type="hidden" name="card_id" value="<?= htmlspecialchars($card['id_informacao']) ?>">
                                    <button type="submit" class="delete-button" title="Excluir Cartão">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-x-circle"><circle cx="12" cy="12" r="10"/><path d="m15 9-6 6"/><path d="m9 9 6 6"/></svg>
                                    </button>
                                </form>
                            </div>

                            <h3>
                                <?php if ($card['tp_tipo'] == 'Crédito'): ?>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-credit-card"><rect width="20" height="14" x="2" y="5" rx="2"/><line x1="2" x2="22" y1="10" y2="10"/></svg>
                                <?php elseif ($card['tp_tipo'] == 'Débito'): ?>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-wallet"><path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h12a2 2 0 0 1 0 4H3a2 2 0 0 0 0 4h18a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2h-3Z"/><path d="M16 3v4"/></svg>
                                <?php elseif ($card['tp_tipo'] == 'Virtual'): ?>
                                     <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-smartphone-nfc"><rect width="7" height="12" x="12" y="6" rx="2"/><path d="M7 19h10"/><path d="M18 19a2 2 0 0 0 2-2v-1c0-.7-.3-1.5-.9-2.1l-1.4-1.4c-.6-.6-1.4-.9-2.1-.9H12"/><path d="M10 6H7a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h11"/></svg>
                                <?php else: ?>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-banknote"><rect width="20" height="12" x="2" y="6" rx="2"/><circle cx="12" cy="12" r="3"/><path d="M6 12h.01M18 12h.01"/></svg>
                                <?php endif; ?>
                                Cartão de <?= htmlspecialchars($card['tp_tipo']) ?>
                            </h3>
                            <p>Bandeira: <strong><?= htmlspecialchars($card['ds_bandeira']) ?></strong></p>
                            <!-- Apenas os últimos 4 dígitos são exibidos por segurança, o número completo não é armazenado. -->
                            <p>Final do Cartão: <strong>...<?= substr(htmlspecialchars($card['nr_cartao_tokenizado']), -4) ?></strong></p>
                            <p>Titular: <strong><?= htmlspecialchars($card['nm_titular']) ?></strong></p>
                            <p>Validade: <strong><?= htmlspecialchars(date('m/Y', strtotime($card['dt_validade']))) ?></strong></p>
                            <p>Status: <strong style="color: <?= ($card['ds_status'] === 'Ativo') ? 'var(--primary-color)' : '#ffc107' ?>;"><?= htmlspecialchars($card['ds_status']) ?></strong></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p>Nenhum cartão cadastrado. Adicione um para ver aqui!</p>
            <?php endif; ?>

            <div class="card-actions-buttons">
                <a href="add_card.php" class="button primary">Adicionar Novo Cartão</a>
                <a href="create_virtual_card.php" class="button secondary">Criar Cartão Virtual</a>
            </div>
            <p><a href="dashboard.php">Voltar para o Dashboard</a></p>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>
</body>
</html>
