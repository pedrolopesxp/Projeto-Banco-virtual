<?php
// www/pages/dashboard.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php'; // Inclui functions.php onde generate_uuid_v4() está

// Verifica se o usuário está logado. Se não, redireciona para a página de login.
if (!isset($_SESSION['user_id'])) {
    set_message("Você precisa estar logado para acessar o dashboard.", "error");
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$userName = htmlspecialchars($_SESSION['user_name'] ?? 'Usuário');

// --- Variáveis de dados iniciais ---
$user_info = [];
$current_real_balance = 0;
$current_bitcoin_balance = 0;
$user_pix_keys = [];
$user_bitcoin_addresses = []; // Nova variável para armazenar endereços Bitcoin
$can_generate_random_pix_key = true;
$max_random_pix_keys = 5; // Limite de chaves PIX aleatórias por usuário

// --- Lógica para processar ações POST ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'create_pix_key') { // Alterado para 'create_pix_key'
        $pix_key_type = filter_input(INPUT_POST, 'pix_key_type', FILTER_SANITIZE_STRING);
        $pix_key_value = trim(filter_input(INPUT_POST, 'pix_key_value', FILTER_SANITIZE_STRING)); // Trim whitespace
        $is_principal = isset($_POST['is_principal']) ? 1 : 0; // Nova linha: captura se a chave é principal

        $generated_key = '';
        $rotulo = '';
        $validation_error = false;
        $message = '';

        // Obter a contagem atual de chaves aleatórias ANTES de tentar gerar/inserir
        $stmt_random_key_count = $pdo->prepare("SELECT COUNT(*) FROM tb_informacao_pix WHERE id_usuario = ? AND tp_tipo_chave = 'Aleatória'");
        $stmt_random_key_count->execute([$user_id]);
        $random_pix_key_count_for_check = $stmt_random_key_count->fetchColumn();


        if (empty($pix_key_type)) {
            $validation_error = true;
            $message = "Por favor, selecione um tipo de chave PIX.";
        } else {
            switch ($pix_key_type) {
                case 'Aleatória':
                    if ($random_pix_key_count_for_check >= $max_random_pix_keys) {
                        $validation_error = true;
                        $message = "Você atingiu o limite de " . $max_random_pix_keys . " chaves PIX aleatórias.";
                    } else {
                        $generated_key = generate_uuid_v4();
                        $rotulo = "Chave Aleatória " . date('Y-m-d H:i:s');
                    }
                    break;
                case 'CPF':
                    $pix_key_value = preg_replace('/[^0-9]/', '', $pix_key_value); // Remove non-numeric
                    if (!preg_match('/^\d{11}$/', $pix_key_value)) { // Basic CPF format check (11 digits)
                        $validation_error = true;
                        $message = "CPF inválido. Deve conter 11 dígitos numéricos.";
                    } else {
                        $generated_key = $pix_key_value;
                        $rotulo = "CPF";
                    }
                    break;
                case 'CNPJ':
                    $pix_key_value = preg_replace('/[^0-9]/', '', $pix_key_value); // Remove non-numeric
                    if (!preg_match('/^\d{14}$/', $pix_key_value)) { // Basic CNPJ format check (14 digits)
                        $validation_error = true;
                        $message = "CNPJ inválido. Deve conter 14 dígitos numéricos.";
                    } else {
                        $generated_key = $pix_key_value;
                        $rotulo = "CNPJ";
                    }
                    break;
                case 'Email':
                    if (!filter_var($pix_key_value, FILTER_VALIDATE_EMAIL)) {
                        $validation_error = true;
                        $message = "E-mail inválido.";
                    } else {
                        $generated_key = $pix_key_value;
                        $rotulo = "E-mail";
                    }
                    break;
                case 'Telefone':
                    $pix_key_value = preg_replace('/[^0-9]/', '', $pix_key_value); // Remove non-numeric
                    // Assuming a phone number can have between 10 and 11 digits (with DDD) in Brazil for simplicity
                    if (!preg_match('/^\d{10,11}$/', $pix_key_value)) { 
                        $validation_error = true;
                        $message = "Telefone inválido. Deve conter 10 ou 11 dígitos numéricos (com DDD).";
                    } else {
                        $generated_key = $pix_key_value;
                        $rotulo = "Telefone";
                    }
                    break;
                default:
                    $validation_error = true;
                    $message = "Tipo de chave PIX inválido selecionado.";
                    break;
            }
        }

        if (!$validation_error) {
            if (empty($generated_key)) { // This should ideally not happen if logic is correct
                $validation_error = true;
                $message = "Erro interno: a chave PIX não foi gerada ou validada corretamente.";
            } else {
                try {
                    $pdo->beginTransaction(); // Inicia uma transação

                    // Check if key already exists for the user to prevent duplicates (except for random)
                    // We check for duplicate only if the key is not random, because random keys are by nature unique UUIDs.
                    if ($pix_key_type !== 'Aleatória') {
                        $stmt_check_duplicate = $pdo->prepare("SELECT COUNT(*) FROM tb_informacao_pix WHERE id_usuario = ? AND ch_chave_pix = ? AND tp_tipo_chave = ?");
                        $stmt_check_duplicate->execute([$user_id, $generated_key, $pix_key_type]);
                        if ($stmt_check_duplicate->fetchColumn() > 0) {
                            $validation_error = true;
                            $message = "Esta chave PIX (Tipo: " . htmlspecialchars($pix_key_type) . ", Valor: " . htmlspecialchars($generated_key) . ") já está cadastrada para o seu usuário.";
                        }
                    }

                    if (!$validation_error) {
                        // Se a nova chave será principal, desativar a atual chave principal do usuário
                        if ($is_principal) {
                            $stmt_unset_principal = $pdo->prepare("UPDATE tb_informacao_pix SET bo_principal = 0 WHERE id_usuario = ? AND bo_principal = 1");
                            $stmt_unset_principal->execute([$user_id]);
                        }

                        $stmt_insert_pix = $pdo->prepare("INSERT INTO tb_informacao_pix (id_usuario, ch_chave_pix, tp_tipo_chave, ds_rotulo, bo_principal, dt_criacao) VALUES (?, ?, ?, ?, ?, NOW())");
                        $stmt_insert_pix->execute([$user_id, $generated_key, $pix_key_type, $rotulo, $is_principal]);
                        
                        $pdo->commit(); // Confirma a transação
                        set_message("Chave PIX do tipo '" . htmlspecialchars($pix_key_type) . "' gerada/cadastrada com sucesso!" . ($is_principal ? " (Definida como Principal)" : ""), "success");
                    } else {
                         $pdo->rollBack(); // Reverte a transação em caso de erro de validação
                    }
                } catch (PDOException $e) {
                    $pdo->rollBack(); // Reverte a transação em caso de erro no banco de dados
                    error_log("Erro ao gerar/cadastrar chave PIX: " . $e->getMessage());
                    // Check if it's a duplicate entry error from DB (e.g., if ch_chave_pix is unique and someone tries to register same email/cpf twice)
                    if ($e->getCode() == '23000' && strpos($e->getMessage(), 'Duplicate entry') !== false) {
                        set_message("Erro: A chave PIX '" . htmlspecialchars($generated_key) . "' já existe para este tipo. Por favor, utilize outra ou verifique suas chaves existentes.", "error");
                    } else {
                        set_message("Ocorreu um erro ao gerar/cadastrar a chave PIX. Por favor, tente novamente. Detalhes: " . $e->getMessage(), "error");
                    }
                }
            }
        }

        if ($validation_error) {
            set_message($message, "error");
        }
        header("Location: " . get_base_url() . "/pages/dashboard.php");
        exit();

    } elseif ($_POST['action'] === 'delete_pix_key') {
        $key_id_to_delete = filter_input(INPUT_POST, 'key_id', FILTER_VALIDATE_INT);

        if ($key_id_to_delete) {
            try {
                $stmt_check_key = $pdo->prepare("SELECT id_informacao, tp_tipo_chave FROM tb_informacao_pix WHERE id_informacao = ? AND id_usuario = ?");
                $stmt_check_key->execute([$key_id_to_delete, $user_id]);
                $key_data = $stmt_check_key->fetch(PDO::FETCH_ASSOC);
                
                if ($key_data) {
                    error_log("Tentativa de exclusão: Chave ID " . $key_id_to_delete . ", Tipo: " . $key_data['tp_tipo_chave']);

                    // Permite a exclusão de qualquer tipo de chave PIX cadastrada pelo usuário via dashboard.
                    $stmt_delete_key = $pdo->prepare("DELETE FROM tb_informacao_pix WHERE id_informacao = ? AND id_usuario = ?");
                    $stmt_delete_key->execute([$key_id_to_delete, $user_id]);
                    set_message("Chave PIX do tipo '" . htmlspecialchars($key_data['tp_tipo_chave']) . "' excluída com sucesso! (ID: " . $key_id_to_delete . ")", "success");
                } else {
                    set_message("Falha na exclusão: Chave PIX ID " . $key_id_to_delete . " não encontrada para o seu usuário ou não é válida.", "error");
                }
            } catch (PDOException $e) {
                error_log("Erro ao excluir chave PIX: " . $e->getMessage());
                set_message("Ocorreu um erro ao excluir a chave PIX. Por favor, tente novamente. Detalhes do BD: " . $e->getMessage(), "error");
            }
        } else {
            set_message("ID da chave PIX inválido para exclusão: " . htmlspecialchars($_POST['key_id'] ?? 'Não fornecido'), "error");
        }
        // Sempre redireciona para evitar reenvio do formulário e atualizar a lista
        header("Location: " . get_base_url() . "/pages/dashboard.php");
        exit();
    } elseif ($_POST['action'] === 'set_pix_key_as_principal') { // Nova ação para definir como principal
        $key_id_to_set_principal = filter_input(INPUT_POST, 'key_id', FILTER_VALIDATE_INT);

        if ($key_id_to_set_principal) {
            try {
                $pdo->beginTransaction(); // Inicia uma transação

                // 1. Verificar se a chave pertence ao usuário
                $stmt_check_owner = $pdo->prepare("SELECT id_informacao FROM tb_informacao_pix WHERE id_informacao = ? AND id_usuario = ?");
                $stmt_check_owner->execute([$key_id_to_set_principal, $user_id]);
                
                if ($stmt_check_owner->fetch(PDO::FETCH_ASSOC)) {
                    // 2. Desativar a chave principal atual do usuário (se houver)
                    $stmt_unset_current_principal = $pdo->prepare("UPDATE tb_informacao_pix SET bo_principal = 0 WHERE id_usuario = ? AND bo_principal = 1");
                    $stmt_unset_current_principal->execute([$user_id]);

                    // 3. Definir a nova chave como principal
                    $stmt_set_new_principal = $pdo->prepare("UPDATE tb_informacao_pix SET bo_principal = 1 WHERE id_informacao = ? AND id_usuario = ?");
                    $stmt_set_new_principal->execute([$key_id_to_set_principal, $user_id]);

                    $pdo->commit(); // Confirma a transação
                    set_message("Chave PIX definida como principal com sucesso!", "success");
                } else {
                    $pdo->rollBack(); // Reverte a transação
                    set_message("Erro: A chave PIX selecionada não foi encontrada ou não pertence a você.", "error");
                }
            } catch (PDOException $e) {
                $pdo->rollBack(); // Reverte a transação em caso de erro
                error_log("Erro ao definir chave PIX como principal: " . $e->getMessage());
                set_message("Ocorreu um erro ao definir a chave PIX como principal. Por favor, tente novamente. Detalhes: " . $e->getMessage(), "error");
            }
        } else {
            set_message("ID da chave PIX inválido para definir como principal.", "error");
        }
        header("Location: " . get_base_url() . "/pages/dashboard.php");
        exit();
    } elseif ($_POST['action'] === 'generate_bitcoin_address') {
        try {
            $mock_address = 'bc1q' . bin2hex(random_bytes(18)); // Exemplo de endereço com 20 bytes hex + prefixo
            $rotulo = "Endereço BTC " . date('Y-m-d H:i:s');
            $qr_code_data = "https://placehold.co/150x150/000000/FFFFFF?text=BTC+Address+QR";

            $stmt_insert_btc = $pdo->prepare("INSERT INTO tb_endereco_bitcoin (id_usuario, ds_endereco, ds_qr_code, tp_tipo, ds_rotulo, dt_criacao) VALUES (?, ?, ?, ?, ?, NOW())");
            $stmt_insert_btc->execute([$user_id, $mock_address, $qr_code_data, 'Recebimento', $rotulo]);

            set_message("Novo endereço Bitcoin gerado com sucesso! (Simulado)", "success");
        } catch (PDOException $e) {
            error_log("Erro ao gerar endereço Bitcoin: " . $e->getMessage());
            set_message("Ocorreu um erro ao gerar o endereço Bitcoin. Por favor, tente novamente. Detalhes: " . $e->getMessage(), "error");
        }
        header("Location: " . get_base_url() . "/pages/dashboard.php");
        exit();
    }
}

// --- Lógica para buscar informações do usuário e saldo (após processar POST, se houver) ---
try {
    // Buscar informações completas do usuário
    $stmt_user_info = $pdo->prepare("SELECT nm_usuario, ds_email, ds_cpf, dt_nascimento, ds_telefone, ds_endereco, ds_cidade, ds_estado, ds_pais_origem, dt_cadastro FROM tb_usuario WHERE id_usuario = ?");
    $stmt_user_info->execute([$user_id]);
    $user_info = $stmt_user_info->fetch(PDO::FETCH_ASSOC);

    // Buscar saldos da conta
    $stmt_balance = $pdo->prepare("SELECT vl_saldo_bitcoin, vl_saldo_real FROM tb_conta WHERE id_usuario = ?");
    $stmt_balance->execute([$user_id]);
    $account_data = $stmt_balance->fetch(PDO::FETCH_ASSOC);
    if ($account_data) {
        $current_bitcoin_balance = $account_data['vl_saldo_bitcoin'];
        $current_real_balance = $account_data['vl_saldo_real'];
    }

    // Buscar chaves PIX do usuário (agora incluindo bo_principal)
    $stmt_pix_keys = $pdo->prepare("SELECT id_informacao, ch_chave_pix, tp_tipo_chave, ds_rotulo, bo_principal, dt_criacao FROM tb_informacao_pix WHERE id_usuario = ? ORDER BY bo_principal DESC, dt_criacao DESC");
    $stmt_pix_keys->execute([$user_id]);
    $user_pix_keys = $stmt_pix_keys->fetchAll(PDO::FETCH_ASSOC);

    // Contar chaves aleatórias para aplicar o limite
    $random_pix_key_count = 0;
    foreach ($user_pix_keys as $key) {
        if ($key['tp_tipo_chave'] === 'Aleatória') {
            $random_pix_key_count++;
        }
    }
    if ($random_pix_key_count >= $max_random_pix_keys) {
        $can_generate_random_pix_key = false;
    }


    // Buscar endereços Bitcoin do usuário (apenas do tipo 'Recebimento' para este contexto)
    $stmt_btc_addresses = $pdo->prepare("SELECT id_endereco, ds_endereco, ds_qr_code, ds_rotulo, dt_criacao FROM tb_endereco_bitcoin WHERE id_usuario = ? AND tp_tipo = 'Recebimento' ORDER BY dt_criacao DESC");
    $stmt_btc_addresses->execute([$user_id]);
    $user_bitcoin_addresses = $stmt_btc_addresses->fetchAll(PDO::FETCH_ASSOC);


} catch (PDOException $e) {
    error_log("Erro ao carregar dados do dashboard: " . $e->getMessage());
    set_message("Erro ao carregar suas informações. Por favor, tente novamente.", "error");
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"> <!-- Adicionado Font Awesome -->
    <style>
        /* Estilos existentes do código original */
        .dashboard-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 30px;
            margin-top: 30px;
        }

        .dashboard-section {
            background-color: var(--secondary-color);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        }

        .dashboard-section h3 {
            color: var(--primary-color);
            margin-bottom: 20px;
            font-size: 1.8em;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .dashboard-section h3 svg {
            width: 28px;
            height: 28px;
        }

        .balance-info p {
            font-size: 1.1em;
            margin-bottom: 10px;
        }
        .balance-info strong {
            color: var(--primary-dark-color);
        }

        .user-profile-info p {
            margin-bottom: 8px;
        }
        .user-profile-info p strong {
            color: #555;
        }

        .actions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }
        .actions-grid .button {
            padding: 15px 10px;
            font-size: 1em;
            text-align: center;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        /* PIX Keys Styling */
        .pix-keys-list, .bitcoin-addresses-list {
            list-style: none;
            padding: 0;
            margin-top: 15px;
        }
        .pix-keys-list li, .bitcoin-addresses-list li {
            background-color: var(--light-gray);
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.95em;
            flex-wrap: wrap; /* Para chaves longas em telas pequenas */
        }
        .pix-keys-list li strong, .bitcoin-addresses-list li strong {
            color: var(--primary-dark-color);
        }
        .pix-keys-list li .pix-key-details, .bitcoin-addresses-list li .address-details {
            word-break: break-all; /* Quebra a linha para chaves longas */
            flex-grow: 1;
            margin-right: 10px;
        }
        .pix-keys-list li .pix-key-details .principal-tag {
            background-color: var(--primary-color);
            color: white;
            padding: 2px 8px;
            border-radius: 5px;
            font-size: 0.8em;
            font-weight: bold;
            margin-left: 10px;
            vertical-align: middle;
        }

        .pix-keys-list li .copy-button,
        .pix-keys-list li .delete-button,
        .pix-keys-list li .set-principal-button, /* Novo estilo para o botão */
        .bitcoin-addresses-list li .copy-button,
        .bitcoin-addresses-list li .qr-code-button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.2s ease;
            white-space: nowrap; /* Evita que o botão quebre a linha */
            margin-left: 5px; /* Espaço entre botões */
        }
        .pix-keys-list li .copy-button:hover,
        .bitcoin-addresses-list li .copy-button:hover {
            background-color: #0056b3;
        }
        .pix-keys-list li .delete-button {
            background-color: #dc3545; /* Vermelho para deletar */
        }
        .pix-keys-list li .delete-button:hover {
            background-color: #c82333;
        }
        .pix-keys-list li .delete-button:disabled {
            background-color: #cccccc;
            cursor: not-allowed;
        }
        
        .pix-keys-list li .set-principal-button { /* Estilo para o novo botão */
            background-color: #ffc107; /* Amarelo para definir como principal */
            color: #333;
        }
        .pix-keys-list li .set-principal-button:hover {
            background-color: #e0a800;
        }
        .pix-keys-list li .set-principal-button:disabled {
            background-color: #cccccc;
            cursor: not-allowed;
        }


        /* Bitcoin specific buttons */
        .bitcoin-addresses-list li .qr-code-button {
            background-color: #28a745; /* Green for QR Code */
            margin-left: 8px; /* Space from copy button */
        }
        .bitcoin-addresses-list li .qr-code-button:hover {
            background-color: #218838;
        }

        .generate-pix-button-container, .generate-bitcoin-button-container {
            margin-top: 20px;
            /* text-align: center; */ /* Removido para alinhar o formulário à esquerda */
        }
        .generate-pix-button-container .button, .generate-bitcoin-button-container .button {
            background-color: #17a2b8; /* Cor para gerar chave */
            color: white;
            padding: 12px 25px;
            border-radius: 8px;
            font-weight: bold;
            text-align: center;
            text-decoration: none;
            transition: background-color 0.3s ease, transform 0.2s ease;
            display: inline-block;
            border: none;
            cursor: pointer;
            margin-top: 15px; /* Espaço entre o campo e o botão */
        }
        .generate-pix-button-container .button:hover, .generate-bitcoin-button-container .button:hover {
            background-color: #138496;
            transform: translateY(-2px);
        }
        .generate-pix-button-container .button:disabled, .generate-bitcoin-button-container .button:disabled {
            background-color: #cccccc;
            cursor: not-allowed;
            transform: none;
        }

        /* Formulario de Geração de PIX */
        .form-group {
            margin-bottom: 10px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }
        .form-group .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-size: 1em;
            box-sizing: border-box; /* Garante que padding e border sejam incluídos na largura */
        }
        .form-group .form-control:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 0 2px rgba(76, 175, 80, 0.2);
        }
        .form-group.checkbox-group {
            display: flex;
            align-items: center;
            margin-top: 15px;
        }
        .form-group.checkbox-group input[type="checkbox"] {
            margin-right: 10px;
            width: 20px;
            height: 20px;
            cursor: pointer;
        }

        /* Modal Styles */
        .modal {
            position: fixed; /* Stay in place */
            z-index: 1000; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background-color: #fefefe;
            margin: auto;
            padding: 30px;
            border: 1px solid #888;
            border-radius: 10px;
            width: 80%; /* Could be more responsive */
            max-width: 500px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
            text-align: center;
        }
        .modal-content.qr-modal img {
            max-width: 100%;
            height: auto;
            border: 1px solid #ddd;
            padding: 5px;
            border-radius: 5px;
            background-color: white;
            margin-top: 15px;
        }

        .modal-content h3 {
            margin-top: 0;
            color: var(--primary-color);
        }

        .modal-buttons {
            margin-top: 20px;
            display: flex;
            justify-content: center;
            gap: 15px;
        }

        .modal-buttons .button {
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            border: none;
            font-size: 1em;
            transition: background-color 0.2s ease;
        }

        .modal-buttons .button.confirm {
            background-color: #dc3545; /* Red for confirm */
            color: white;
        }
        .modal-buttons .button.confirm:hover {
            background-color: #c82333;
        }

        .modal-buttons .button.cancel {
            background-color: #6c757d; /* Gray for cancel */
            color: white;
        }
        .modal-buttons .button.cancel:hover {
            background-color: #5a6268;
        }


        @media (min-width: 768px) {
            .dashboard-grid {
                grid-template-columns: 2fr 1fr; /* Duas colunas em telas maiores */
            }
            .user-profile-section {
                grid-column: 1 / 2; /* Perfil na primeira coluna */
            }
            .pix-keys-section {
                grid-column: 2 / 3; /* PIX keys na segunda coluna */
            }
            .bitcoin-addresses-section {
                grid-column: 1 / -1; /* Endereços Bitcoin abaixo das outras colunas, ocupando a largura total */
            }
            .balance-info, .actions-section {
                grid-column: 1 / -1; /* Balanço e ações em largura total abaixo */
            }
            /* Ajuste para evitar que PIX keys e perfil fiquem muito pequenos ou desproporcionais */
            .user-profile-section, .pix-keys-section {
                min-width: 300px; /* Garante um tamanho mínimo */
            }
            .dashboard-section:nth-child(odd) { /* Exemplo: Alternar cor de fundo para seções */
                background-color: var(--light-gray);
            }
            .dashboard-section:nth-child(even) {
                background-color: var(--secondary-color);
            }
        }
        @media (max-width: 768px) {
            .dashboard-grid {
                grid-template-columns: 1fr; /* Uma coluna em telas menores */
            }
            .actions-grid {
                grid-template-columns: 1fr; /* Botões empilhados */
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Bank Lopes</div>
            <nav>
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li>Olá, <?= $userName ?></li>
                    <li><a href="logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="form-container" style="max-width: 90%; text-align: left;">
            <h2>Bem-vindo(a), <?= $userName ?>!</h2>
            <?php display_messages(); ?>

            <div class="dashboard-grid">
                <!-- Seção de Saldo -->
                <div class="dashboard-section balance-info">
                    <h3>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-wallet"><path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h12a2 2 0 0 1 0 4H3a2 2 0 0 0 0 4h18a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2h-3Z"/><path d="M16 3v4"/></svg>
                        Seu Saldo
                    </h3>
                    <p>Saldo em Reais: <strong>R$ <?= htmlspecialchars(number_format($current_real_balance, 2, ',', '.')) ?></strong></p>
                    <p>Saldo em Bitcoin: <strong><?= htmlspecialchars(number_format($current_bitcoin_balance, 8, ',', '.')) ?> BTC</strong></p>
                </div>

                <!-- Seção de Perfil do Usuário -->
                <div class="dashboard-section user-profile-section">
                    <h3>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-user"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                        Meu Perfil
                    </h3>
                    <?php if (!empty($user_info)): ?>
                        <div class="user-profile-info">
                            <p>Nome: <strong><?= htmlspecialchars($user_info['nm_usuario']) ?></strong></p>
                            <p>E-mail: <strong><?= htmlspecialchars($user_info['ds_email']) ?></strong></p>
                            <p>CPF: <strong><?= htmlspecialchars($user_info['ds_cpf']) ?></strong></p>
                            <p>Data de Nascimento: <strong><?= htmlspecialchars(date('d/m/Y', strtotime($user_info['dt_nascimento']))) ?></strong></p>
                            <p>Telefone: <strong><?= htmlspecialchars($user_info['ds_telefone'] ?: 'Não informado') ?></strong></p>
                            <p>Endereço: <strong><?= htmlspecialchars($user_info['ds_endereco'] ?: 'Não informado') ?></strong></p>
                            <p>Cidade: <strong><?= htmlspecialchars($user_info['ds_cidade'] ?: 'Não informado') ?></strong></p>
                            <p>Estado: <strong><?= htmlspecialchars($user_info['ds_estado'] ?: 'Não informado') ?></strong></p>
                            <p>País: <strong><?= htmlspecialchars($user_info['ds_pais_origem'] ?: 'Não informado') ?></strong></p>
                            <p>Membro desde: <strong><?= htmlspecialchars(date('d/m/Y H:i', strtotime($user_info['dt_cadastro']))) ?></strong></p>
                        </div>
                    <?php else: ?>
                        <p>Não foi possível carregar as informações do seu perfil.</p>
                    <?php endif; ?>
                </div>

                <!-- Seção de Chaves PIX -->
                <div class="dashboard-section pix-keys-section">
                    <h3>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-key-round"><path d="M2 18v3c0 .6.4 1 1 1h4v-3h-3v-3H2z"/><path d="M7 9H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h3v7Z"/><path d="M14 5H9l-5 5 7 7 5-5v-5Z"/><path d="M15 9h2a2 2 0 0 1 2 2v2a2 2 0 0 1-2 2h-2"/><path d="M22 7h-3V4a2 2 0 0 1 2-2h1a1 1 0 0 1 1 1v3Z"/><path d="M3 15h3v-3H3a1 1 0 0 0-1 1v2a1 1 0 0 0 1 1Z"/></svg>
                        Minhas Chaves PIX
                    </h3>
                    <?php if (!empty($user_pix_keys)): ?>
                        <ul class="pix-keys-list">
                            <?php foreach ($user_pix_keys as $key): ?>
                                <li>
                                    <div class="pix-key-details">
                                        <strong><?= htmlspecialchars($key['tp_tipo_chave']) ?>:</strong> <?= htmlspecialchars($key['ch_chave_pix']) ?>
                                        <?php if ($key['bo_principal']): // Exibe tag se for chave principal ?>
                                            <span class="principal-tag">Principal</span>
                                        <?php endif; ?>
                                        <?php if (!empty($key['ds_rotulo'])): ?>
                                            <br><small>(Rótulo: <?= htmlspecialchars($key['ds_rotulo']) ?>)</small>
                                        <?php endif; ?>
                                        <br><small>Criada em: <?= htmlspecialchars(date('d/m/Y H:i', strtotime($key['dt_criacao']))) ?></small>
                                    </div>
                                    <button class="copy-button" onclick="copyToClipboard('<?= htmlspecialchars($key['ch_chave_pix']) ?>')">Copiar</button>
                                    <?php if (!$key['bo_principal']): // Botão para definir como principal, se não for já ?>
                                        <button type="button" class="set-principal-button" onclick="setPixKeyAsPrincipal(<?= htmlspecialchars($key['id_informacao']) ?>)">Definir como Principal</button>
                                    <?php endif; ?>
                                    <button type="button" class="delete-button" onclick="showDeleteModal(<?= htmlspecialchars($key['id_informacao']) ?>)">Excluir</button>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <p>Nenhuma chave PIX cadastrada. Crie uma para começar a receber pagamentos!</p>
                    <?php endif; ?>

                    <div class="generate-pix-button-container">
                        <form action="dashboard.php" method="POST">
                            <input type="hidden" name="action" value="create_pix_key">
                            <div class="form-group">
                                <label for="pix_key_type">Tipo de Chave PIX:</label>
                                <select id="pix_key_type" name="pix_key_type" class="form-control" required onchange="handlePixKeyTypeChange()">
                                    <option value="">Selecione o tipo</option>
                                    <option value="Aleatória" <?= (!$can_generate_random_pix_key && $random_pix_key_count >= $max_random_pix_keys) ? 'disabled' : '' ?>>Aleatória</option>
                                    <option value="CPF">CPF</option>
                                    <option value="Email">E-mail</option>
                                    <option value="CNPJ">CNPJ</option>
                                    <option value="Telefone">Telefone</option>
                                </select>
                                <?php if (!$can_generate_random_pix_key && $random_pix_key_count >= $max_random_pix_keys): ?>
                                    <p style="font-size: 0.85em; color: #dc3545; margin-top: 5px;">Você já possui o limite de <?= $max_random_pix_keys ?> chaves PIX aleatórias.</p>
                                <?php endif; ?>
                            </div>
                            <div class="form-group" id="pix_key_value_group" style="display: none; margin-top: 15px;">
                                <label for="pix_key_value">Valor da Chave:</label>
                                <input type="text" id="pix_key_value" name="pix_key_value" class="form-control" placeholder="Informe a chave">
                            </div>
                            <div class="form-group checkbox-group">
                                <input type="checkbox" id="is_principal" name="is_principal" value="1">
                                <label for="is_principal">Definir como Chave Principal</label>
                            </div>
                            <button type="submit" class="button" id="generatePixKeyButton">
                                Gerar/Cadastrar Chave PIX
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Seção de Endereços Bitcoin -->
                <div class="dashboard-section bitcoin-addresses-section">
                    <h3>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-bitcoin"><path d="M11.76 17.85H9.65v-3.79c-1.4.24-2.28 1.15-2.28 2.37 0 1.25.75 2.06 2.05 2.06 1.13 0 1.83-.55 2.22-1.3l.03-.06zm3.32-4.14c-.66.86-1.57 1.3-2.68 1.3-1.6 0-2.83-1-2.83-2.54 0-1.46 1-2.3 2.5-2.43V8.8h2.09c.07-.36.2-.74.34-1.12a.67.67 0 0 0-.58-.8h-2.12V6.15h.69a.67.67 0 0 0 .58-.8h-.69V4.54a.67.67 0 0 0-.58-.8h-.69V2.83h-2.09a.67.67 0 0 0-.58-.8h-.69V.8a.67.67 0 0 0-.58-.8h-.69V-1.54h2.09a.67.67 0 0 0 .58-.8h-.69V-3.23a.67.67 0 0 0-.58-.8h-.69V-4.54a.67.67 0 0 0-.58-.8h-.69V-6.15h2.09a.67.67 0 0 0 .58-.8h-.69V-7.83a.67.67 0 0 0-.58-.8h-.69V-9.54h2.09a.67.67 0 0 0 .58-.8h-.69V-11.23a.67.67 0 0 0-.58-.8h-.69V-12.85h2.09a.67.67 0 0 0 .58-.8h-.69V-14.54a.67.67 0 0 0-.58-.8h-.69V-16.15h2.09a.67.67 0 0 0 .58-.8h-.69V-17.83a.67.67 0 0 0-.58-.8h-.69V-19.54h2.09a.67.67 0 0 0 .58-.8h-.69V-21.23a.67.67 0 0 0-.58-.8h-.69V-22.85h2.09a.67.67 0 0 0 .58-.8h-.69V-24.54a.67.67 0 0 0-.58-.8h-.69V-26.15h2.09a.67.67 0 0 0 .58-.8h-.69V-27.83a.67.67 0 0 0-.58-.8h-.69V-29.54h2.09a.67.67 0 0 0 .58-.8h-.69V-31.23a.67.67 0 0 0-.58-.8h-.69V-32.85h2.09a.67.67 0 0 0 .58-.8h-.69V-34.54a.67.67 0 0 0-.58-.8h-.69V-36.15h2.09a.67.67 0 0 0 .58-.8h-.69V-37.83a.67.67 0 0 0-.58-.8h-.69V-39.54h2.09a.67.67 0 0 0 .58-.8h-.69V-41.23a.67.67 0 0 0-.58-.8h-.69V-42.85h2.09a.67.67 0 0 0 .58-.8h-.69V-44.54a.67.67 0 0 0-.58-.8h-.69V-46.15h2.09a.67.67 0 0 0 .58-.8h-.69V-47.83a.67.67 0 0 0-.58-.8h-.69V-49.54h2.09a.67.67 0 0 0 .58-.8h-.69V-51.23a.67.67 0 0 0-.58-.8h-.69V-52.85h2.09a.67.67 0 0 0 .58-.8h-.69V-54.54a.67.67 0 0 0-.58-.8h-.69V-56.15h2.09a.67.67 0 0 0 .58-.8h-.69V-57.83a.67.67 0 0 0-.58-.8h-.69V-59.54h2.09a.67.67 0 0 0 .58-.8h-.69V-61.23a.67.67 0 0 0-.58-.8h-.69V-62.85h2.09a.67.67 0 0 0 .58-.8h-.69V-64.54a.67.67 0 0 0-.58-.8h-.69V-66.15h2.09a.67.67 0 0 0 .58-.8h-.69V-67.83a.67.67 0 0 0-.58-.8h-.69V-69.54h2.09a.67.67 0 0 0 .58-.8h-.69V-71.23a.67.67 0 0 0-.58-.8h-.69V-72.85h2.09a.67.67 0 0 0 .58-.8h-.69V-74.54a.67.67 0 0 0-.58-.8h-.69V-76.15h2.09a.67.67 0 0 0 .58-.8h-.69V-77.83a.67.67 0 0 0-.58-.8h-.69V-79.54h2.09a.67.67 0 0 0 .58-.8h-.69V-81.23a.67.67 0 0 0-.58-.8h-.69V-82.85h2.09a.67.67 0 0 0 .58-.8h-.69V-84.54a.67.67 0 0 0-.58-.8h-.69V-86.15h2.09a.67.67 0 0 0 .58-.8h-.69V-87.83a.67.67 0 0 0-.58-.8h-.69V-89.54h2.09a.67.67 0 0 0 .58-.8h-.69V-91.23a.67.67 0 0 0-.58-.8h-.69V-92.85h2.09a.67.67 0 0 0 .58-.8h-.69V-94.54a.67.67 0 0 0-.58-.8h-.69V-96.15h2.09a.67.67 0 0 0 .58-.8h-.69V-97.83a.67.67 0 0 0-.58-.8h-.69V-99.54h2.09a.67.67 0 0 0 .58-.8h-.69V-101.23a.67.67 0 0 0-.58-.8h-.69V-102.85h2.09a.67.67 0 0 0 .58-.8h-.69V-104.54a.67.67 0 0 0-.58-.8h-.69V-106.15h2.09a.67.67 0 0 0 .58-.8h-.69V-107.83a.67.67 0 0 0-.58-.8h-.69V-109.54h2.09a.67.67 0 0 0 .58-.8h-.69V-111.23a.67.67 0 0 0-.58-.8h-.69V-1112.85h2.09a.67.67 0 0 0 .58-.8h-.69V-1114.54a.67.67 0 0 0-.58-.8h-.69V-1116.15h2.09a.67.67 0 0 0 .58-.8h-.69V-1117.83a.67.67 0 0 0-.58-.8h-.69V-1119.54h2.09a.67.67 0 0 0 .58-.8h-.69V-1121.23a.67.67 0 0 0-.58-.8h-.69V-1122.85h2.09a.67.67 0 0 0 .58-.8h-.69V-1124.54a.67.67 0 0 0-.58-.8h-.69V-1126.15h2.09a.67.67 0 0 0 .58-.8h-.69V-1127.83a.67.67 0 0 0-.58-.8h-.69V-1129.54h2.09a.67.67 0 0 0 .58-.8h-.69V-1131.23a.67.67 0 0 0-.58-.8h-.69V-1132.85h2.09a.67.67 0 0 0 .58-.8h-.69V-1134.54a.67.67 0 0 0-.58-.8h-.69V-1136.15h2.09a.67.67 0 0 0 .58-.8h-.69V-1137.83a.67.67 0 0 0-.58-.8h-.69V-1139.54h2.09a.67.67 0 0 0 .58-.8h-.69V-1141.23a.67.67 0 0 0-.58-.8h-.69V-1142.85h2.09a.67.67 0 0 0 .58-.8h-.69V-1144.54a.67.67 0 0 0-.58-.8h-.69V-1146.15h2.09a.67.67 0 0 0 .58-.8h-.69V-1147.83a.67.67 0 0 0-.58-.8h-.69V-1149.54h2.09a.67.67 0 0 0 .58-.8h-.69V-1151.23a.67.67 0 0 0-.58-.8h-.69V-1152.85h2.09a.67.67 0 0 0 .58-.8h-.69V-1154.54a.67.67 0 0 0-.58-.8h-.69V-1156.15h2.09a.67.67 0 0 0 .58-.8h-.69V-1157.83a.67.67 0 0 0-.58-.8h-.69V-1159.54h2.09a.67.67 0 0 0 .58-.8h-.69V-1161.23a.67.67 0 0 0-.58-.8h-.69V-1162.85h2.09a.67.67 0 0 0 .58-.8h-.69V-1164.54a.67.67 0 0 0-.58-.8h-.69V-1166.15h2.09a.67.67 0 0 0 .58-.8h-.69V-1167.83a.67.67 0 0 0-.58-.8h-.69V-1169.54h2.09a.67.67 0 0 0 .58-.8h-.69V-1171.23a.67.67 0 0 0-.58-.8h-.69V-1172.85h2.09a.67.67 0 0 0 .58-.8h-.69V-1174.54a.67.67 0 0 0-.58-.8h-.69V-1176.15h2.09a.67.67 0 0 0 .58-.8h-.69V-1177.83a.67.67 0 0 0-.58-.8h-.69V-1179.54h2.09a.67.67 0 0 0 .58-.8h-.69V-1181.23a.67.67 0 0 0-.58-.8h-.69V-1182.85h2.09a.67.67 0 0 0 .58-.8h-.69V-1184.54a.67.67 0 0 0-.58-.8h-.69V-1186.15h2.09a.67.67 0 0 0 .58-.8h-.69V-187.83a.67.67 0 0 0-.58-.8h-.69V-189.54h2.09a.67.67 0 0 0 .58-.8h-.69V-191.23a.67.67 0 0 0-.58-.8h-.69V-192.85h2.09a.67.67 0 0 0 .58-.8h-.69V-194.54a.67.67 0 0 0-.58-.8h-.69V-196.15h2.09a.67.67 0 0 0 .58-.8h-.69V-197.83a.67.67 0 0 0-.58-.8h-.69V-199.54h2.09a.67.67 0 0 0 .58-.8h-.69V-201.23a.67.67 0 0 0-.58-.8h-.69V-202.85h2.09a.67.67 0 0 0 .58-.8h-.69V-204.54a.67.67 0 0 0-.58-.8h-.69V-206.15h2.09a.67.67 0 0 0 .58-.8h-.69V-207.83a.67.67 0 0 0-.58-.8h-.69V-209.54h2.09a.67.67 0 0 0 .58-.8h-.69V-211.23a.67.67 0 0 0-.58-.8h-.69V-212.85h2.09a.67.67 0 0 0 .58-.8h-.69V-214.54a.67.67 0 0 0-.58-.8h-.69V-216.15h2.09a.67.67 0 0 0 .58-.8h-.69V-217.83a.67.67 0 0 0-.58-.8h-.69V-219.54h2.09a.67.67 0 0 0 .58-.8h-.69V-221.23a.67.67 0 0 0-.58-.8h-.69V-222.85h2.09a.67.67 0 0 0 .58-.8h-.69V-224.54a.67.67 0 0 0-.58-.8h-.69V-226.15h2.09a.67.67 0 0 0 .58-.8h-.69V-227.83a.67.67 0 0 0-.58-.8h-.69V-229.54h2.09a.67.67 0 0 0 .58-.8h-.69V-231.23a.67.67 0 0 0-.58-.8h-.69V-232.85h2.09a.67.67 0 0 0 .58-.8h-.69V-234.54a.67.67 0 0 0-.58-.8h-.69V-236.15h2.09a.67.67 0 0 0 .58-.8h-.69V-237.83a.67.67 0 0 0-.58-.8h-.69V-239.54h2.09a.67.67 0 0 0 .58-.8h-.69V-241.23a.67.67 0 0 0-.58-.8h-.69V-242.85h2.09a.67.67 0 0 0 .58-.8h-.69V-244.54a.67.67 0 0 0-.58-.8h-.69V-246.15h2.09a.67.67 0 0 0 .58-.8h-.69V-247.83a.67.67 0 0 0-.58-.8h-.69V-249.54h2.09a.67.67 0 0 0 .58-.8h-.69V-251.23a.67.67 0 0 0-.58-.8h-.69V-252.85h2.09a.67.67 0 0 0 .58-.8h-.69V-254.54a.67.67 0 0 0-.58-.8h-.69V-256.15h2.09a.67.67 0 0 0 .58-.8h-.69V-257.83a.67.67 0 0 0-.58-.8h-.69V-259.54h2.09a.67.67 0 0 0 .58-.8h-.69V-261.23a.67.67 0 0 0-.58-.8h-.69V-262.85h2.09a.67.67 0 0 0 .58-.8h-.69V-264.54a.67.67 0 0 0-.58-.8h-.69V-266.15h2.09a.67.67 0 0 0 .58-.8h-.69V-267.83a.67.67 0 0 0-.58-.8h-.69V-269.54h2.09a.67.67 0 0 0 .58-.8h-.69V-271.23a.67.67 0 0 0-.58-.8h-.69V-272.85h2.09a.67.67 0 0 0 .58-.8h-.69V-274.54a.67.67 0 0 0-.58-.8h-.69V-276.15h2.09a.67.67 0 0 0 .58-.8h-.69V-277.83a.67.67 0 0 0-.58-.8h-.69V-279.54h2.09a.67.67 0 0 0 .58-.8h-.69V-281.23a.67.67 0 0 0-.58-.8h-.69V-282.85h2.09a.67.67 0 0 0 .58-.8h-.69V-284.54a.67.67 0 0 0-.58-.8h-.69V-286.15h2.09a.67.67 0 0 0 .58-.8h-.69V-287.83a.67.67 0 0 0-.58-.8h-.69V-289.54h2.09a.67.67 0 0 0 .58-.8h-.69V-291.23a.67.67 0 0 0-.58-.8h-.69V-292.85h2.09a.67.67 0 0 0 .58-.8h-.69V-294.54a.67.67 0 0 0-.58-.8h-.69V-296.15h2.09a.67.67 0 0 0 .58-.8h-.69V-297.83a.67.67 0 0 0-.58-.8h-.69V-299.54h2.09a.67.67 0 0 0 .58-.8h-.69V-301.23a.67.67 0 0 0-.58-.8h-.69V-302.85h2.09a.67.67 0 0 0 .58-.8h-.69V-304.54a.67.67 0 0 0-.58-.8h-.69V-306.15h2.09a.67.67 0 0 0 .58-.8h-.69V-307.83a.67.67 0 0 0-.58-.8h-.69V-309.54h2.09a.67.67 0 0 0 .58-.8h-.69V-311.23a.67.67 0 0 0-.58-.8h-.69V-312.85h2.09a.67.67 0 0 0 .58-.8h-.69V-314.54a.67.67 0 0 0-.58-.8h-.69V-316.15h2.09a.67.67 0 0 0 .58-.8h-.69V-317.83a.67.67 0 0 0-.58-.8h-.69V-319.54h2.09a.67.67 0 0 0 .58-.8h-.69V-321.23a.67.67 0 0 0-.58-.8h-.69V-322.85h2.09a.67.67 0 0 0 .58-.8h-.69V-324.54a.67.67 0 0 0-.58-.8h-.69V-326.15h2.09a.67.67 0 0 0 .58-.8h-.69V-327.83a.67.67 0 0 0-.58-.8h-.69V-329.54h2.09a.67.67 0 0 0 .58-.8h-.69V-331.23a.67.67 0 0 0-.58-.8h-.69V-332.85h2.09a.67.67 0 0 0 .58-.8h-.69V-334.54a.67.67 0 0 0-.58-.8h-.69V-336.15h2.09a.67.67 0 0 0 .58-.8h-.69V-337.83a.67.67 0 0 0-.58-.8h-.69V-339.54h2.09a.67.67 0 0 0 .58-.8h-.69V-341.23a.67.67 0 0 0-.58-.8h-.69V-342.85h2.09a.67.67 0 0 0 .58-.8h-.69V-344.54a.67.67 0 0 0-.58-.8h-.69V-346.15h2.09a.67.67 0 0 0 .58-.8h-.69V-347.83a.67.67 0 0 0-.58-.8h-.69V-349.54h2.09a.67.67 0 0 0 .58-.8h-.69V-351.23a.67.67 0 0 0-.58-.8h-.69V-352.85h2.09a.67.67 0 0 0 .58-.8h-.69V-354.54a.67.67 0 0 0-.58-.8h-.69V-356.15h2.09a.67.67 0 0 0 .58-.8h-.69V-357.83a.67.67 0 0 0-.58-.8h-.69V-359.54h2.09a.67.67 0 0 0 .58-.8h-.69V-361.23a.67.67 0 0 0-.58-.8h-.69V-362.85h2.09a.67.67 0 0 0 .58-.8h-.69V-364.54a.67.67 0 0 0-.58-.8h-.69V-366.15h2.09a.67.67 0 0 0 .58-.8h-.69V-367.83a.67.67 0 0 0-.58-.8h-.69V-369.54h2.09a.67.67 0 0 0 .58-.8h-.69V-371.23a.67.67 0 0 0-.58-.8h-.69V-372.85h2.09a.67.67 0 0 0 .58-.8h-.69V-374.54a.67.67 0 0 0-.58-.8h-.69V-376.15h2.09a.67.67 0 0 0 .58-.8h-.69V-377.83a.67.67 0 0 0-.58-.8h-.69V-379.54h2.09a.67.67 0 0 0 .58-.8h-.69V-381.23a.67.67 0 0 0-.58-.8h-.69V-382.85h2.09a.67.67 0 0 0 .58-.8h-.69V-384.54a.67.67 0 0 0-.58-.8h-.69V-386.15h2.09a.67.67 0 0 0 .58-.8h-.69V-387.83a.67.67 0 0 0-.58-.8h-.69V-389.54h2.09a.67.67 0 0 0 .58-.8h-.69V-391.23a.67.67 0 0 0-.58-.8h-.69V-392.85h2.09a.67.67 0 0 0 .58-.8h-.69V-394.54a.67.67 0 0 0-.58-.8h-.69V-396.15h2.09a.67.67 0 0 0 .58-.8h-.69V-397.83a.67.67 0 0 0-.58-.8h-.69V-399.54h2.09a.67.67 0 0 0 .58-.8h-.69V-401.23a.67.67 0 0 0-.58-.8h-.69V-402.85h2.09a.67.67 0 0 0 .58-.8h-.69V-404.54a.67.67 0 0 0-.58-.8h-.69V-406.15h2.09a.67.67 0 0 0 .58-.8h-.69V-407.83a.67.67 0 0 0-.58-.8h-.69V-409.54h2.09a.67.67 0 0 0 .58-.8h-.69V-411.23a.67.67 0 0 0-.58-.8h-.69V-412.85h2.09a.67.67 0 0 0 .58-.8h-.69V-414.54a.67.67 0 0 0-.58-.8h-.69V-416.15h2.09a.67.67 0 0 0 .58-.8h-.69V-417.83a.67.67 0 0 0-.58-.8h-.69V-419.54h2.09a.67.67 0 0 0 .58-.8h-.69V-421.23a.67.67 0 0 0-.58-.8h-.69V-422.85h2.09a.67.67 0 0 0 .58-.8h-.69V-424.54a.67.67 0 0 0-.58-.8h-.69V-426.15h2.09a.67.67 0 0 0 .58-.8h-.69V-427.83a.67.67 0 0 0-.58-.8h-.69V-429.54h2.09a.67.67 0 0 0 .58-.8h-.69V-431.23a.67.67 0 0 0-.58-.8h-.69V-432.85h2.09a.67.67 0 0 0 .58-.8h-.69V-434.54a.67.67 0 0 0-.58-.8h-.69V-436.15h2.09a.67.67 0 0 0 .58-.8h-.69V-437.83a.67.67 0 0 0-.58-.8h-.69V-439.54h2.09a.67.67 0 0 0 .58-.8h-.69V-441.23a.67.67 0 0 0-.58-.8h-.69V-442.85h2.09a.67.67 0 0 0 .58-.8h-.69V-444.54a.67.67 0 0 0-.58-.8h-.69V-446.15h2.09a.67.67 0 0 0 .58-.8h-.69V-447.83a.67.67 0 0 0-.58-.8h-.69V-449.54h2.09a.67.67 0 0 0 .58-.8h-.69V-451.23a.67.67 0 0 0-.58-.8h-.69V-452.85h2.09a.67.67 0 0 0 .58-.8h-.69V-454.54a.67.67 0 0 0-.58-.8h-.69V-456.15h2.09a.67.67 0 0 0 .58-.8h-.69V-457.83a.67.67 0 0 0-.58-.8h-.69V-459.54h2.09a.67.67 0 0 0 .58-.8h-.69V-461.23a.67.67 0 0 0-.58-.8h-.69V-462.85h2.09a.67.67 0 0 0 .58-.8h-.69V-464.54a.67.67 0 0 0-.58-.8h-.69V-466.15h2.09a.67.67 0 0 0 .58-.8h-.69V-467.83a.67.67 0 0 0-.58-.8h-.69V-469.54h2.09a.67.67 0 0 0 .58-.8h-.69V-471.23a.67.67 0 0 0-.58-.8h-.69V-472.85h2.09a.67.67 0 0 0 .58-.8h-.69V-474.54a.67.67 0 0 0-.58-.8h-.69V-476.15h2.09a.67.67 0 0 0 .58-.8h-.69V-477.83a.67.67 0 0 0-.58-.8h-.69V-479.54h2.09a.67.67 0 0 0 .58-.8h-.69V-481.23a.67.67 0 0 0-.58-.8h-.69V-482.85h2.09a.67.67 0 0 0 .58-.8h-.69V-484.54a.67.67 0 0 0-.58-.8h-.69V-486.15h2.09a.67.67 0 0 0 .58-.8h-.69V-487.83a.67.67 0 0 0-.58-.8h-.69V-489.54h2.09a.67.67 0 0 0 .58-.8h-.69V-491.23a.67.67 0 0 0-.58-.8h-.69V-492.85h2.09a.67.67 0 0 0 .58-.8h-.69V-494.54a.67.67 0 0 0-.58-.8h-.69V-496.15h2.09a.67.67 0 0 0 .58-.8h-.69V-497.83a.67.67 0 0 0-.58-.8h-.69V-499.54h2.09a.67.67 0 0 0 .58-.8h-.69V-501.23a.67.67 0 0 0-.58-.8h-.69V-502.85h2.09a.67.67 0 0 0 .58-.8h-.69V-504.54a.67.67 0 0 0-.58-.8h-.69V-506.15h2.09a.67.67 0 0 0 .58-.8h-.69V-507.83a.67.67 0 0 0-.58-.8h-.69V-509.54h2.09a.67.67 0 0 0 .58-.8h-.69V-511.23a.67.67 0 0 0-.58-.8h-.69V-512.85h2.09a.67.67 0 0 0 .58-.8h-.69V-514.54a.67.67 0 0 0-.58-.8h-.69V-516.15h2.09a.67.67 0 0 0 .58-.8h-.69V-517.83a.67.67 0 0 0-.58-.8h-.69V-519.54h2.09a.67.67 0 0 0 .58-.8h-.69V-521.23a.67.67 0 0 0-.58-.8h-.69V-522.85h2.09a.67.67 0 0 0 .58-.8h-.69V-524.54a.67.67 0 0 0-.58-.8h-.69V-526.15h2.09a.67.67 0 0 0 .58-.8h-.69V-527.83a.67.67 0 0 0-.58-.8h-.69V-529.54h2.09a.67.67 0 0 0 .58-.8h-.69V-531.23a.67.67 0 0 0-.58-.8h-.69V-532.85h2.09a.67.67 0 0 0 .58-.8h-.69V-534.54a.67.67 0 0 0-.58-.8h-.69V-536.15h2.09a.67.67 0 0 0 .58-.8h-.69V-537.83a.67.67 0 0 0-.58-.8h-.69V-539.54h2.09a.67.67 0 0 0 .58-.8h-.69V-541.23a.67.67 0 0 0-.58-.8h-.69V-542.85h2.09a.67.67 0 0 0 .58-.8h-.69V-544.54a.67.67 0 0 0-.58-.8h-.69V-546.15h2.09a.67.67 0 0 0 .58-.8h-.69V-547.83a.67.67 0 0 0-.58-.8h-.69V-549.54h2.09a.67.67 0 0 0 .58-.8h-.69V-551.23a.67.67 0 0 0-.58-.8h-.69V-552.85h2.09a.67.67 0 0 0 .58-.8h-.69V-554.54a.67.67 0 0 0-.58-.8h-.69V-556.15h2.09a.67.67 0 0 0 .58-.8h-.69V-557.83a.67.67 0 0 0-.58-.8h-.69V-559.54h2.09a.67.67 0 0 0 .58-.8h-.69V-561.23a.67.67 0 0 0-.58-.8h-.69V-562.85h2.09a.67.67 0 0 0 .58-.8h-.69V-564.54a.67.67 0 0 0-.58-.8h-.69V-566.15h2.09a.67.67 0 0 0 .58-.8h-.69V-567.83a.67.67 0 0 0-.58-.8h-.69V-569.54h2.0</svg>
                        Meus Endereços Bitcoin
                    </h3>
                    <?php if (!empty($user_bitcoin_addresses)): ?>
                        <ul class="bitcoin-addresses-list">
                            <?php foreach ($user_bitcoin_addresses as $address): ?>
                                <li>
                                    <div class="address-details">
                                        <strong>Endereço:</strong> <?= htmlspecialchars($address['ds_endereco']) ?>
                                        <?php if (!empty($address['ds_rotulo'])): ?>
                                            <br><small>(Rótulo: <?= htmlspecialchars($address['ds_rotulo']) ?>)</small>
                                        <?php endif; ?>
                                        <br><small>Criado em: <?= htmlspecialchars(date('d/m/Y H:i', strtotime($address['dt_criacao']))) ?></small>
                                    </div>
                                    <button class="copy-button" onclick="copyToClipboard('<?= htmlspecialchars($address['ds_endereco']) ?>')">Copiar</button>
                                    <button class="qr-code-button" onclick="showQrCodeModal('<?= htmlspecialchars($address['ds_qr_code']) ?>', '<?= htmlspecialchars($address['ds_endereco']) ?>')">Ver QR Code</button>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <p>Nenhum endereço Bitcoin cadastrado. Crie um para começar a receber Bitcoin!</p>
                    <?php endif; ?>

                    <div class="generate-bitcoin-button-container">
                        <form action="dashboard.php" method="POST">
                            <input type="hidden" name="action" value="generate_bitcoin_address">
                            <button type="submit" class="button">
                                Gerar Novo Endereço Bitcoin
                            </button>
                        </form>
                    </div>
                </div>


                <!-- Seção de Ações Rápidas -->
                <div class="dashboard-section actions-section" style="grid-column: 1 / -1;">
                    <h3>
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-zap"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
                        Ações Rápidas
                    </h3>
                    <div class="actions-grid">
                        <a href="deposit_withdraw.php" class="button primary">Depositar / Sacar</a>
                        <a href="my_cards.php" class="button primary">Meus Cartões</a>
                        <a href="transaction_history.php" class="button primary">Histórico de Transações</a>
                        <a href="transfer.php" class="button primary">Fazer Transferência</a>
                        <a href="pix_scheduling.php" class="button primary">Agendar PIX</a>
                        <a href="pix_refund.php" class="button primary">Estorno PIX (Funcionalidade)</a>
                        <!-- O botão "Receber Bitcoin" agora está integrado com a nova seção -->
                    </div>
                </div>
            </div>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>

    <!-- Custom Modal for Confirmations and Notifications -->
    <div id="customModal" class="modal" style="display: none;">
        <div class="modal-content">
            <h3 id="modalMessage"></h3>
            <div id="modalQrCodeContainer" style="display: none;">
                <img id="modalQrCodeImage" src="" alt="QR Code" style="max-width: 200px; height: auto; margin: 15px auto; display: block;">
                <p id="modalQrCodeText" style="word-break: break-all; font-size: 0.9em;"></p>
            </div>
            <div class="modal-buttons">
                <button class="button confirm" id="modalConfirmBtn">Confirmar</button>
                <button class="button cancel" id="modalCancelBtn">Cancelar</button>
            </div>
        </div>
    </div>

    <script>
        // Função para copiar texto para a área de transferência
        function copyToClipboard(text) {
            const tempInput = document.createElement('input');
            tempInput.value = text;
            document.body.appendChild(tempInput);
            tempInput.select();
            tempInput.setSelectionRange(0, 99999);
            document.execCommand('copy');
            document.body.removeChild(tempInput);
            showNotification('Copiado para a área de transferência: ' + text, 'success');
        }

        // --- Sistema de Notificação/Alerta Personalizado ---
        let currentModalCallback = null;

        function showNotification(message, type = 'info') {
            const modal = document.getElementById('customModal');
            const modalMessage = document.getElementById('modalMessage');
            const modalConfirmBtn = document.getElementById('modalConfirmBtn');
            const modalCancelBtn = document.getElementById('modalCancelBtn');
            const modalQrCodeContainer = document.getElementById('modalQrCodeContainer');

            modalMessage.textContent = message;
            modalConfirmBtn.style.display = 'none'; // Esconde o botão de confirmação para notificação simples
            modalCancelBtn.textContent = 'OK'; // Muda o texto do botão "Cancelar" para "OK"
            modalCancelBtn.onclick = hideModal; // Fecha o modal ao clicar em OK
            modalQrCodeContainer.style.display = 'none'; // Esconde elementos do QR code
            modal.classList.remove('qr-modal'); // Remove a classe específica para modal de QR

            currentModalCallback = null; // Limpa o callback
            modal.style.display = 'flex';
        }

        // --- Modal Personalizado para Confirmações ---
        function showModal(message, confirmCallback) {
            const modal = document.getElementById('customModal');
            const modalMessage = document.getElementById('modalMessage');
            const modalConfirmBtn = document.getElementById('modalConfirmBtn');
            const modalCancelBtn = document.getElementById('modalCancelBtn');
            const modalQrCodeContainer = document.getElementById('modalQrCodeContainer');


            modalMessage.textContent = message;
            currentModalCallback = confirmCallback;

            modalConfirmBtn.style.display = 'inline-block'; // Mostra o botão de confirmação para confirmação real
            modalCancelBtn.textContent = 'Cancelar'; // Restaura o texto do botão "Cancelar"
            modalQrCodeContainer.style.display = 'none'; // Esconde elementos do QR code
            modal.classList.remove('qr-modal'); // Garante que a classe de modal de QR seja removida
            
            modalConfirmBtn.onclick = function() {
                hideModal();
                if (currentModalCallback) {
                    currentModalCallback(true);
                }
            };

            modalCancelBtn.onclick = function() {
                hideModal();
                if (currentModalCallback) {
                    currentModalCallback(false);
                }
            };

            modal.style.display = 'flex'; // Mostra o modal
        }

        function hideModal() {
            const modal = document.getElementById('customModal');
            modal.style.display = 'none'; // Esconde o modal
            currentModalCallback = null; // Limpa o callback
        }

        // Função para mostrar o modal do QR Code
        function showQrCodeModal(qrCodeImageUrl, addressText) {
            const modal = document.getElementById('customModal');
            const modalMessage = document.getElementById('modalMessage');
            const modalQrCodeContainer = document.getElementById('modalQrCodeContainer');
            const modalQrCodeImage = document.getElementById('modalQrCodeImage');
            const modalQrCodeText = document.getElementById('modalQrCodeText');
            const modalConfirmBtn = document.getElementById('modalConfirmBtn');
            const modalCancelBtn = document.getElementById('modalCancelBtn');

            modalMessage.textContent = "QR Code para: " + addressText;
            modalQrCodeImage.src = qrCodeImageUrl;
            modalQrCodeText.textContent = "Endereço: " + addressText;
            
            modalQrCodeContainer.style.display = 'block'; // Mostra elementos do QR code
            modalConfirmBtn.style.display = 'none'; // Esconde o botão de confirmação
            modalCancelBtn.textContent = 'Fechar'; // Muda o texto do botão
            modalCancelBtn.onclick = hideModal; // Define a função de fechar

            modal.classList.add('qr-modal'); // Adiciona classe específica para estilização de modal de QR, se necessário
            modal.style.display = 'flex';
        }


        // Função para mostrar o modal de confirmação de exclusão da chave PIX
        function showDeleteModal(keyId) {
            console.log("Tentando excluir chave com ID:", keyId); // Debugging: Verifica se o keyId está correto
            showModal("Tem certeza que deseja excluir esta chave PIX? Esta ação não pode ser desfeita.", function(confirmed) {
                if (confirmed) {
                    console.log("Confirmação recebida para excluir chave com ID:", keyId); // Debugging: Confirmação
                    // Cria um formulário programaticamente e o envia
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = 'dashboard.php';

                    const actionInput = document.createElement('input');
                    actionInput.type = 'hidden';
                    actionInput.name = 'action';
                    actionInput.value = 'delete_pix_key';
                    form.appendChild(actionInput);

                    const keyIdInput = document.createElement('input');
                    keyIdInput.type = 'hidden';
                    keyIdInput.name = 'key_id';
                    keyIdInput.value = keyId; 
                    form.appendChild(keyIdInput);

                    document.body.appendChild(form);
                    form.submit();
                } else {
                    console.log("Exclusão de chave PIX cancelada para ID:", keyId); // Debugging: Cancelamento
                }
            });
        }

        // Função para definir uma chave PIX como principal
        function setPixKeyAsPrincipal(keyId) {
            console.log("Tentando definir chave principal com ID:", keyId);
            showModal("Tem certeza que deseja definir esta chave PIX como principal? A chave principal anterior será desativada.", function(confirmed) {
                if (confirmed) {
                    console.log("Confirmação recebida para definir chave principal com ID:", keyId);
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = 'dashboard.php';

                    const actionInput = document.createElement('input');
                    actionInput.type = 'hidden';
                    actionInput.name = 'action';
                    actionInput.value = 'set_pix_key_as_principal';
                    form.appendChild(actionInput);

                    const keyIdInput = document.createElement('input');
                    keyIdInput.type = 'hidden';
                    keyIdInput.name = 'key_id';
                    keyIdInput.value = keyId; 
                    form.appendChild(keyIdInput);

                    document.body.appendChild(form);
                    form.submit();
                } else {
                    console.log("Operação de definir chave PIX principal cancelada para ID:", keyId);
                }
            });
        }

        // JavaScript para controlar a visibilidade do campo de valor da chave PIX
        function handlePixKeyTypeChange() {
            const pixKeyTypeSelect = document.getElementById('pix_key_type');
            const pixKeyValueGroup = document.getElementById('pix_key_value_group');
            const pixKeyValueInput = document.getElementById('pix_key_value');
            const selectedType = pixKeyTypeSelect.value;

            // Reinicia os atributos para evitar conflitos
            pixKeyValueInput.value = '';
            pixKeyValueInput.removeAttribute('required');
            pixKeyValueInput.removeAttribute('maxlength');
            pixKeyValueInput.type = 'text'; // Define o tipo padrão como texto

            if (selectedType === 'Aleatória' || selectedType === '') {
                pixKeyValueGroup.style.display = 'none';
            } else {
                pixKeyValueGroup.style.display = 'block';
                pixKeyValueInput.setAttribute('required', 'required');
                
                if (selectedType === 'CPF') {
                    pixKeyValueInput.placeholder = 'Digite o CPF (somente números)';
                    pixKeyValueInput.setAttribute('maxlength', '11');
                } else if (selectedType === 'CNPJ') {
                    pixKeyValueInput.placeholder = 'Digite o CNPJ (somente números)';
                    pixKeyValueInput.setAttribute('maxlength', '14');
                } else if (selectedType === 'Email') {
                    pixKeyValueInput.placeholder = 'Digite o e-mail';
                    pixKeyValueInput.type = 'email'; 
                } else if (selectedType === 'Telefone') {
                    pixKeyValueInput.placeholder = 'Digite o telefone (somente números com DDD)';
                    pixKeyValueInput.setAttribute('maxlength', '11'); // Assumindo DDD + 8 ou 9 dígitos
                    pixKeyValueInput.type = 'tel'; // Tipo 'tel' para teclados numéricos em mobile
                }
            }
        }

        // Chama a função ao carregar a página para definir o estado inicial
        document.addEventListener('DOMContentLoaded', handlePixKeyTypeChange);
    </script>
</body>
</html>
