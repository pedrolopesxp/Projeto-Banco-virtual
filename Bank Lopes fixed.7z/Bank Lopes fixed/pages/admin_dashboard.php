<?php
// www/pages/admin_dashboard.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

// Verifica se o administrador está logado. Se não, redireciona para a página de login do admin.
if (!isset($_SESSION['admin_id'])) {
    set_message("Você precisa estar logado como administrador para acessar esta área.", "error");
    redirect('admin_login.php');
}

$admin_id = $_SESSION['admin_id'];
$admin_name = htmlspecialchars($_SESSION['admin_name'] ?? 'Administrador');
$admin_level = htmlspecialchars($_SESSION['admin_level'] ?? 'Nível Desconhecido');

// --- Dados para o Dashboard ---
// As consultas ao banco de dados são realizadas aqui para popular os cards e tabelas.

// Total de Usuários
try {
    $stmt_total_users = $pdo->query("SELECT COUNT(*) FROM tb_usuario");
    $total_users = $stmt_total_users->fetchColumn();
} catch (PDOException $e) {
    error_log("Erro ao buscar total de usuários: " . $e->getMessage());
    $total_users = "Erro";
}

// Saldo Total de Bitcoin (soma de todas as contas)
try {
    $stmt_total_btc = $pdo->query("SELECT SUM(vl_saldo_bitcoin) FROM tb_conta");
    $total_bitcoin_balance = number_format($stmt_total_btc->fetchColumn(), 8, ',', '.');
} catch (PDOException | TypeError $e) { // Adicionado TypeError para lidar com retornos nulos de SUM
    error_log("Erro ao buscar saldo total BTC: " . $e->getMessage());
    $total_bitcoin_balance = "0.00000000"; // Define um valor padrão se houver erro ou resultado nulo
}


// Saldo Total em Reais (soma de todas as contas)
try {
    $stmt_total_brl = $pdo->query("SELECT SUM(vl_saldo_real) FROM tb_conta");
    $total_real_balance = number_format($stmt_total_brl->fetchColumn(), 2, ',', '.');
} catch (PDOException | TypeError $e) { // Adicionado TypeError para lidar com retornos nulos de SUM
    error_log("Erro ao buscar saldo total BRL: " . $e->getMessage());
    $total_real_balance = "0.00"; // Define um valor padrão se houver erro ou resultado nulo
}


// Últimas 5 Transações (qualquer tipo)
try {
    $stmt_transactions = $pdo->query("SELECT tp_tipo, tp_metodo_pagamento, vl_quantidade_real, vl_quantidade_bitcoin, ds_status, dt_transacao FROM tb_transacao ORDER BY dt_transacao DESC LIMIT 5");
    $latest_transactions = $stmt_transactions->fetchAll();
} catch (PDOException $e) {
    error_log("Erro ao buscar últimas transações: " . $e->getMessage());
    $latest_transactions = [];
}

// Últimos 5 Registros de Usuários
try {
    $stmt_new_users = $pdo->query("SELECT nm_usuario, ds_email, dt_cadastro FROM tb_usuario ORDER BY dt_cadastro DESC LIMIT 5");
    $latest_new_users = $stmt_new_users->fetchAll();
} catch (PDOException $e) {
    error_log("Erro ao buscar últimos usuários: " . $e->getMessage());
    $latest_new_users = [];
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .admin-dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 30px;
            margin-top: 30px;
        }
        .admin-card {
            background-color: var(--secondary-color);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            text-align: center;
        }
        .admin-card h3 {
            color: var(--primary-dark-color);
            margin-bottom: 15px;
            font-size: 1.8em;
        }
        .admin-card .value {
            font-size: 2.5em;
            font-weight: bold;
            color: var(--primary-color);
        }
        .admin-list-container {
            grid-column: 1 / -1; /* Ocupa todas as colunas disponíveis */
            background-color: var(--secondary-color);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            margin-top: 30px; /* Adicionado para espaçamento */
        }
        .admin-list-container h3 {
            text-align: left;
            margin-bottom: 20px;
            font-size: 1.6em;
            color: var(--primary-dark-color);
        }
        .admin-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .admin-table th, .admin-table td {
            border: 1px solid var(--border-color);
            padding: 12px;
            text-align: left;
            font-size: 0.95em;
        }
        .admin-table th {
            background-color: var(--light-gray);
            font-weight: bold;
            color: var(--text-color);
        }
        .admin-table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .admin-table tbody tr:hover {
            background-color: #eef;
        }
        .admin-actions {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            margin-top: 50px;
        }
        .admin-actions .button {
            padding: 15px 25px;
            font-size: 1.1em;
            border-radius: 10px;
            text-decoration: none;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.2s ease;
            box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
            background-color: var(--primary-color);
            color: var(--secondary-color);
            border: none;
            cursor: pointer;
        }
        .admin-actions .button:hover {
            background-color: var(--primary-dark-color);
            transform: translateY(-2px);
        }

        @media (max-width: 768px) {
            .admin-card, .admin-list-container {
                padding: 20px;
            }
            .admin-card .value {
                font-size: 2em;
            }
            .admin-actions .button {
                width: 100%;
                text-align: center;
            }
            .admin-table th, .admin-table td {
                padding: 8px; /* Ajuste para telas menores */
                font-size: 0.9em;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Bank Lopes</div>
            <nav>
                <ul>
                    <li><a href="admin_dashboard.php">Dashboard Admin</a></li>
                    <li>Olá, Admin <?= $admin_name ?> (Nível: <?= $admin_level ?>)</li>
                    <li><a href="logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="form-container"> <!-- Reutilizando form-container para centralizar e estilizar -->
            <h2>Dashboard Administrativo</h2>
            <?php display_messages(); ?>

            <div class="admin-dashboard-grid">
                <div class="admin-card">
                    <h3>Total de Usuários</h3>
                    <p class="value"><?= $total_users ?></p>
                </div>
                <div class="admin-card">
                    <h3>Saldo Total em Bitcoin</h3>
                    <p class="value"><?= $total_bitcoin_balance ?> BTC</p>
                </div>
                <div class="admin-card">
                    <h3>Saldo Total em Reais</h3>
                    <p class="value">R$ <?= $total_real_balance ?></p>
                </div>
            </div>

            <div class="admin-list-container">
                <h3>Últimas Transações</h3>
                <?php if (!empty($latest_transactions)): ?>
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Tipo</th>
                                <th>Método</th>
                                <th>Valor (R$)</th>
                                <th>Valor (BTC)</th>
                                <th>Status</th>
                                <th>Data</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($latest_transactions as $transaction): ?>
                                <tr>
                                    <td><?= htmlspecialchars($transaction['tp_tipo']) ?></td>
                                    <td><?= htmlspecialchars($transaction['tp_metodo_pagamento']) ?></td>
                                    <td><?= htmlspecialchars(number_format($transaction['vl_quantidade_real'], 2, ',', '.')) ?></td>
                                    <td><?= htmlspecialchars(number_format($transaction['vl_quantidade_bitcoin'], 8, ',', '.')) ?></td>
                                    <td><?= htmlspecialchars($transaction['ds_status']) ?></td>
                                    <td><?= htmlspecialchars(date('d/m/Y H:i', strtotime($transaction['dt_transacao']))) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>Nenhuma transação recente encontrada.</p>
                <?php endif; ?>
            </div>

            <div class="admin-list-container">
                <h3>Novos Usuários Registrados</h3>
                <?php if (!empty($latest_new_users)): ?>
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>E-mail</th>
                                <th>Data de Registro</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($latest_new_users as $user): ?>
                                <tr>
                                    <td><?= htmlspecialchars($user['nm_usuario']) ?></td>
                                    <td><?= htmlspecialchars($user['ds_email']) ?></td>
                                    <td><?= htmlspecialchars(date('d/m/Y H:i', strtotime($user['dt_cadastro']))) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>Nenhum usuário novo encontrado.</p>
                <?php endif; ?>
            </div>

            <div class="admin-actions">
                <a href="admin_manage_users.php" class="button">Gerenciar Usuários</a>
                <a href="admin_view_transactions.php" class="button">Ver Todas as Transações</a>
                <a href="admin_system_settings.php" class="button">Configurações do Sistema</a>
                <a href="admin_manage_fees.php" class="button">Gerenciar Taxas</a>
            </div>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>
</body>
</html>
