<?php
// www/pages/admin_manage_users.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

// Verifica se o administrador está logado. Se não, redireciona para a página de login do admin.
if (!isset($_SESSION['admin_id'])) {
    set_message("Você precisa estar logado como administrador para acessar esta área.", "error");
    redirect('admin_login.php');
}

$admin_name = htmlspecialchars($_SESSION['admin_name'] ?? 'Administrador');
$admin_level = htmlspecialchars($_SESSION['admin_level'] ?? 'Nível Desconhecido');

$users = [];
try {
    $stmt = $pdo->query("SELECT id_usuario, nm_usuario, ds_email, ds_cpf, ds_status, dt_cadastro FROM tb_usuario ORDER BY dt_cadastro DESC");
    $users = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Erro ao buscar usuários para gerenciamento: " . $e->getMessage());
    set_message("Ocorreu um erro ao carregar a lista de usuários.", "error");
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Usuários - Admin - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        /* Estilos específicos para esta página */
        .admin-table-container {
            background-color: var(--secondary-color);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
            margin-top: 40px;
        }
        .admin-table-container h2 {
            text-align: left;
            margin-bottom: 30px;
            color: var(--primary-dark-color);
            font-size: 2em;
        }
        .admin-table {
            width: 100%;
            border-collapse: collapse;
        }
        .admin-table th, .admin-table td {
            border: 1px solid var(--border-color);
            padding: 12px;
            text-align: left;
            font-size: 0.95em;
        }
        .admin-table th {
            background-color: var(--light-gray);
            font-weight: bold;
            color: var(--text-color);
        }
        .admin-table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .admin-table tbody tr:hover {
            background-color: #eef;
        }
        .action-buttons {
            display: flex;
            gap: 5px;
            justify-content: center; /* Centraliza botões se houver espaço */
        }
        .action-buttons .button {
            padding: 8px 12px;
            font-size: 0.85em;
            border-radius: 5px;
            text-decoration: none;
            font-weight: bold;
            transition: background-color 0.3s ease;
            border: none;
            cursor: pointer;
            white-space: nowrap; /* Evita quebra de linha em botões pequenos */
        }
        .action-buttons .button.view {
            background-color: #007bff; /* Azul */
            color: white;
        }
        .action-buttons .button.view:hover {
            background-color: #0056b3;
        }
        .action-buttons .button.edit {
            background-color: #ffc107; /* Amarelo */
            color: #333;
        }
        .action-buttons .button.edit:hover {
            background-color: #e0a800;
        }
        .action-buttons .button.delete {
            background-color: var(--danger-color); /* Vermelho */
            color: white;
        }
        .action-buttons .button.delete:hover {
            background-color: #c82333;
        }

        @media (max-width: 768px) {
            .admin-table th, .admin-table td {
                padding: 8px;
                font-size: 0.8em;
            }
            .action-buttons {
                flex-direction: column;
                align-items: center;
            }
            .action-buttons .button {
                width: 100%;
                margin-bottom: 5px;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Bank Lopes</div>
            <nav>
                <ul>
                    <li><a href="admin_dashboard.php">Dashboard Admin</a></li>
                    <li>Olá, Admin <?= $admin_name ?> (Nível: <?= $admin_level ?>)</li>
                    <li><a href="logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="form-container admin-table-container">
            <h2>Gerenciar Usuários</h2>
            <?php display_messages(); ?>

            <?php if (!empty($users)): ?>
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>E-mail</th>
                            <th>CPF</th>
                            <th>Status</th>
                            <th>Data de Cadastro</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?= htmlspecialchars($user['id_usuario']) ?></td>
                                <td><?= htmlspecialchars($user['nm_usuario']) ?></td>
                                <td><?= htmlspecialchars($user['ds_email']) ?></td>
                                <td><?= htmlspecialchars($user['ds_cpf']) ?></td>
                                <td><?= htmlspecialchars($user['ds_status']) ?></td>
                                <td><?= htmlspecialchars(date('d/m/Y H:i', strtotime($user['dt_cadastro']))) ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <a href="#" class="button view">Ver</a>
                                        <a href="#" class="button edit">Editar</a>
                                        <a href="#" class="button delete">Excluir</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>Nenhum usuário registrado.</p>
            <?php endif; ?>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>
</body>
</html>
