<?php
// www/pages/pix_scheduling.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

// Verifica se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    set_message("Você precisa estar logado para agendar PIX.", "error");
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$userName = htmlspecialchars($_SESSION['user_name'] ?? 'Usuário');

$agendamentos = [];
try {
    // Busca agendamentos PIX do usuário
    $stmt_agendamentos = $pdo->prepare("SELECT * FROM tb_pix_agendado WHERE id_usuario = ? ORDER BY dt_proxima_execucao DESC");
    $stmt_agendamentos->execute([$user_id]);
    $agendamentos = $stmt_agendamentos->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Erro ao buscar agendamentos PIX: " . $e->getMessage());
    set_message("Erro ao carregar seus agendamentos PIX. Por favor, tente novamente.", "error");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = trim(isset($_POST['action']) ? $_POST['action'] : '');

    if ($action === 'schedule_pix') {
        $chave_pix_destino = trim(isset($_POST['chave_pix_destino']) ? $_POST['chave_pix_destino'] : '');
        $tipo_chave_destino = trim(isset($_POST['tipo_chave_destino']) ? $_POST['tipo_chave_destino'] : '');
        $valor = floatval(str_replace(',', '.', trim(isset($_POST['valor']) ? $_POST['valor'] : '0')));
        $descricao_agendamento = trim(isset($_POST['descricao_agendamento']) ? $_POST['descricao_agendamento'] : '');
        $data_primeira_execucao = trim(isset($_POST['data_primeira_execucao']) ? $_POST['data_primeira_execucao'] : '');
        $hora_primeira_execucao = trim(isset($_POST['hora_primeira_execucao']) ? $_POST['hora_primeira_execucao'] : '');
        $frequencia = trim(isset($_POST['frequencia']) ? $_POST['frequencia'] : '');
        $data_fim_agendamento = trim(isset($_POST['data_fim_agendamento']) ? $_POST['data_fim_agendamento'] : '');

        $dt_primeira_execucao_full = $data_primeira_execucao . ' ' . $hora_primeira_execucao . ':00';
        $dt_proxima_execucao = $dt_primeira_execucao_full; // Na criação, a próxima é a primeira

        if ($data_fim_agendamento === '') {
            $data_fim_agendamento = null; // Se vazio, armazena como NULL no banco
        } else {
             $data_fim_agendamento .= ' 23:59:59'; // Para cobrir o dia todo se for apenas a data
        }

        if (empty($chave_pix_destino) || empty($tipo_chave_destino) || $valor <= 0 || empty($data_primeira_execucao) || empty($hora_primeira_execucao) || empty($frequencia)) {
            set_message("Por favor, preencha todos os campos obrigatórios para agendar o PIX.", "error");
        } elseif (strtotime($dt_primeira_execucao_full) < time()) {
             set_message("A data e hora da primeira execução deve ser no futuro.", "error");
        } elseif ($data_fim_agendamento && strtotime($data_fim_agendamento) < strtotime($dt_primeira_execucao_full)) {
             set_message("A data de término do agendamento não pode ser anterior à data de primeira execução.", "error");
        } else {
            try {
                $stmt_insert = $pdo->prepare("INSERT INTO tb_pix_agendado (id_usuario, ch_chave_pix_destino, tp_tipo_chave_destino, vl_valor, ds_descricao_agendamento, dt_primeira_execucao, tp_frequencia, dt_proxima_execucao, dt_fim_agendamento) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt_insert->execute([$user_id, $chave_pix_destino, $tipo_chave_destino, $valor, $descricao_agendamento, $dt_primeira_execucao_full, $frequencia, $dt_proxima_execucao, $data_fim_agendamento]);

                set_message("PIX agendado com sucesso!", "success");
                redirect('pix_scheduling.php'); // Recarrega a página para ver o novo agendamento
            } catch (PDOException $e) {
                error_log("Erro ao agendar PIX: " . $e->getMessage());
                set_message("Ocorreu um erro ao agendar o PIX. Por favor, tente novamente: " . $e->getMessage(), "error");
            }
        }
    } elseif ($action === 'cancel_scheduling') {
        $agendamento_id = intval(isset($_POST['agendamento_id']) ? $_POST['agendamento_id'] : 0);
        if ($agendamento_id > 0) {
            try {
                // Cancela o agendamento apenas se pertencer ao usuário logado e não estiver concluído/cancelado
                $stmt_cancel = $pdo->prepare("UPDATE tb_pix_agendado SET ds_status_agendamento = 'Cancelado' WHERE id_agendamento = ? AND id_usuario = ? AND ds_status_agendamento IN ('Ativo', 'Pausado')");
                if ($stmt_cancel->execute([$agendamento_id, $user_id]) && $stmt_cancel->rowCount() > 0) {
                    set_message("Agendamento cancelado com sucesso!", "success");
                } else {
                    set_message("Não foi possível cancelar o agendamento ou ele já está cancelado/concluído.", "error");
                }
            } catch (PDOException $e) {
                error_log("Erro ao cancelar agendamento PIX: " . $e->getMessage());
                set_message("Ocorreu um erro ao cancelar o agendamento. Por favor, tente novamente.", "error");
            }
        } else {
            set_message("Agendamento inválido.", "error");
        }
        redirect('pix_scheduling.php'); // Recarrega para ver o status atualizado
    }
}
// Re-busca agendamentos após POST
try {
    $stmt_agendamentos = $pdo->prepare("SELECT * FROM tb_pix_agendado WHERE id_usuario = ? ORDER BY dt_proxima_execucao DESC");
    $stmt_agendamentos->execute([$user_id]);
    $agendamentos = $stmt_agendamentos->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Erro ao re-buscar agendamentos PIX após POST: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendar PIX - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .scheduling-form-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }
        .scheduling-form-grid label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: var(--text-color);
        }
        .scheduling-form-grid input[type="text"],
        .scheduling-form-grid input[type="number"],
        .scheduling-form-grid input[type="date"],
        .scheduling-form-grid input[type="time"],
        .scheduling-form-grid select,
        .scheduling-form-grid textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-size: 1em;
            box-sizing: border-box;
        }
        .agendamento-list {
            list-style: none;
            padding: 0;
            margin-top: 30px;
        }
        .agendamento-item {
            background-color: var(--light-gray);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        .agendamento-item p {
            margin: 0;
            font-size: 0.95em;
        }
        .agendamento-item strong {
            color: var(--primary-dark-color);
        }
        .agendamento-item .status {
            font-weight: bold;
        }
        .agendamento-item .status.Ativo { color: #28a745; }
        .agendamento-item .status.Pausado { color: #ffc107; }
        .agendamento-item .status.Concluído { color: #6c757d; }
        .agendamento-item .status.Cancelado { color: #dc3545; }
        .agendamento-item .status.Falha { color: #fd7e14; }

        .agendamento-item .cancel-form {
            margin-top: 10px;
        }
        .agendamento-item .cancel-button {
            background-color: #dc3545;
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.2s ease;
        }
        .agendamento-item .cancel-button:hover {
            background-color: #c82333;
        }
        .agendamento-item .cancel-button:disabled {
            background-color: #cccccc;
            cursor: not-allowed;
        }

        @media (min-width: 600px) {
            .scheduling-form-grid {
                grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            }
            .scheduling-form-grid .full-width {
                grid-column: 1 / -1;
            }
            .agendamento-item {
                flex-direction: row;
                justify-content: space-between;
                align-items: center;
            }
            .agendamento-item > div {
                flex: 1;
            }
            .agendamento-item .cancel-form {
                margin-top: 0;
                flex-shrink: 0;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Bank Lopes</div>
            <nav>
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li>Olá, <?= $userName ?></li>
                    <li><a href="logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="form-container" style="max-width: 90%; text-align: left;">
            <h2>Agendar PIX</h2>
            <?php display_messages(); ?>

            <h3>Novo Agendamento</h3>
            <form action="pix_scheduling.php" method="POST">
                <input type="hidden" name="action" value="schedule_pix">
                <div class="scheduling-form-grid">
                    <div>
                        <label for="chave_pix_destino">Chave PIX do Destinatário:</label>
                        <input type="text" id="chave_pix_destino" name="chave_pix_destino" placeholder="Chave PIX (CPF, CNPJ, E-mail, Tel, Aleatória)" required>
                    </div>
                    <div>
                        <label for="tipo_chave_destino">Tipo de Chave:</label>
                        <select id="tipo_chave_destino" name="tipo_chave_destino" required>
                            <option value="">Selecione o Tipo</option>
                            <option value="CPF">CPF</option>
                            <option value="CNPJ">CNPJ</option>
                            <option value="E-mail">E-mail</option>
                            <option value="Telefone">Telefone</option>
                            <option value="Aleatória">Aleatória</option>
                        </select>
                    </div>
                    <div>
                        <label for="valor">Valor (R$):</label>
                        <input type="number" step="0.01" id="valor" name="valor" placeholder="Valor a agendar" required min="0.01">
                    </div>
                    <div class="full-width">
                        <label for="descricao_agendamento">Descrição (Opcional):</label>
                        <textarea id="descricao_agendamento" name="descricao_agendamento" rows="2" placeholder="Ex: Pagamento mensal, Boleto de luz, etc."></textarea>
                    </div>
                    <div>
                        <label for="data_primeira_execucao">Data da Primeira Execução:</label>
                        <input type="date" id="data_primeira_execucao" name="data_primeira_execucao" required>
                    </div>
                    <div>
                        <label for="hora_primeira_execucao">Hora da Primeira Execução:</label>
                        <input type="time" id="hora_primeira_execucao" name="hora_primeira_execucao" required>
                    </div>
                    <div>
                        <label for="frequencia">Frequência:</label>
                        <select id="frequencia" name="frequencia" required>
                            <option value="Única">Única</option>
                            <option value="Diário">Diário</option>
                            <option value="Semanal">Semanal</option>
                            <option value="Mensal">Mensal</option>
                            <option value="Anual">Anual</option>
                        </select>
                    </div>
                    <div>
                        <label for="data_fim_agendamento">Data de Término (Opcional):</label>
                        <input type="date" id="data_fim_agendamento" name="data_fim_agendamento">
                        <small>Deixe em branco para agendamentos contínuos ou únicos.</small>
                    </div>
                </div>
                <button type="submit" class="button primary">Agendar PIX</button>
            </form>

            <h3 style="margin-top: 40px;">Meus Agendamentos PIX</h3>
            <?php if (empty($agendamentos)): ?>
                <p>Nenhum agendamento PIX encontrado.</p>
            <?php else: ?>
                <ul class="agendamento-list">
                    <?php foreach ($agendamentos as $agendamento): ?>
                        <li class="agendamento-item">
                            <div>
                                <p><strong>Destino:</strong> <?= htmlspecialchars($agendamento['ch_chave_pix_destino']) ?> (<?= htmlspecialchars($agendamento['tp_tipo_chave_destino']) ?>)</p>
                                <p><strong>Valor:</strong> R$ <?= htmlspecialchars(number_format($agendamento['vl_valor'], 2, ',', '.')) ?></p>
                                <p><strong>Primeira Execução:</strong> <?= htmlspecialchars(date('d/m/Y H:i', strtotime($agendamento['dt_primeira_execucao']))) ?></p>
                                <p><strong>Próxima Execução:</strong> <?= htmlspecialchars(date('d/m/Y H:i', strtotime($agendamento['dt_proxima_execucao']))) ?></p>
                                <p><strong>Frequência:</strong> <?= htmlspecialchars($agendamento['tp_frequencia']) ?></p>
                                <?php if (!empty($agendamento['dt_fim_agendamento'])): ?>
                                    <p><strong>Término:</strong> <?= htmlspecialchars(date('d/m/Y', strtotime($agendamento['dt_fim_agendamento']))) ?></p>
                                <?php endif; ?>
                                <p><strong>Status:</strong> <span class="status <?= htmlspecialchars($agendamento['ds_status_agendamento']) ?>"><?= htmlspecialchars($agendamento['ds_status_agendamento']) ?></span></p>
                                <?php if (!empty($agendamento['ds_descricao_agendamento'])): ?>
                                    <p>Descrição: <small><?= htmlspecialchars($agendamento['ds_descricao_agendamento']) ?></small></p>
                                <?php endif; ?>
                            </div>
                            <div class="cancel-form">
                                <?php if ($agendamento['ds_status_agendamento'] === 'Ativo' || $agendamento['ds_status_agendamento'] === 'Pausado'): ?>
                                <form action="pix_scheduling.php" method="POST">
                                    <input type="hidden" name="action" value="cancel_scheduling">
                                    <input type="hidden" name="agendamento_id" value="<?= htmlspecialchars($agendamento['id_agendamento']) ?>">
                                    <button type="submit" class="cancel-button">Cancelar Agendamento</button>
                                </form>
                                <?php else: ?>
                                    <button type="button" class="cancel-button" disabled>Não Cancelável</button>
                                <?php endif; ?>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>

            <p style="margin-top: 30px;"><a href="dashboard.php">Voltar para o Dashboard</a></p>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>
</body>
</html>
