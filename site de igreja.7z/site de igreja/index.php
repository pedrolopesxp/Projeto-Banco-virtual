<?php
require_once 'inc/config.php';
$page_title = 'Início';
include 'inc/header.php';
?>

<section class="hero">
    <div class="container">
        <h1 class="fade-in-up">⭐ Igreja dos Anjos</h1>
        <p class="fade-in-up">Livros de orações virtuais para você enviar boas energias e pedir orações aos anjos para receber juventude, imortalidade e recuperar seus poderes e saúde para poder ajudar o mundo!</p>
        <div class="fade-in-up">
            <a href="pages/livros.php" class="btn btn-primary">Ver Livros de Orações</a>
            <a href="pages/orar.php" class="btn btn-secondary">Enviar Oração</a>
        </div>
    </div>
</section>

<section class="container">
    <div class="cards-grid">
        <div class="card fade-in-up">
            <h3>📚 Livros de Orações</h3>
            <p>Acesse nossa coleção completa de livros de orações virtuais, cada um dedicado a diferentes anjos e propósitos espirituais.</p>
            <a href="pages/livros.php" class="btn btn-primary">Explorar Livros</a>
        </div>
        
        <div class="card fade-in-up">
            <h3>🙏 Enviar Oração</h3>
            <p>Envie suas orações diretamente aos anjos. Peça por juventude, imortalidade, cura, proteção e força para ajudar o mundo.</p>
            <a href="pages/orar.php" class="btn btn-primary">Orar Agora</a>
        </div>
        
        <div class="card fade-in-up">
            <h3>✨ Testemunhos</h3>
            <p>Leia os testemunhos de pessoas que tiveram suas orações atendidas e compartilhe sua própria experiência.</p>
            <a href="pages/testemunhos.php" class="btn btn-primary">Ver Testemunhos</a>
        </div>
    </div>
</section>

<section class="container" style="padding: 4rem 0;">
    <div style="text-align: center; color: white; margin-bottom: 3rem;">
        <h2 style="font-size: 2.5rem; margin-bottom: 1rem;">Categorias de Orações</h2>
        <p style="font-size: 1.2rem;">Encontre a oração perfeita para sua necessidade</p>
    </div>
    
    <div class="prayer-categories">
        <div class="category-tag">👼 Anjos Guardiões</div>
        <div class="category-tag">💊 Cura e Saúde</div>
        <div class="category-tag">🌍 Paz Mundial</div>
        <div class="category-tag">👨‍👩‍👧‍👦 Família</div>
        <div class="category-tag">🛡️ Proteção</div>
        <div class="category-tag">🧠 Sabedoria</div>
        <div class="category-tag">👩 Anjos Femininos</div>
        <div class="category-tag">🌟 Juventude</div>
        <div class="category-tag">💪 Força</div>
        <div class="category-tag">💖 Amor</div>
        <div class="category-tag">💰 Prosperidade</div>
        <div class="category-tag">😇 Gratidão</div>
    </div>
</section>

<?php include 'inc/footer.php'; ?>