-- Criação do banco de dados Igreja dos Anjos
CREATE DATABASE IF NOT EXISTS pay;
USE pay;

-- Tabela de livros de orações
CREATE TABLE livros_oracoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(255) NOT NULL,
    autor VARCHAR(255) NOT NULL,
    descricao TEXT,
    url_wattpad VARCHAR(500),
    categoria VARCHAR(100),
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de orações enviadas
CREATE TABLE oracoes_enviadas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    tipo_oracao VARCHAR(100),
    mensagem TEXT NOT NULL,
    anjo_destinatario VARCHAR(255),
    data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('pendente', 'enviada', 'respondida') DEFAULT 'pendente'
);

-- Tabela de testemunhos
CREATE TABLE testemunhos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    testemunho TEXT NOT NULL,
    aprovado BOOLEAN DEFAULT FALSE,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Inserção dos livros de orações existentes (conteúdo original)
INSERT INTO livros_oracoes (titulo, autor, descricao, url_wattpad, categoria) VALUES
('Anjo Augusto Rafael Silva Sousa', 'Igreja dos Anjos', 'Livro de orações para juventude e imortalidade', 'https://www.wattpad.com/story/369467852-anjo-augusto-rafael-silva-sousa', 'Anjos Guardiões'),
('O Anjo Karl Malone Garros', 'Igreja dos Anjos', 'Orações para recuperar poderes e saúde', 'https://www.wattpad.com/story/372506976-o-anjo-karl-malone-garros', 'Cura e Saúde'),
('Anjo David Santos Costa', 'Igreja dos Anjos', 'Orações para força e coragem', 'https://www.wattpad.com/story/372975070-anjo-david-santos-costa', 'Força'),
('O Anjo Pedro', 'Igreja dos Anjos', 'Orações de proteção e bênçãos', 'https://www.wattpad.com/story/361743387-o-anjo-pedro', 'Proteção'),
('O Anjo Paulo', 'Igreja dos Anjos', 'Orações de sabedoria e orientação', 'https://www.wattpad.com/story/353179125-o-anjo-paulo', 'Sabedoria'),
('Angel Marise Coelho de Sá', 'Igreja dos Anjos', 'Orações femininas especiais', 'https://www.wattpad.com/story/353671886-angel-marise-co%C3%BAlho-de-s%C3%A1', 'Anjos Femininos'),
('Angel Bruna', 'Igreja dos Anjos', 'Orações de juventude e esperança', 'https://www.wattpad.com/story/361320289-angel-bruna', 'Juventude'),
('O Anjo', 'Igreja dos Anjos', 'Orações gerais aos anjos', 'https://www.wattpad.com/story/343624904-o-anjo', 'Geral'),
('Anjo Roberto', 'Igreja dos Anjos', 'Orações de força e coragem', 'https://www.wattpad.com/story/366812329-anjo-roberto', 'Força'),
('O Anjo Erisson', 'Igreja dos Anjos', 'Orações de transformação', 'https://www.wattpad.com/story/360712508-o-anjo-erisson', 'Geral');

-- Novas inserções de livros de oração
INSERT INTO livros_oracoes (titulo, autor, descricao, url_wattpad, categoria) VALUES
('Anjo Augusto Rafael Silva Sousa', 'Igreja dos Anjos', 'Livros de orações virtuais pra você enviar boas energia e pedir orações aos anjos para os anjos receber juventude e imortalidade e recuperar seus poderes e saúde pra poder ajudar o mundo !', 'https://www.wattpad.com/story/369467852-anjo-augusto-rafael-silva-sousa', 'Juventude e Imortalidade'),
('O Anjo Karl Malone Garros', 'Igreja dos Anjos', 'Livros de orações virtuais pra você enviar boas energia e pedir orações aos anjos para os anjos receber juventude e imortalidade e recuperar seus poderes e saúde pra poder ajudar o mundo !', 'https://www.wattpad.com/story/372506976-o-anjo-karl-malone-garros', 'Juventude e Imortalidade'),
('Anjo David Santos Costa', 'Igreja dos Anjos', 'Livros de orações virtuais pra você enviar boas energia e pedir orações aos anjos para os anjos receber juventude e imortalidade e recuperar seus poderes e saúde pra poder ajudar o mundo !', 'https://www.wattpad.com/story/372975070-anjo-david-santos-costa', 'Juventude e Imortalidade'),
('O Anjo Pedro', 'Igreja dos Anjos', 'Livros de orações virtuais pra você enviar boas energia e pedir orações aos anjos para os anjos receber juventude e imortalidade e recuperar seus poderes e saúde pra poder ajudar o mundo !', 'https://www.wattpad.com/story/361743387-o-anjo-pedro', 'Família'),
('Família Lopes Sá Moreira Gomes', 'Igreja dos Anjos', 'Livros de orações virtuais pra você enviar boas energia e pedir orações aos anjos para os anjos receber juventude e imortalidade e recuperar seus poderes e saúde pra poder ajudar o mundo !', 'https://www.wattpad.com/story/339071691-fam%C3%ADlia-lopes-s%C3%A1-moreira-gomes', 'Família'),
('O Anjo Bento Urbano Neto', 'Igreja dos Anjos', 'Livros de orações virtuais pra você enviar boas energia e pedir orações aos anjos para os anjos receber juventude e imortalidade e recuperar seus poderes e saúde pra poder ajudar o mundo !', 'https://www.wattpad.com/story/353478695-o-anjo-bento-urbano-neto', 'Família'),
('O Anjo Paulo', 'Igreja dos Anjos', 'Livros de orações virtuais pra você enviar boas energia e pedir orações aos anjos para os anjos receber juventude e imortalidade e recuperar seus poderes e saúde pra poder ajudar o mundo !', 'https://www.wattpad.com/story/353179125-o-anjo-pauulo', 'Família'),
('Angel Marise Coelho de Sá', 'Igreja dos Anjos', 'Livros de orações virtuais pra você enviar boas energia e pedir orações aos anjos para os anjos receber juventude e imortalidade e recuperar seus poderes e saúde pra poder ajudar o mundo !', 'https://www.wattpad.com/story/353671886-angel-marise-co%C3%BAlho-de-s%C3%A1', 'Família'),
('Angel Bruna', 'Igreja dos Anjos', 'Livros de orações virtuais pra você enviar boas energia e pedir orações aos anjos para os anjos receber juventude e imortalidade e recuperar seus poderes e saúde pra poder ajudar o mundo !', 'https://www.wattpad.com/story/361320289-angel-bruna', 'Família'),
('O Anjo', 'Igreja dos Anjos', 'Livros de orações virtuais pra você enviar boas energia e pedir orações aos anjos para os anjos receber juventude e imortalidade e recuperar seus poderes e saúde pra poder ajudar o mundo !', 'https://www.wattpad.com/story/343624904-o-anjo', 'Família'),
('Anjo Roberto', 'Igreja dos Anjos', 'Livros de orações virtuais pra você enviar boas energia e pedir orações aos anjos para os anjos receber juventude e imortalidade e recuperar seus poderes e saúde pra poder ajudar o mundo !', 'https://www.wattpad.com/story/366812329-anjo-roberto', 'Família'),
('O Anjo Erisson', 'Igreja dos Anjos', 'Livros de orações virtuais pra você enviar boas energia e pedir orações aos anjos para os anjos receber juventude e imortalidade e recuperar seus poderes e saúde pra poder ajudar o mundo !', 'https://www.wattpad.com/story/360712508-o-anjo-erisson', 'Família'),
('Angel Maria das Dores Coelho de Sá', 'Igreja dos Anjos', 'Livros de orações virtuais pra você enviar boas energia e pedir orações aos anjos para os anjos receber juventude e imortalidade e recuperar seus poderes e saúde pra poder ajudar o mundo !', 'https://www.wattpad.com/story/377726874-angel-maria-das-dores-coelho-de-s%C3%A1', 'Família'),
('O Anjo Eberte', 'Igreja dos Anjos', 'Livros de orações virtuais pra você enviar boas energia e pedir orações aos anjos para os anjos receber juventude e imortalidade e recuperar seus poderes e saúde pra poder ajudar o mundo !', 'https://www.wattpad.com/story/376294094-o-anjo-eberte', 'Família'),
('Angel Maria das Chagas Moreira Homem', 'Igreja dos Anjos', 'Livros de orações virtuais pra você enviar boas energia e pedir orações aos anjos para os anjos receber juventude e imortalidade e recuperar seus poderes e saúde pra poder ajudar o mundo !', 'https://www.wattpad.com/story/384933346-angel-maria-das-chagas-moreira-homem', 'Família');