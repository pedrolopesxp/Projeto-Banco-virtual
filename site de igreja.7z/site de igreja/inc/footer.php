</main>
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>Igreja dos Anjos</h3>
                    <p>Conectando corações através da oração e espiritualidade. Envie suas orações aos anjos para receber juventude, imortalidade e recuperar seus poderes para ajudar o mundo.</p>
                </div>
                <div class="footer-section">
                    <h4>Links Rápidos</h4>
                    <ul>
                        <li><a href="<?php echo SITE_URL; ?>/index.php">Início</a></li>
                        <li><a href="<?php echo SITE_URL; ?>/pages/livros.php">Livros de Orações</a></li>
                        <li><a href="<?php echo SITE_URL; ?>/pages/orar.php">Enviar Oração</a></li>
                        <li><a href="<?php echo SITE_URL; ?>/pages/testemunhos.php">Testemunhos</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Contato</h4>
                    <p>Email: contato@igrejadosanjos.com</p>
                    <p>Telefone: (11) 9999-9999</p>
                </div>
                <?php /* REMOVIDO: Bloco de Redes Sociais
                <div class="footer-section">
                    <h4>Redes Sociais</h4>
                    <div class="social-links">
                        <a href="#" target="_blank">Facebook</a>
                        <a href="#" target="_blank">Instagram</a>
                        <a href="#" target="_blank">YouTube</a>
                    </div>
                </div>
                */ ?>
            </div>
            <div class="footer-bottom">
                <p>© <?php echo date('Y'); ?> Igreja dos Anjos. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const navToggle = document.querySelector('.nav-toggle');
            const navMenu = document.querySelector('.nav-menu');
        
            if (navToggle && navMenu) {
                navToggle.addEventListener('click', () => {
                    navMenu.classList.toggle('active');
                });
            }
        
            // Smooth scroll for anchor links (if any, though none explicitly defined yet)
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();
        
                    document.querySelector(this.getAttribute('href')).scrollIntoView({
                        behavior: 'smooth'
                    });
                });
            });
        
            // Simple fade-in animation for hero elements
            const heroElements = document.querySelectorAll('.hero h1, .hero p, .hero .btn');
            heroElements.forEach((el, index) => {
                el.style.animationDelay = `${index * 0.2}s`;
            });
        
            // Card fade-in animation on scroll (simplified, can be improved with Intersection Observer)
            const cards = document.querySelectorAll('.card');
            const observerOptions = {
                root: null,
                rootMargin: '0px',
                threshold: 0.1
            };
        
            const observer = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('fade-in-up');
                        observer.unobserve(entry.target);
                    }
                });
            }, observerOptions);
        
            cards.forEach(card => {
                observer.observe(card);
            });
        });
    </script>
</body>
</html>