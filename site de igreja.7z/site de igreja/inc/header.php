<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' - ' : ''; ?>Igreja dos Anjos</title>
    <meta name="description" content="Igreja dos Anjos - Livros de orações virtuais para enviar boas energias e pedir orações aos anjos">
    <meta name="keywords" content="igreja, anjos, orações, espiritualidade, juventude, imortalidade, cura">
    
    <style>
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }
        
        body {
          font-family: "Inter", sans-serif;
          line-height: 1.6;
          color: #333;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          min-height: 100vh;
        }
        
        .container {
          max-width: 1200px;
          margin: 0 auto;
          padding: 0 20px;
        }
        
        /* Header */
        .header {
          background: rgba(255, 255, 255, 0.95);
          backdrop-filter: blur(10px);
          box-shadow: 0 2px 20px rgba(0, 0, 0, 0.1);
          position: fixed;
          top: 0;
          width: 100%;
          z-index: 1000;
        }
        
        .navbar {
          padding: 1rem 0;
        }
        
        .navbar .container {
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        
        .nav-brand a {
          text-decoration: none;
          color: #667eea;
        }
        
        .nav-brand h1 {
          font-size: 1.8rem;
          font-weight: 700;
        }
        
        .nav-menu {
          display: flex;
          list-style: none;
          margin: 0;
          padding: 0;
        }
        
        .nav-menu li {
          margin-left: 2rem;
        }
        
        .nav-menu a {
          text-decoration: none;
          color: #555;
          font-weight: 500;
          transition: color 0.3s ease;
        }
        
        .nav-menu a:hover {
          color: #764ba2;
        }
        
        .nav-toggle {
          display: none;
          flex-direction: column;
          cursor: pointer;
        }
        
        .nav-toggle span {
          height: 3px;
          width: 25px;
          background-color: #667eea;
          margin-bottom: 4px;
          border-radius: 5px;
        }
        
        /* Main Content Padding for fixed header */
        .main-content {
          padding-top: 80px; /* Adjust based on header height */
          min-height: calc(100vh - 80px - 200px); /* Adjust based on header and footer height */
        }
        
        /* Hero Section */
        .hero {
          background: linear-gradient(135deg, rgba(102, 126, 234, 0.8) 0%, rgba(118, 75, 162, 0.8) 100%), url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><filter id="noiseFilter"><feTurbulence type="fractalNoise" baseFrequency="0.6" numOctaves="3" stitchTiles="stitch"/></filter><rect width="100%" height="100%" filter="url(#noiseFilter)" opacity="0.1"/></svg>');
          background-size: cover;
          color: white;
          text-align: center;
          padding: 6rem 0;
          border-radius: 8px;
          margin-top: 2rem; /* Adjusted for main-content padding */
        }
        
        .hero h1 {
          font-size: 3.5rem;
          margin-bottom: 1rem;
          font-weight: 700;
        }
        
        .hero p {
          font-size: 1.5rem;
          margin-bottom: 2rem;
          max-width: 800px;
          margin-left: auto;
          margin-right: auto;
        }
        
        .btn {
          display: inline-block;
          padding: 12px 25px;
          border-radius: 50px;
          text-decoration: none;
          font-weight: 600;
          transition: all 0.3s ease;
          cursor: pointer;
          border: none;
          font-size: 1rem;
        }
        
        .btn-primary {
          background-color: #fff;
          color: #667eea;
          margin-right: 1rem;
          box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }
        
        .btn-primary:hover {
          background-color: #f0f0f0;
          transform: translateY(-2px);
          box-shadow: 0 6px 20px rgba(0, 0, 0, 0.25);
        }
        
        .btn-secondary {
          background: linear-gradient(45deg, #667eea, #764ba2);
          color: white;
          box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        }
        
        .btn-secondary:hover {
          transform: translateY(-2px);
          box-shadow: 0 6px 20px rgba(0, 0, 0, 0.25);
          opacity: 0.9;
        }
        
        /* Cards Grid */
        .cards-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 2rem;
          margin: 4rem 0;
        }
        
        .card {
          background-color: white;
          padding: 2rem;
          border-radius: 8px;
          box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
          text-align: center;
          transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .card:hover {
          transform: translateY(-5px);
          box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
        }
        
        .card h3 {
          color: #667eea;
          font-size: 1.8rem;
          margin-bottom: 1rem;
        }
        
        .card p {
          color: #555;
          margin-bottom: 1.5rem;
        }
        
        /* Forms */
        .form-group {
          margin-bottom: 1.5rem;
        }
        
        .form-group label {
          display: block;
          margin-bottom: 0.5rem;
          color: #555;
          font-weight: 500;
        }
        
        .form-control {
          width: 100%;
          padding: 12px;
          border: 1px solid #ddd;
          border-radius: 5px;
          font-size: 1rem;
          color: #333;
        }
        
        .form-control:focus {
          outline: none;
          border-color: #667eea;
          box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.2);
        }
        
        textarea.form-control {
          resize: vertical;
        }
        
        /* Alerts */
        .alert {
          padding: 1rem;
          border-radius: 5px;
          margin-bottom: 1.5rem;
          text-align: center;
          font-weight: 500;
        }
        
        .alert-success {
          background-color: #d4edda;
          color: #155724;
          border-color: #c3e6cb;
        }
        
        .alert-error {
          background-color: #f8d7da;
          color: #721c24;
          border-color: #f5c6cb;
        }
        
        /* Footer */
        .footer {
          background-color: #222;
          color: white;
          padding: 3rem 0;
          margin-top: 4rem;
        }
        
        .footer-content {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
          gap: 2rem;
          margin-bottom: 2rem;
        }
        
        .footer-section h3 {
          color: #667eea;
          margin-bottom: 1rem;
          font-size: 1.5rem;
        }
        
        .footer-section h4 {
          color: #764ba2;
          margin-bottom: 1rem;
          font-size: 1.2rem;
        }
        
        .footer-section p,
        .footer-section ul {
          font-size: 0.95rem;
          line-height: 1.8;
        }
        
        .footer-section ul {
          list-style: none;
          padding: 0;
        }
        
        .footer-section ul li a {
          color: white;
          text-decoration: none;
          transition: color 0.3s ease;
        }
        
        .footer-section ul li a:hover {
          color: #667eea;
        }
        
        .social-links a {
          display: inline-block;
          color: white;
          margin-right: 15px;
          font-size: 1rem;
          text-decoration: none;
          transition: color 0.3s ease;
        }
        
        .social-links a:hover {
          color: #667eea;
        }
        
        .footer-bottom {
          text-align: center;
          padding-top: 1.5rem;
          border-top: 1px solid rgba(255, 255, 255, 0.1);
          font-size: 0.9rem;
          color: #aaa;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
          .nav-menu {
            display: none;
            flex-direction: column;
            width: 100%;
            position: absolute;
            top: 80px; /* Height of the header */
            left: 0;
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(10px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            padding: 1rem 0;
          }
        
          .nav-menu.active {
            display: flex;
          }
        
          .nav-menu li {
            margin: 0;
            text-align: center;
            padding: 0.8rem 0;
            border-bottom: 1px solid #eee;
          }
        
          .nav-menu li:last-child {
            border-bottom: none;
          }
        
          .nav-toggle {
            display: flex;
          }
        
          .hero h1 {
            font-size: 2.5rem;
          }
        
          .hero p {
            font-size: 1.2rem;
          }
        
          .btn-primary, .btn-secondary {
            display: block;
            width: 80%;
            margin: 1rem auto;
          }
        
          .cards-grid {
            grid-template-columns: 1fr;
          }
        
          .footer-content {
            grid-template-columns: 1fr;
            text-align: center;
          }
          
          .footer-section ul {
              margin-top: 1rem;
          }
        }
        
        /* Animations */
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .fade-in-up {
          animation: fadeInUp 0.6s ease-out;
        }
        
        /* Prayer Categories */
        .prayer-categories {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
          gap: 1rem;
          margin: 2rem 0;
        }
        
        .category-tag {
          background: #667eea;
          color: white;
          padding: 8px 16px;
          border-radius: 20px;
          text-align: center;
          font-size: 0.9rem;
          font-weight: 500;
        }
        
        /* Book Links */
        .book-link {
          display: inline-block;
          background: #764ba2;
          color: white;
          padding: 8px 16px;
          border-radius: 5px;
          text-decoration: none;
          font-size: 0.9rem;
          margin-top: 1rem;
          transition: background 0.3s ease;
        }
        
        .book-link:hover {
          background: #5a3a7a;
        }
        
        /* Animações CSS Puras */
        .card {
          animation: fadeInUp 0.6s ease-out;
        }
        
        .hero h1,
        .hero p {
          animation: fadeInUp 0.8s ease-out;
        }
        
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
    </style>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <header class="header">
        <nav class="navbar">
            <div class="container">
                <div class="nav-brand">
                    <a href="<?php echo SITE_URL; ?>/index.php">
                        <h1>⭐ Igreja dos Anjos</h1>
                    </a>
                </div>
                <ul class="nav-menu">
                    <li><a href="<?php echo SITE_URL; ?>/index.php">Início</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/pages/livros.php">Livros de Orações</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/pages/orar.php">Enviar Oração</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/pages/testemunhos.php">Testemunhos</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/pages/sobre.php">Sobre</a></li>
                    <li><a href="<?php echo SITE_URL; ?>/pages/contato.php">Contato</a></li>
                </ul>
                <div class="nav-toggle">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>
        </nav>
    </header>
    <main class="main-content">