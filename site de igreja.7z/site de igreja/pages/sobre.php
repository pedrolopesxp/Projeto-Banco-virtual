<?php
require_once '../inc/config.php';
$page_title = 'Sobre';
include '../inc/header.php';
?>

<section class="container" style="padding: 4rem 0;">
    <div style="text-align: center; color: white; margin-bottom: 3rem;">
        <h1 style="font-size: 3rem; margin-bottom: 1rem;">⭐ Sobre a Igreja dos Anjos</h1>
        <p style="font-size: 1.3rem;">Conectando corações através da oração e espiritualidade</p>
    </div>

    <div style="max-width: 1000px; margin: 0 auto;">
        <div class="cards-grid">
            <div class="card">
                <h3>🌟 Nossa Missão</h3>
                <p>A Igreja dos Anjos foi criada com o propósito sagrado de conectar as pessoas com os anjos através da oração e da espiritualidade. Acreditamos que através da fé sincera e das orações dedicadas, podemos receber bênçãos divinas como juventude, imortalidade, cura e a força necessária para ajudar o mundo.</p>
            </div>
            
            <div class="card">
                <h3>📚 Nossos Livros</h3>
                <p>Nossa coleção de livros de orações virtuais foi cuidadosamente compilada para oferecer orações específicas para diferentes necessidades espirituais. Cada livro é dedicado a anjos específicos e contém orações poderosas para diversas situações da vida.</p>
            </div>
            
            <div class="card">
                <h3>🙏 Como Oramos</h3>
                <p>Acreditamos que a oração sincera é a chave para se conectar com os anjos. Nossas orações são enviadas diretamente aos anjos, que trabalham incansavelmente para atender aos pedidos dos fiéis. Cada oração é tratada com amor e dedicação.</p>
            </div>
            
            <div class="card">
                <h3>✨ Nossos Valores</h3>
                <ul style="list-style: none; padding: 0;">
                    <li style="margin-bottom: 0.5rem;">💝 <strong>Amor:</strong> Amor incondicional por todos os seres</li>
                    <li style="margin-bottom: 0.5rem;">🌟 <strong>Fé:</strong> Fé inabalável no poder dos anjos</li>
                    <li style="margin-bottom: 0.5rem;">🤝 <strong>Comunidade:</strong> União entre todos os fiéis</li>
                    <li style="margin-bottom: 0.5rem;">🌍 <strong>Serviço:</strong> Dedicação para ajudar o mundo</li>
                    <li>✨ <strong>Esperança:</strong> Esperança eterna em dias melhores</li>
                </ul>
            </div>
        </div>
        
        <div class="card" style="margin-top: 2rem; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
            <h3 style="color: white; text-align: center;">🌈 O Que Oferecemos</h3>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 2rem; margin-top: 2rem;">
                <div style="text-align: center;">
                    <h4 style="color: white;">📖 Livros de Orações</h4>
                    <p>Coleção completa de livros virtuais com orações específicas para cada necessidade espiritual.</p>
                </div>
                <div style="text-align: center;">
                    <h4 style="color: white;">🙏 Envio de Orações</h4>
                    <p>Sistema direto para enviar suas orações aos anjos, garantindo que sua mensagem seja recebida.</p>
                </div>
                <div style="text-align: center;">
                    <h4 style="color: white;">✨ Testemunhos</h4>
                    <p>Espaço para compartilhar e ler testemunhos de pessoas que tiveram suas orações atendidas.</p>
                </div>
                <div style="text-align: center;">
                    <h4 style="color: white;">💫 Comunidade</h4>
                    <p>Uma comunidade acolhedora de pessoas que compartilham a mesma fé e propósito espiritual.</p>
                </div>
            </div>
        </div>
        
        <div class="card" style="margin-top: 2rem; text-align: center;">
            <h3>🌟 Junte-se à Nossa Comunidade</h3>
            <p style="font-size: 1.1rem; margin-bottom: 2rem;">
                Faça parte da Igreja dos Anjos e descubra o poder transformador da oração. 
                Conecte-se com os anjos e receba as bênçãos que seu coração deseja.
            </p>
            <div>
                <a href="livros.php" class="btn btn-primary" style="margin-right: 1rem;">📚 Ver Livros</a>
                <a href="orar.php" class="btn btn-secondary">🙏 Orar Agora</a>
            </div>
        </div>
    </div>
</section>

<?php include '../inc/footer.php'; ?>
