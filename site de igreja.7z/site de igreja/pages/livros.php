<?php
require_once '../inc/config.php';
$page_title = 'Livros de Orações';
include '../inc/header.php';

// Buscar livros do banco de dados
try {
    $stmt = $pdo->query("SELECT * FROM livros_oracoes ORDER BY categoria, titulo");
    $livros = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $livros = [];
}
?>

<section class="container" style="padding: 4rem 0;">
    <div style="text-align: center; color: white; margin-bottom: 3rem;">
        <h1 style="font-size: 3rem; margin-bottom: 1rem;">📚 Livros de Orações</h1>
        <p style="font-size: 1.3rem;">Coleção completa de livros de orações virtuais para conectar-se com os anjos</p>
    </div>

    <?php if (!empty($livros)): ?>
        <div class="cards-grid">
            <?php 
            $current_category = '';
            foreach ($livros as $livro): 
            ?>
                <div class="card">
                    <div class="category-tag" style="margin-bottom: 1rem; display: inline-block;">
                        <?php echo htmlspecialchars($livro['categoria']); ?>
                    </div>
                    <h3><?php echo htmlspecialchars($livro['titulo']); ?></h3>
                    <p><strong>Autor:</strong> <?php echo htmlspecialchars($livro['autor']); ?></p>
                    <p><?php echo htmlspecialchars($livro['descricao']); ?></p>
                    
                    <?php if (!empty($livro['url_wattpad'])): ?>
                        <a href="<?php echo htmlspecialchars($livro['url_wattpad']); ?>" 
                           target="_blank" 
                           class="book-link">
                            📖 Ler no Wattpad
                        </a>
                    <?php endif; ?>
                    
                    <div style="margin-top: 1rem;">
                        <a href="orar.php?livro=<?php echo urlencode($livro['titulo']); ?>" 
                           class="btn btn-primary">
                            🙏 Orar com este Livro
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php else: ?>
        <div class="card" style="text-align: center;">
            <h3>Nenhum livro encontrado</h3>
            <p>Os livros de orações estão sendo carregados. Tente novamente em alguns instantes.</p>
        </div>
    <?php endif; ?>
</section>

<?php include '../inc/footer.php'; ?>