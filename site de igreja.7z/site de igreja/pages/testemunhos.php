<?php
require_once '../inc/config.php';
$page_title = 'Testemunhos';
include '../inc/header.php';

$message = '';

// Processar envio de testemunho
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = sanitize($_POST['nome']);
    $email = sanitize($_POST['email']);
    $testemunho = sanitize($_POST['testemunho']);
    
    if (!empty($nome) && !empty($testemunho)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO testemunhos (nome, email, testemunho) VALUES (?, ?, ?)");
            $stmt->execute([$nome, $email, $testemunho]);
            $message = '<div class="alert alert-success">✅ Seu testemunho foi enviado com sucesso! Será analisado antes da publicação.</div>';
        } catch(PDOException $e) {
            $message = '<div class="alert alert-error">❌ Erro ao enviar testemunho. Tente novamente.</div>';
        }
    } else {
        $message = '<div class="alert alert-error">❌ Por favor, preencha pelo menos o nome e o testemunho.</div>';
    }
}

// Buscar testemunhos aprovados
try {
    $stmt = $pdo->query("SELECT nome, testemunho, data_criacao FROM testemunhos WHERE aprovado = 1 ORDER BY data_criacao DESC LIMIT 10");
    $testemunhos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $testemunhos = [];
}
?>

<section class="container" style="padding: 4rem 0;">
    <div style="text-align: center; color: white; margin-bottom: 3rem;">
        <h1 style="font-size: 3rem; margin-bottom: 1rem;">✨ Testemunhos</h1>
        <p style="font-size: 1.3rem;">Histórias reais de pessoas que tiveram suas orações atendidas pelos anjos</p>
    </div>

    <!-- Formulário para enviar testemunho -->
    <div style="max-width: 800px; margin: 0 auto 4rem;">
        <div class="card">
            <h3>📝 Compartilhe Seu Testemunho</h3>
            <?php echo $message; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="nome">Nome *</label>
                    <input type="text" id="nome" name="nome" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email (opcional)</label>
                    <input type="email" id="email" name="email" class="form-control">
                </div>
                
                <div class="form-group">
                    <label for="testemunho">Seu Testemunho *</label>
                    <textarea id="testemunho" name="testemunho" class="form-control" rows="6" 
                              placeholder="Conte-nos como os anjos atenderam sua oração... Que bênçãos você recebeu? Como sua vida mudou?" required></textarea>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    ✨ Enviar Testemunho
                </button>
            </form>
        </div>
    </div>

    <!-- Testemunhos publicados -->
    <?php if (!empty($testemunhos)): ?>
        <div style="max-width: 1000px; margin: 0 auto;">
            <h2 style="text-align: center; color: white; margin-bottom: 2rem; font-size: 2.5rem;">
                🌟 Testemunhos dos Fiéis
            </h2>
            
            <div class="cards-grid">
                <?php foreach ($testemunhos as $testemunho): ?>
                    <div class="card">
                        <div style="display: flex; align-items: center; margin-bottom: 1rem;">
                            <div style="width: 50px; height: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold; margin-right: 1rem;">
                                <?php echo strtoupper(substr($testemunho['nome'], 0, 1)); ?>
                            </div>
                            <div>
                                <h4 style="margin: 0; color: #667eea;"><?php echo htmlspecialchars($testemunho['nome']); ?></h4>
                                <small style="color: #666;"><?php echo date('d/m/Y', strtotime($testemunho['data_criacao'])); ?></small>
                            </div>
                        </div>
                        <p style="font-style: italic; line-height: 1.6;">
                            "<?php echo nl2br(htmlspecialchars($testemunho['testemunho'])); ?>"
                        </p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php else: ?>
        <div style="max-width: 800px; margin: 0 auto;">
            <div class="card" style="text-align: center;">
                <h3>🌟 Seja o Primeiro!</h3>
                <p>Ainda não temos testemunhos publicados. Seja o primeiro a compartilhar como os anjos atenderam sua oração!</p>
            </div>
        </div>
    <?php endif; ?>
</section>

<?php include '../inc/footer.php'; ?>
