<?php
require_once '../inc/config.php';
$page_title = 'Contato';
include '../inc/header.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = sanitize($_POST['nome']);
    $email = sanitize($_POST['email']);
    $assunto = sanitize($_POST['assunto']);
    $mensagem = sanitize($_POST['mensagem']);
    
    if (!empty($nome) && !empty($email) && !empty($mensagem)) {
        // Aqui você pode implementar o envio de email
        $message = '<div class="alert alert-success">✅ Sua mensagem foi enviada com sucesso! Entraremos em contato em breve.</div>';
    } else {
        $message = '<div class="alert alert-error">❌ Por favor, preencha todos os campos obrigatórios.</div>';
    }
}
?>

<section class="container" style="padding: 4rem 0;">
    <div style="text-align: center; color: white; margin-bottom: 3rem;">
        <h1 style="font-size: 3rem; margin-bottom: 1rem;">📞 Contato</h1>
        <p style="font-size: 1.3rem;">Entre em contato conosco para dúvidas, sugestões ou apoio espiritual</p>
    </div>

    <div style="max-width: 1000px; margin: 0 auto;">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; margin-bottom: 3rem;">
            <div class="card">
                <h3>📧 Informações de Contato</h3>
                <div style="margin: 2rem 0;">
                    <p><strong>📧 Email:</strong> contato@igrejadosanjos.com</p>
                    <p><strong>📱 Telefone:</strong> (11) 9999-9999</p>
                    <p><strong>📍 Endereço:</strong> Rua dos Anjos, 123 - São Paulo, SP</p>
                    <p><strong>🕐 Horário:</strong> Segunda a Sexta, 9h às 18h</p>
                </div>
                
                <h4>🌐 Redes Sociais</h4>
                <div style="margin-top: 1rem;">
                    <a href="#" style="color: #667eea; text-decoration: none; margin-right: 1rem;">📘 Facebook</a>
                    <a href="#" style="color: #667eea; text-decoration: none; margin-right: 1rem;">📷 Instagram</a>
                    <a href="#" style="color: #667eea; text-decoration: none;">📺 YouTube</a>
                </div>
            </div>
            
            <div class="card">
                <h3>💬 Envie uma Mensagem</h3>
                <?php echo $message; ?>
                
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="nome">Nome *</label>
                        <input type="text" id="nome" name="nome" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email *</label>
                        <input type="email" id="email" name="email" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="assunto">Assunto</label>
                        <select id="assunto" name="assunto" class="form-control">
                            <option value="">Selecione um assunto</option>
                            <option value="duvida">Dúvida sobre orações</option>
                            <option value="testemunho">Compartilhar testemunho</option>
                            <option value="sugestao">Sugestão</option>
                            <option value="apoio">Pedido de apoio espiritual</option>
                            <option value="outro">Outro</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="mensagem">Mensagem *</label>
                        <textarea id="mensagem" name="mensagem" class="form-control" rows="5" required></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">
                        📤 Enviar Mensagem
                    </button>
                </form>
            </div>
        </div>
        
        <div class="card" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
            <h3 style="color: white; text-align: center;">🤝 Como Podemos Ajudar</h3>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 2rem; margin-top: 2rem;">
                <div style="text-align: center;">
                    <h4 style="color: white;">🙏 Orientação Espiritual</h4>
                    <p>Oferecemos orientação para suas orações e jornada espiritual.</p>
                </div>
                <div style="text-align: center;">
                    <h4 style="color: white;">📚 Dúvidas sobre Livros</h4>
                    <p>Esclarecemos dúvidas sobre nossos livros de orações.</p>
                </div>
                <div style="text-align: center;">
                    <h4 style="color: white;">💝 Apoio Emocional</h4>
                    <p>Oferecemos apoio e consolo em momentos difíceis.</p>
                </div>
                <div style="text-align: center;">
                    <h4 style="color: white;">✨ Testemunhos</h4>
                    <p>Ajudamos você a compartilhar seu testemunho.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include '../inc/footer.php'; ?>
