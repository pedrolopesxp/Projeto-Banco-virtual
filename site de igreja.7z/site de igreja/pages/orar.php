<?php
require_once '../inc/config.php';
$page_title = 'Enviar Oração';
include '../inc/header.php';

$message = '';
$livro_selecionado = isset($_GET['livro']) ? $_GET['livro'] : '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = sanitize($_POST['nome']);
    $email = sanitize($_POST['email']);
    $tipo_oracao = sanitize($_POST['tipo_oracao']);
    $anjo_destinatario = sanitize($_POST['anjo_destinatario']);
    $mensagem = sanitize($_POST['mensagem']);
    
    if (!empty($nome) && !empty($mensagem)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO oracoes_enviadas (nome, email, tipo_oracao, anjo_destinatario, mensagem) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$nome, $email, $tipo_oracao, $anjo_destinatario, $mensagem]);
            $message = '<div class="alert alert-success">✅ Sua oração foi enviada com sucesso aos anjos! Eles receberam sua mensagem e trabalharão para atendê-la.</div>';
        } catch(PDOException $e) {
            $message = '<div class="alert alert-error">❌ Erro ao enviar oração. Tente novamente.</div>';
        }
    } else {
        $message = '<div class="alert alert-error">❌ Por favor, preencha pelo menos o nome e a mensagem.</div>';
    }
}
?>

<section class="container" style="padding: 4rem 0;">
    <div style="text-align: center; color: white; margin-bottom: 3rem;">
        <h1 style="font-size: 3rem; margin-bottom: 1rem;">🙏 Enviar Oração</h1>
        <p style="font-size: 1.3rem;">Conecte-se com os anjos e envie suas orações para receber bênçãos, cura e proteção</p>
    </div>

    <div style="max-width: 800px; margin: 0 auto;">
        <div class="card">
            <?php echo $message; ?>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="nome">Nome Completo *</label>
                    <input type="text" id="nome" name="nome" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email (opcional)</label>
                    <input type="email" id="email" name="email" class="form-control">
                </div>
                
                <div class="form-group">
                    <label for="tipo_oracao">Tipo de Oração</label>
                    <select id="tipo_oracao" name="tipo_oracao" class="form-control">
                        <option value="">Selecione o tipo de oração</option>
                        <option value="juventude">Juventude e Imortalidade</option>
                        <option value="cura">Cura e Saúde</option>
                        <option value="protecao">Proteção</option>
                        <option value="familia">Família</option>
                        <option value="prosperidade">Prosperidade</option>
                        <option value="sabedoria">Sabedoria</option>
                        <option value="paz">Paz Mundial</option>
                        <option value="forca">Força e Coragem</option>
                        <option value="transformacao">Transformação</option>
                        <option value="consolo">Consolo</option>
                        <option value="geral">Oração Geral</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="anjo_destinatario">Anjo Destinatário</label>
                    <select id="anjo_destinatario" name="anjo_destinatario" class="form-control">
                        <option value="">Todos os Anjos</option>
                        <option value="Anjo Augusto Rafael Silva Sousa">Anjo Augusto Rafael Silva Sousa</option>
                        <option value="Anjo Karl Malone Garros">Anjo Karl Malone Garros</option>
                        <option value="Anjo David Santos Costa">Anjo David Santos Costa</option>
                        <option value="Anjo Pedro">Anjo Pedro</option>
                        <option value="Anjo Bento Urbano Neto">Anjo Bento Urbano Neto</option>
                        <option value="Anjo Paulo">Anjo Paulo</option>
                        <option value="Angel Marise Coelho de Sá">Angel Marise Coelho de Sá</option>
                        <option value="Angel Bruna">Angel Bruna</option>
                        <option value="Anjo Roberto">Anjo Roberto</option>
                        <option value="Anjo Erisson">Anjo Erisson</option>
                        <option value="Angel Maria das Dores">Angel Maria das Dores Coelho de Sá</option>
                        <option value="Anjo Eberte">Anjo Eberte</option>
                        <option value="Angel Maria das Chagas">Angel Maria das Chagas Moreira Homem</option>
                    </select>
                </div>
                
                <?php if ($livro_selecionado): ?>
                <div class="form-group">
                    <label>Livro Selecionado</label>
                    <input type="text" value="<?php echo htmlspecialchars($livro_selecionado); ?>" class="form-control" readonly>
                </div>
                <?php endif; ?>
                
                <div class="form-group">
                    <label for="mensagem">Sua Oração *</label>
                    <textarea id="mensagem" name="mensagem" class="form-control" rows="6" 
                              placeholder="Escreva sua oração aqui... Peça aos anjos por juventude, imortalidade, cura, proteção, ou qualquer outra necessidade que tenha em seu coração." required></textarea>
                </div>
                
                <button type="submit" class="btn btn-primary" style="width: 100%; font-size: 1.1rem; padding: 15px;">
                    ✨ Enviar Oração aos Anjos
                </button>
            </form>
        </div>
        
        <div class="card" style="margin-top: 2rem; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
            <h3 style="color: white;">💫 Como Funciona</h3>
            <ul style="list-style: none; padding: 0;">
                <li style="margin-bottom: 1rem;">🌟 <strong>1.</strong> Preencha o formulário com sua oração sincera</li>
                <li style="margin-bottom: 1rem;">👼 <strong>2.</strong> Escolha o anjo que melhor se conecta com sua necessidade</li>
                <li style="margin-bottom: 1rem;">✨ <strong>3.</strong> Sua oração será enviada diretamente aos anjos</li>
                <li style="margin-bottom: 1rem;">🙏 <strong>4.</strong> Os anjos trabalharão para atender sua oração</li>
                <li>💝 <strong>5.</strong> Mantenha a fé e aguarde as bênçãos chegarem</li>
            </ul>
        </div>
    </div>
</section>

<?php include '../inc/footer.php'; ?>
