<?php
// www/inc/db_connection.php

$host = 'localhost';
$dbname = 'Pay';
$username = 'root';
$password = '123456789';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    // Em um ambiente de produção, você deve logar o erro e exibir uma mensagem genérica.
    // die("Connection failed: " . $e->getMessage()); // Evite mostrar detalhes de erro em produção
    error_log("Erro de conexão com o banco de dados: " . $e->getMessage());
    die("Erro interno do servidor. Por favor, tente novamente mais tarde.");
}
?>
