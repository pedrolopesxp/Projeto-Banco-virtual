<?php
// www/pages/dashboard.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

// Verifica se o usuário está logado. Se não, redireciona para a página de login.
if (!isset($_SESSION['user_id'])) {
    set_message("Você precisa estar logado para acessar o Dashboard.", "error");
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$userName = htmlspecialchars($_SESSION['user_name'] ?? 'Usuário');
$saldo_bitcoin = 0;
$saldo_real = 0;
$numero_conta = '';

try {
    // Buscar dados da conta do usuário
    $stmt_account = $pdo->prepare("SELECT nr_conta, vl_saldo_bitcoin, vl_saldo_real FROM tb_conta WHERE id_usuario = ?");
    $stmt_account->execute([$user_id]);
    $account_data = $stmt_account->fetch();

    if ($account_data) {
        $numero_conta = htmlspecialchars($account_data['nr_conta']);
        $saldo_bitcoin = htmlspecialchars(number_format($account_data['vl_saldo_bitcoin'], 8, ',', '.'));
        $saldo_real = htmlspecialchars(number_format($account_data['vl_saldo_real'], 2, ',', '.'));
    } else {
        set_message("Não foi possível carregar os dados da sua conta.", "error");
    }

    // Buscar últimas transações (exemplo)
    $stmt_transactions = $pdo->prepare("SELECT tp_tipo, tp_metodo_pagamento, vl_quantidade_real, vl_quantidade_bitcoin, ds_status, dt_transacao FROM tb_transacao WHERE id_remetente = ? OR id_destinatario = ? ORDER BY dt_transacao DESC LIMIT 5");
    $stmt_transactions->execute([$user_id, $user_id]);
    $transactions = $stmt_transactions->fetchAll();

} catch (PDOException $e) {
    error_log("Erro ao carregar dashboard: " . $e->getMessage());
    set_message("Ocorreu um erro ao carregar seus dados. Por favor, tente novamente.", "error");
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            margin-top: 30px;
        }
        .dashboard-card {
            background-color: var(--secondary-color);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            text-align: center;
        }
        .dashboard-card h3 {
            color: var(--primary-dark-color);
            margin-bottom: 20px;
            font-size: 1.8em;
        }
        .dashboard-card p {
            font-size: 1.2em;
            color: var(--text-color);
            margin-bottom: 10px;
        }
        .dashboard-card .balance {
            font-size: 2.2em;
            font-weight: bold;
            color: var(--primary-color);
            margin-top: 15px;
        }
        .transaction-list {
            list-style: none;
            padding: 0;
            margin-top: 20px;
        }
        .transaction-item {
            background-color: var(--light-gray);
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 8px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.95em;
            flex-wrap: wrap; /* Para quebras de linha em telas pequenas */
        }
        .transaction-item span {
            font-weight: bold;
            color: var(--primary-dark-color);
            margin-right: 15px; /* Espaçamento entre os spans */
        }
        /* Ajuste para spans em telas pequenas */
        @media (max-width: 480px) {
            .transaction-item span {
                width: 100%; /* Ocupa toda a largura */
                margin-bottom: 5px; /* Espaçamento entre eles */
            }
        }

        .dashboard-actions {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            margin-top: 50px;
        }
        .dashboard-actions .button {
            padding: 15px 25px;
            font-size: 1.1em;
            border-radius: 10px;
            text-decoration: none;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.2s ease;
            box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
            background-color: var(--primary-color);
            color: var(--secondary-color);
            border: none;
            cursor: pointer;
        }
        .dashboard-actions .button:hover {
            background-color: var(--primary-dark-color);
            transform: translateY(-2px);
        }
        @media (max-width: 768px) {
            .dashboard-card {
                padding: 20px;
            }
            .dashboard-card h3 {
                font-size: 1.5em;
            }
            .dashboard-card .balance {
                font-size: 1.8em;
            }
            .dashboard-actions .button {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Bank Lopes</div>
            <nav>
                <ul>
                    <li><a href="../index.php">Início</a></li>
                    <li>Olá, <?= $userName ?></li>
                    <li><a href="logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="form-container"> <!-- Usando form-container para centralizar e estilizar -->
            <h2>Bem-vindo(a) ao seu Dashboard, <?= $userName ?>!</h2>
            <?php display_messages(); ?>

            <div class="dashboard-grid">
                <div class="dashboard-card">
                    <h3>Saldo em Bitcoin (BTC)</h3>
                    <p class="balance"><?= $saldo_bitcoin ?> BTC</p>
                    <p>Número da sua conta: <span><?= $numero_conta ?></span></p>
                </div>
                <div class="dashboard-card">
                    <h3>Saldo em Reais (BRL)</h3>
                    <p class="balance">R$ <?= $saldo_real ?></p>
                    <p>Número da sua conta: <span><?= $numero_conta ?></span></p>
                </div>
            </div>

            <div class="dashboard-card" style="margin-top: 30px;">
                <h3>Últimas Transações</h3>
                <?php if (!empty($transactions)): ?>
                    <ul class="transaction-list">
                        <?php foreach ($transactions as $transaction): ?>
                            <li class="transaction-item">
                                <span>Tipo: <?= htmlspecialchars($transaction['tp_tipo']) ?></span>
                                <span>Método: <?= htmlspecialchars($transaction['tp_metodo_pagamento']) ?></span>
                                <?php if (!empty($transaction['vl_quantidade_real'])): ?>
                                    <span>Valor: R$ <?= htmlspecialchars(number_format($transaction['vl_quantidade_real'], 2, ',', '.')) ?></span>
                                <?php endif; ?>
                                <?php if (!empty($transaction['vl_quantidade_bitcoin'])): ?>
                                    <span>BTC: <?= htmlspecialchars(number_format($transaction['vl_quantidade_bitcoin'], 8, ',', '.')) ?></span>
                                <?php endif; ?>
                                <span>Status: <?= htmlspecialchars($transaction['ds_status']) ?></span>
                                <span>Data: <?= htmlspecialchars(date('d/m/Y H:i', strtotime($transaction['dt_transacao']))) ?></span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p>Nenhuma transação recente encontrada.</p>
                <?php endif; ?>
            </div>

            <div class="dashboard-actions">
                <a href="send_bitcoin.php" class="button">Enviar Bitcoin</a>
                <a href="make_pix.php" class="button">Fazer PIX</a>
                <a href="my_cards.php" class="button">Meus Cartões</a>
                <a href="deposit_withdraw.php" class="button">Depositar/Sacar</a>
            </div>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>
</body>
</html>
