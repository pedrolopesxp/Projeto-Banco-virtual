<?php
// www/pages/deposit_withdraw.php

session_start();
// Exibição de erros para depuração (MUITO IMPORTANTE: REMOVER EM PRODUÇÃO!)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php'; // Garante que functions.php seja carregado

// Verifica se o usuário está logado.
if (!isset($_SESSION['user_id'])) {
    set_message("Você precisa estar logado para depositar ou sacar.", "error");
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$userName = htmlspecialchars($_SESSION['user_name'] ?? 'Usuário');

$current_real_balance = 0;
$current_bitcoin_balance = 0;

try {
    $stmt_balance = $pdo->prepare("SELECT vl_saldo_bitcoin, vl_saldo_real FROM tb_conta WHERE id_usuario = ?");
    $stmt_balance->execute([$user_id]);
    $account_data = $stmt_balance->fetch(PDO::FETCH_ASSOC);
    if ($account_data) {
        $current_bitcoin_balance = $account_data['vl_saldo_bitcoin'];
        $current_real_balance = $account_data['vl_saldo_real'];
    }
} catch (PDOException $e) {
    error_log("Erro ao buscar saldos para depósito/saque: " . $e->getMessage());
    set_message("Erro ao carregar seus saldos. Por favor, tente novamente.", "error");
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = trim(isset($_POST['action']) ? $_POST['action'] : ''); // 'deposit' ou 'withdraw'
    $currency = trim(isset($_POST['currency']) ? $_POST['currency'] : ''); // 'BRL' ou 'BTC'
    $amount = floatval(str_replace(',', '.', trim(isset($_POST['amount']) ? $_POST['amount'] : '0')));
    $method = trim(isset($_POST['method']) ? $_POST['method'] : ''); // 'PIX', 'TED', 'Bitcoin', etc.

    // Campos adicionais para métodos específicos
    $pix_key_type = trim(isset($_POST['pix_key_type']) ? $_POST['pix_key_type'] : '');
    $pix_key = trim(isset($_POST['pix_key']) ? $_POST['pix_key'] : '');
    $bank_name = trim(isset($_POST['bank_name']) ? $_POST['bank_name'] : '');
    $agency_number = trim(isset($_POST['agency_number']) ? $_POST['agency_number'] : '');
    $account_number = trim(isset($_POST['account_number']) ? $_POST['account_number'] : '');
    $account_type = trim(isset($_POST['account_type']) ? $_POST['account_type'] : '');
    $holder_name = trim(isset($_POST['holder_name']) ? $_POST['holder_name'] : '');
    $holder_cpf_cnpj = trim(isset($_POST['holder_cpf_cnpj']) ? $_POST['holder_cpf_cnpj'] : '');
    $bitcoin_address = trim(isset($_POST['bitcoin_address']) ? $_POST['bitcoin_address'] : '');


    if ($amount <= 0) {
        set_message("A quantidade deve ser maior que zero.", "error");
    } elseif (empty($action) || empty($currency) || empty($method)) {
        set_message("Por favor, preencha todos os campos obrigatórios.", "error");
    } else {
        // Validação adicional para campos específicos do método
        $method_details = ''; // Para armazenar detalhes para a descrição da transação

        if ($method === 'PIX') {
            if (empty($pix_key_type) || empty($pix_key)) {
                set_message("Por favor, preencha o tipo e a chave PIX.", "error");
            } else {
                $method_details = "Chave PIX: " . htmlspecialchars($pix_key) . " (" . htmlspecialchars($pix_key_type) . ")";
            }
        } elseif ($method === 'TED') {
            if (empty($bank_name) || empty($agency_number) || empty($account_number) || empty($account_type) || empty($holder_name) || empty($holder_cpf_cnpj)) {
                set_message("Por favor, preencha todos os dados bancários para TED.", "error");
            } else {
                $method_details = "TED para " . htmlspecialchars($holder_name) . " (CPF/CNPJ: " . htmlspecialchars($holder_cpf_cnpj) . ") Banco: " . htmlspecialchars($bank_name) . ", Ag: " . htmlspecialchars($agency_number) . ", Cc: " . htmlspecialchars($account_number) . " (" . htmlspecialchars($account_type) . ")";
            }
        } elseif ($method === 'Transferência Bitcoin') {
            if ($action === 'withdraw') { // Para saque, o usuário precisa fornecer o endereço
                if (empty($bitcoin_address)) {
                    set_message("Por favor, informe o endereço Bitcoin de destino para o saque.", "error");
                } else {
                    $method_details = "Endereço BTC para saque: " . htmlspecialchars($bitcoin_address);
                }
            } else { // Para depósito, o endereço é simulado como fornecido pelo sistema
                // A 'bitcoin_address' para depósito virá do campo hidden no HTML simulado
                $method_details = "Endereço BTC para depósito: " . htmlspecialchars($bitcoin_address); // Irá capturar o valor do campo hidden
            }
        }

        // Se houver erros de validação de método, não prosseguir
        if (!empty(get_message('error'))) {
            // Re-busca os saldos para que a página exiba os valores corretos após o erro
            try {
                $stmt_balance = $pdo->prepare("SELECT vl_saldo_bitcoin, vl_saldo_real FROM tb_conta WHERE id_usuario = ?");
                $stmt_balance->execute([$user_id]);
                $account_data = $stmt_balance->fetch(PDO::FETCH_ASSOC);
                if ($account_data) {
                    $current_bitcoin_balance = $account_data['vl_saldo_bitcoin'];
                    $current_real_balance = $account_data['vl_saldo_real'];
                }
            } catch (PDOException $e) {
                error_log("Erro ao re-buscar saldos após erro de validação: " . $e->getMessage());
            }
            return; // Interrompe a execução do script para exibir o formulário com a mensagem
        }


        try {
            $pdo->beginTransaction();

            $status = 'Pendente'; // Status inicial para a maioria das operações
            $transaction_type = '';
            $message = '';
            $taxa = 0; // Por padrão, taxa zero, buscaria de tb_taxa em um sistema real

            if ($action === 'deposit') {
                $transaction_type = 'Depósito';
                if ($currency === 'BRL') {
                    $new_balance = $current_real_balance + $amount;
                    $stmt_update_balance = $pdo->prepare("UPDATE tb_conta SET vl_saldo_real = ? WHERE id_usuario = ?");
                    $stmt_update_balance->execute([$new_balance, $user_id]);
                    $message = "Depósito de R$ " . number_format($amount, 2, ',', '.') . " realizado com sucesso via " . htmlspecialchars($method) . ". " . $method_details;
                    $status = 'Concluída'; // Depósito em Reais pode ser instantâneo dependendo do método
                } elseif ($currency === 'BTC') {
                    $new_balance = $current_bitcoin_balance + $amount;
                    $stmt_update_balance = $pdo->prepare("UPDATE tb_conta SET vl_saldo_bitcoin = ? WHERE id_usuario = ?");
                    $stmt_update_balance->execute([$new_balance, $user_id]);
                    $message = "Depósito de " . number_format($amount, 8, ',', '.') . " BTC realizado com sucesso. " . $method_details;
                    $status = 'Concluída'; // Simulado como concluído
                }
            } elseif ($action === 'withdraw') {
                $transaction_type = 'Saque';
                if ($currency === 'BRL') {
                    if ($amount > $current_real_balance) {
                        set_message("Saldo em Reais insuficiente para saque.", "error");
                        $pdo->rollBack();
                    } else {
                        $new_balance = $current_real_balance - $amount;
                        $stmt_update_balance = $pdo->prepare("UPDATE tb_conta SET vl_saldo_real = ? WHERE id_usuario = ?");
                        $stmt_update_balance->execute([$new_balance, $user_id]);
                        $message = "Solicitação de saque de R$ " . number_format($amount, 2, ',', '.') . " via " . htmlspecialchars($method) . " enviada. Aguardando processamento. " . $method_details;
                        $status = 'Pendente'; // Saque geralmente é pendente
                    }
                } elseif ($currency === 'BTC') {
                    if ($amount > $current_bitcoin_balance) {
                        set_message("Saldo em Bitcoin insuficiente para saque.", "error");
                        $pdo->rollBack();
                    } else {
                        $new_balance = $current_bitcoin_balance - $amount;
                        $stmt_update_balance = $pdo->prepare("UPDATE tb_conta SET vl_saldo_bitcoin = ? WHERE id_usuario = ?");
                        $stmt_update_balance->execute([$new_balance, $user_id]);
                        $message = "Solicitação de saque de " . number_format($amount, 8, ',', '.') . " BTC enviada. Aguardando processamento. " . $method_details;
                        $status = 'Pendente'; // Saque BTC geralmente é pendente
                    }
                }
            }

            // Se não houver erro de saldo (ou outros erros de validação antes do commit), registra a transação e commita
            if (empty(get_message('error'))) {
                $stmt_log_transaction = $pdo->prepare("
                    INSERT INTO tb_transacao (tp_tipo, tp_metodo_pagamento, id_remetente, vl_quantidade_real, vl_quantidade_bitcoin, vl_taxa, ds_status, dt_transacao, ds_descricao)
                    VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), ?)
                ");
                $stmt_log_transaction->execute([
                    $transaction_type,
                    $method,
                    $user_id,
                    ($currency === 'BRL' ? $amount : 0),
                    ($currency === 'BTC' ? $amount : 0),
                    $taxa,
                    $status,
                    $method_details
                ]);
                set_message($message, "success");
                $pdo->commit();

                header("Location: " . get_base_url() . "/pages/dashboard.php");
                exit();
            } else {
                $pdo->rollBack();
            }

        } catch (PDOException $e) {
            $pdo->rollBack();
            error_log("Erro PDO na operação de depósito/saque: " . $e->getMessage());
            set_message("Ocorreu um erro na sua solicitação: " . $e->getMessage(), "error");
        }
    }
    // Após o POST, busca novamente os saldos para exibir no formulário caso haja um erro e a página recarregue
    try {
        $stmt_balance = $pdo->prepare("SELECT vl_saldo_bitcoin, vl_saldo_real FROM tb_conta WHERE id_usuario = ?");
        $stmt_balance->execute([$user_id]);
        $account_data = $stmt_balance->fetch(PDO::FETCH_ASSOC);
        if ($account_data) {
            $current_bitcoin_balance = $account_data['vl_saldo_bitcoin'];
            $current_real_balance = $account_data['vl_saldo_real'];
        }
    } catch (PDOException $e) {
        error_log("Erro ao re-buscar saldos após POST: " . $e->getMessage());
    }
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Depositar/Sacar - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .deposit-withdraw-form-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }
        .deposit-withdraw-form-grid label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: var(--text-color);
        }
        .deposit-withdraw-form-grid input[type="text"],
        .deposit-withdraw-form-grid input[type="number"],
        .deposit-withdraw-form-grid select {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-size: 1em;
            box-sizing: border-box;
        }
        .current-balances {
            background-color: var(--light-gray);
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            text-align: center;
            font-size: 1.1em;
            color: var(--text-color);
        }
        .current-balances strong {
            color: var(--primary-dark-color);
        }

        /* Estilos para ocultar/mostrar seções */
        .form-section {
            display: none;
            border: 1px solid var(--border-color);
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        .form-section.active {
            display: block;
        }

        .tab-buttons {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-bottom: 30px;
        }
        .tab-buttons .button {
            background-color: #eee;
            color: var(--primary-dark-color);
            border: 1px solid var(--border-color);
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease, color 0.3s ease;
        }
        .tab-buttons .button.active {
            background-color: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
            box-shadow: 0 3px 8px rgba(var(--primary-color-rgb), 0.2);
        }
        .tab-buttons .button:hover:not(.active) {
            background-color: #ddd;
        }

        /* Estilos para mensagens (alerta) */
        .alert {
            padding: 12px 20px;
            margin-bottom: 20px;
            border-radius: 10px;
            text-align: left;
            font-weight: 500;
            font-size: 0.9em;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .alert.error {
            background-color: #ffe6e6;
            color: #cc0000;
            border: 1px solid #ffcccc;
        }
        .alert.success {
            background-color: #e6ffe6;
            color: #008000;
            border: 1px solid #ccffcc;
        }
        .alert.info {
            background-color: #e6f7ff;
            color: #0066cc;
            border: 1px solid #cceeff;
        }

        .method-details {
            margin-top: 15px;
            padding: 15px;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            background-color: #f9f9f9;
            display: none; /* Inicia oculto */
        }
        .method-details label {
            font-weight: normal; /* Labels dentro do detalhes um pouco menos bold */
        }
        .method-details input, .method-details select, .method-details button {
            margin-bottom: 10px;
        }
        .method-details button { /* Estilo para o botão Copiar Endereço */
            background-color: #007bff; /* Azul */
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.9em;
            transition: background-color 0.2s ease;
        }
        .method-details button:hover {
            background-color: #0056b3;
        }


        @media (min-width: 600px) {
            .deposit-withdraw-form-grid {
                grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            }
        }
        @media (max-width: 768px) {
            .current-balances {
                font-size: 1em;
                padding: 10px 15px;
            }
            .tab-buttons {
                flex-wrap: wrap;
                gap: 10px;
            }
            .tab-buttons .button {
                width: 48%; /* Duas colunas */
                font-size: 0.9em;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Bank Lopes</div>
            <nav>
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li>Olá, <?= $userName ?></li>
                    <li><a href="logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="form-container">
            <h2>Depositar / Sacar</h2>
            <?php display_messages(); ?>

            <div class="current-balances">
                Saldo em Reais: <strong>R$ <?= htmlspecialchars(number_format($current_real_balance, 2, ',', '.')) ?></strong><br>
                Saldo em Bitcoin: <strong><?= htmlspecialchars(number_format($current_bitcoin_balance, 8, ',', '.')) ?> BTC</strong>
            </div>

            <div class="tab-buttons">
                <button type="button" class="button active" onclick="showSection('deposit-form', this)">Depositar</button>
                <button type="button" class="button" onclick="showSection('withdraw-form', this)">Sacar</button>
            </div>

            <!-- Formulário de Depósito -->
            <div id="deposit-form" class="form-section active">
                <h3>Novo Depósito</h3>
                <form action="deposit_withdraw.php" method="POST">
                    <input type="hidden" name="action" value="deposit">
                    <div class="deposit-withdraw-form-grid">
                        <div>
                            <label for="deposit_currency">Moeda:</label>
                            <select id="deposit_currency" name="currency" required onchange="updateDepositMethods(this.value)">
                                <option value="">Selecione a Moeda</option>
                                <option value="BRL">Reais (BRL)</option>
                                <option value="BTC">Bitcoin (BTC)</option>
                            </select>
                        </div>
                        <div>
                            <label for="deposit_amount">Quantidade:</label>
                            <input type="number" step="0.01" id="deposit_amount" name="amount" placeholder="Valor a depositar" required min="0.01">
                        </div>
                        <div>
                            <label for="deposit_method">Método de Depósito:</label>
                            <select id="deposit_method" name="method" required onchange="showMethodDetails('deposit')">
                                <option value="">Selecione o Método</option>
                                <!-- Opções serão carregadas por JS -->
                            </select>
                        </div>
                    </div>

                    <!-- Detalhes do Método de Depósito (dinâmicos) -->
                    <div id="deposit_method_details" class="method-details">
                        <!-- Conteúdo será injetado por JavaScript -->
                    </div>

                    <button type="submit" class="button primary">Confirmar Depósito</button>
                </form>
            </div>

            <!-- Formulário de Saque -->
            <div id="withdraw-form" class="form-section">
                <h3>Novo Saque</h3>
                <form action="deposit_withdraw.php" method="POST">
                    <input type="hidden" name="action" value="withdraw">
                    <div class="deposit-withdraw-form-grid">
                        <div>
                            <label for="withdraw_currency">Moeda:</label>
                            <select id="withdraw_currency" name="currency" required onchange="updateWithdrawMethods(this.value)">
                                <option value="">Selecione a Moeda</option>
                                <option value="BRL">Reais (BRL)</option>
                                <option value="BTC">Bitcoin (BTC)</option>
                            </select>
                        </div>
                        <div>
                            <label for="withdraw_amount">Quantidade:</label>
                            <input type="number" step="0.01" id="withdraw_amount" name="amount" placeholder="Valor a sacar" required min="0.01">
                        </div>
                        <div>
                            <label for="withdraw_method">Método de Saque:</label>
                            <select id="withdraw_method" name="method" required onchange="showMethodDetails('withdraw')">
                                <option value="">Selecione o Método</option>
                                <!-- Opções serão carregadas por JS -->
                            </select>
                        </div>
                    </div>

                    <!-- Detalhes do Método de Saque (dinâmicos) -->
                    <div id="withdraw_method_details" class="method-details">
                        <!-- Conteúdo será injetado por JavaScript -->
                    </div>

                    <button type="submit" class="button primary">Confirmar Saque</button>
                </form>
            </div>

            <p style="margin-top: 30px;"><a href="dashboard.php">Voltar para o Dashboard</a></p>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Inicializa as opções de método ao carregar a página
            updateDepositMethods(document.getElementById('deposit_currency').value);
            updateWithdrawMethods(document.getElementById('withdraw_currency').value);

            // Garante que a seção ativa é mostrada no carregamento
            showSection(document.querySelector('.form-section.active').id, document.querySelector('.tab-buttons .button.active'));
        });


        function showSection(sectionId, clickedButton) {
            // Esconde todas as seções de formulário
            document.querySelectorAll('.form-section').forEach(section => {
                section.classList.remove('active');
            });
            // Remove a classe 'active' de todos os botões de tab
            document.querySelectorAll('.tab-buttons .button').forEach(button => {
                button.classList.remove('active');
            });

            // Mostra a seção selecionada
            document.getElementById(sectionId).classList.add('active');

            // Ativa o botão clicado
            if (clickedButton) {
                clickedButton.classList.add('active');
            }

            // Reseta e atualiza os métodos de pagamento quando a seção muda
            if (sectionId === 'deposit-form') {
                document.getElementById('deposit_currency').value = ''; // Reseta a moeda
                updateDepositMethods(''); // Limpa os métodos
                hideMethodDetails('deposit'); // Esconde detalhes
            } else if (sectionId === 'withdraw-form') {
                document.getElementById('withdraw_currency').value = ''; // Reseta a moeda
                updateWithdrawMethods(''); // Limpa os métodos
                hideMethodDetails('withdraw'); // Esconde detalhes
            }
        }

        // Mapeamento de métodos por moeda
        const methods = {
            'BRL_deposit': [
                { value: 'PIX', text: 'PIX' },
                { value: 'TED', text: 'TED/DOC' }
                // Removido: { value: 'Cartão de Crédito', text: 'Cartão de Crédito' }
            ],
            'BRL_withdraw': [
                { value: 'PIX', text: 'PIX' },
                { value: 'TED', text: 'TED/DOC' }
            ],
            'BTC_deposit': [
                { value: 'Transferência Bitcoin', text: 'Transferência Bitcoin' }
            ],
            'BTC_withdraw': [
                { value: 'Transferência Bitcoin', text: 'Transferência Bitcoin' }
            ]
        };

        function updateDepositMethods(currency) {
            const selectMethod = document.getElementById('deposit_method');
            selectMethod.innerHTML = '<option value="">Selecione o Método</option>'; // Limpa opções anteriores
            const availableMethods = methods[currency + '_deposit'] || [];

            availableMethods.forEach(method => {
                const option = document.createElement('option');
                option.value = method.value;
                option.textContent = method.text;
                selectMethod.appendChild(option);
            });
            // Oculta os detalhes do método sempre que a moeda é alterada
            hideMethodDetails('deposit');
        }

        function updateWithdrawMethods(currency) {
            const selectMethod = document.getElementById('withdraw_method');
            selectMethod.innerHTML = '<option value="">Selecione o Método</option>'; // Limpa opções anteriores
            const availableMethods = methods[currency + '_withdraw'] || [];

            availableMethods.forEach(method => {
                const option = document.createElement('option');
                option.value = method.value;
                option.textContent = method.text;
                selectMethod.appendChild(option);
            });
            // Oculta os detalhes do método sempre que a moeda é alterada
            hideMethodDetails('withdraw');
        }

        function showMethodDetails(formType) {
            const methodSelect = document.getElementById(formType + '_method');
            const detailsDiv = document.getElementById(formType + '_method_details');
            const selectedMethod = methodSelect.value;

            detailsDiv.innerHTML = ''; // Limpa qualquer conteúdo anterior
            detailsDiv.style.display = 'none'; // Oculta por padrão

            let htmlContent = '';

            if (selectedMethod === 'PIX') {
                htmlContent = `
                    <h4>Detalhes PIX</h4>
                    <label for="${formType}_pix_key_type">Tipo de Chave PIX:</label>
                    <select id="${formType}_pix_key_type" name="pix_key_type" required>
                        <option value="">Selecione o Tipo</option>
                        <option value="CPF">CPF</option>
                        <option value="CNPJ">CNPJ</option>
                        <option value="E-mail">E-mail</option>
                        <option value="Telefone">Telefone</option>
                        <option value="Aleatória">Aleatória</option>
                    </select>
                    <label for="${formType}_pix_key">Chave PIX:</label>
                    <input type="text" id="${formType}_pix_key" name="pix_key" placeholder="Digite a chave PIX" required>
                `;
                detailsDiv.style.display = 'block';
            } else if (selectedMethod === 'TED') {
                htmlContent = `
                    <h4>Dados Bancários para TED</h4>
                    <label for="${formType}_bank_name">Nome do Banco:</label>
                    <input type="text" id="${formType}_bank_name" name="bank_name" placeholder="Ex: Banco do Brasil" required>

                    <label for="${formType}_agency_number">Agência:</label>
                    <input type="text" id="${formType}_agency_number" name="agency_number" placeholder="Ex: 1234" required>

                    <label for="${formType}_account_number">Número da Conta:</label>
                    <input type="text" id="${formType}_account_number" name="account_number" placeholder="Ex: 56789-0" required>

                    <label for="${formType}_account_type">Tipo de Conta:</label>
                    <select id="${formType}_account_type" name="account_type" required>
                        <option value="">Selecione o Tipo</option>
                        <option value="Corrente">Corrente</option>
                        <option value="Poupança">Poupança</option>
                    </select>

                    <label for="${formType}_holder_name">Nome do Titular da Conta:</label>
                    <input type="text" id="${formType}_holder_name" name="holder_name" placeholder="Nome Completo" required>

                    <label for="${formType}_holder_cpf_cnpj">CPF/CNPJ do Titular:</label>
                    <input type="text" id="${formType}_holder_cpf_cnpj" name="holder_cpf_cnpj" placeholder="CPF/CNPJ" required>
                `;
                detailsDiv.style.display = 'block';
            } else if (selectedMethod === 'Transferência Bitcoin') {
                if (formType === 'deposit') {
                    htmlContent = `
                        <h4>Endereço Bitcoin para Depósito</h4>
                        <p>Por favor, envie o valor em Bitcoin para o seguinte endereço:</p>
                        <input type="text" id="deposit_bitcoin_address_display" value="bc1qsimuladoabcd1234567890efgh (Endereço Gerado para Depósito)" readonly style="font-family: monospace; cursor: copy; margin-bottom: 5px;">
                        <button type="button" onclick="copyBitcoinAddress('deposit_bitcoin_address_display')" class="button secondary" style="margin-top: 10px;">Copiar Endereço</button>
                        <p style="font-size: 0.9em; margin-top: 10px; color: #555;">(Este é um endereço simulado para demonstração. Em um sistema real, seria um endereço único gerado para sua carteira.)</p>
                        <!-- Campo oculto para submeter algum valor para a transação. -->
                        <input type="hidden" name="bitcoin_address" value="SIMULATED_DEPOSIT_ADDRESS_XYZ">
                    `;
                } else if (formType === 'withdraw') {
                    htmlContent = `
                        <h4>Endereço Bitcoin para Saque</h4>
                        <label for="withdraw_bitcoin_address">Seu Endereço Bitcoin de Destino:</label>
                        <input type="text" id="withdraw_bitcoin_address" name="bitcoin_address" placeholder="Digite seu endereço Bitcoin (para receber)" required>
                    `;
                }
                detailsDiv.style.display = 'block';
            }

            detailsDiv.innerHTML = htmlContent;
        }

        function hideMethodDetails(formType) {
            const detailsDiv = document.getElementById(formType + '_method_details');
            detailsDiv.innerHTML = '';
            detailsDiv.style.display = 'none';
        }

        function copyBitcoinAddress(elementId) {
            const copyText = document.getElementById(elementId);
            copyText.select();
            copyText.setSelectionRange(0, 99999); /* Para dispositivos móveis */
            document.execCommand("copy");
            alert("Endereço Bitcoin copiado: " + copyText.value);
        }
    </script>
</body>
</html>
