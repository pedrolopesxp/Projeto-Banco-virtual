<?php
// www/pages/register.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

if (isset($_SESSION['user_id'])) {
    redirect('../pages/dashboard.php'); // Já logado, redireciona para o dashboard
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Correção: Usar isset() com operador ternário para compatibilidade com PHP < 7.0
    $nm_usuario = trim(isset($_POST['nm_usuario']) ? $_POST['nm_usuario'] : '');
    $ds_email = trim(isset($_POST['ds_email']) ? $_POST['ds_email'] : '');
    $ds_cpf = trim(isset($_POST['ds_cpf']) ? $_POST['ds_cpf'] : ''); // CPF deve ser preenchido
    $ds_senha = trim(isset($_POST['ds_senha']) ? $_POST['ds_senha'] : '');
    $confirm_senha = trim(isset($_POST['confirm_senha']) ? $_POST['confirm_senha'] : '');
    $dt_nascimento = trim(isset($_POST['dt_nascimento']) ? $_POST['dt_nascimento'] : '');
    $ds_telefone = trim(isset($_POST['ds_telefone']) ? $_POST['ds_telefone'] : '');
    $ds_endereco = trim(isset($_POST['ds_endereco']) ? $_POST['ds_endereco'] : '');
    $ds_cidade = trim(isset($_POST['ds_cidade']) ? $_POST['ds_cidade'] : ''); // Agora opcional
    $ds_estado = trim(isset($_POST['ds_estado']) ? $_POST['ds_estado'] : ''); // Agora opcional
    $ds_pais_origem = trim(isset($_POST['ds_pais_origem']) ? $_POST['ds_pais_origem'] : 'Brasil');

    // Validações: CPF agora é obrigatório junto com nome, email, senha e data de nascimento
    if (empty($nm_usuario) || empty($ds_email) || empty($ds_cpf) || empty($ds_senha) || empty($confirm_senha) || empty($dt_nascimento)) {
        set_message("Por favor, preencha todos os campos obrigatórios: Nome Completo, E-mail, CPF, Senha, Confirmação de Senha e Data de Nascimento.", "error");
    } elseif (!is_valid_email($ds_email)) {
        set_message("Formato de e-mail inválido.", "error");
    }
    // CPF é obrigatório e validado se não estiver vazio
    elseif (!is_valid_cpf($ds_cpf)) {
        set_message("Formato de CPF inválido. Digite apenas números (11 dígitos).", "error");
    } elseif (strlen($ds_senha) < 6) {
        set_message("A senha deve ter no mínimo 6 caracteres.", "error");
    } elseif ($ds_senha !== $confirm_senha) {
        set_message("As senhas não coincidem.", "error");
    } else {
        try {
            // Verificar se o email ou CPF já existem
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM tb_usuario WHERE ds_email = ? OR ds_cpf = ?");
            // Certifique-se de que o CPF esteja limpo antes de verificar no banco de dados
            $ds_cpf_clean = preg_replace('/[^0-9]/', '', $ds_cpf);
            $stmt->execute([$ds_email, $ds_cpf_clean]);
            if ($stmt->fetchColumn() > 0) {
                set_message("Este e-mail ou CPF já está cadastrado.", "error");
            } else {
                $ds_senha_hash = hash_password($ds_senha);

                // Iniciar transação para garantir atomicidade
                $pdo->beginTransaction();

                // Inserir novo usuário
                $stmt_user = $pdo->prepare("INSERT INTO tb_usuario (nm_usuario, ds_email, ds_cpf, ds_senha_hash, dt_nascimento, ds_telefone, ds_endereco, ds_cidade, ds_estado, ds_pais_origem) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                // Todos os campos são passados; campos opcionais podem ser vazios.
                // Passar o CPF limpo para o banco de dados
                $stmt_user->execute([$nm_usuario, $ds_email, $ds_cpf_clean, $ds_senha_hash, $dt_nascimento, $ds_telefone, $ds_endereco, $ds_cidade, $ds_estado, $ds_pais_origem]);

                $user_id = $pdo->lastInsertId();

                // Criar uma conta para o novo usuário
                $nr_conta = 'ACC' . str_pad($user_id, 8, '0', STR_PAD_LEFT); // Exemplo de número de conta
                $stmt_account = $pdo->prepare("INSERT INTO tb_conta (id_usuario, nr_conta) VALUES (?, ?)");
                $stmt_account->execute([$user_id, $nr_conta]);

                $pdo->commit(); // Confirma a transação

                set_message("Sua conta foi criada com sucesso! Faça login para começar.", "success");
                redirect('login.php');
            }
        } catch (PDOException $e) {
            $pdo->rollBack(); // Desfaz a transação em caso de erro
            error_log("Erro no registro: " . $e->getMessage());
            // Verifica se o erro é especificamente de entrada duplicada para o CPF
            if ($e->getCode() == '23000' && strpos($e->getMessage(), 'Duplicate entry') !== false && strpos($e->getMessage(), 'ds_cpf') !== false) {
                 set_message("Não foi possível criar a conta. Um usuário com o mesmo CPF já está registrado. Por favor, forneça um CPF único.", "error");
            } else {
                 set_message("Ocorreu um erro ao criar sua conta. Por favor, tente novamente mais tarde.", "error");
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Criar Conta - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Bank Lopes</div>
            <nav>
                <ul>
                    <li><a href="../index.php">Início</a></li>
                    <li><a href="../pages/login.php" class="button primary">Login</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="form-container">
            <h2>Criar Nova Conta</h2>
            <?php display_messages(); ?>
            <form action="register.php" method="POST">
                <input type="text" name="nm_usuario" placeholder="Nome Completo" required autocomplete="name" value="<?= htmlspecialchars(isset($_POST['nm_usuario']) ? $_POST['nm_usuario'] : '') ?>">
                <input type="email" name="ds_email" placeholder="E-mail" required autocomplete="email" value="<?= htmlspecialchars(isset($_POST['ds_email']) ? $_POST['ds_email'] : '') ?>">
                <!-- CPF agora aceita apenas dígitos, sem exigência de pontos/traços -->
                <input type="text" name="ds_cpf" placeholder="CPF (Apenas números - 11 dígitos)" required pattern="[0-9]{11}" title="Formato: Apenas números, 11 dígitos" autocomplete="off" value="<?= htmlspecialchars(isset($_POST['ds_cpf']) ? $_POST['ds_cpf'] : '') ?>">
                <input type="password" name="ds_senha" placeholder="Senha" required autocomplete="new-password">
                <input type="password" name="confirm_senha" placeholder="Confirmar Senha" required autocomplete="new-password">
                <input type="date" name="dt_nascimento" title="Data de Nascimento" required value="<?= htmlspecialchars(isset($_POST['dt_nascimento']) ? $_POST['dt_nascimento'] : '') ?>">
                <!-- Campos agora opcionais -->
                <input type="tel" name="ds_telefone" placeholder="Telefone (Opcional)" autocomplete="tel" value="<?= htmlspecialchars(isset($_POST['ds_telefone']) ? $_POST['ds_telefone'] : '') ?>">
                <input type="text" name="ds_endereco" placeholder="Endereço Completo (Opcional)" autocomplete="street-address" value="<?= htmlspecialchars(isset($_POST['ds_endereco']) ? $_POST['ds_endereco'] : '') ?>">
                <input type="text" name="ds_cidade" placeholder="Cidade (Opcional)" autocomplete="address-level2" value="<?= htmlspecialchars(isset($_POST['ds_cidade']) ? $_POST['ds_cidade'] : '') ?>">
                <input type="text" name="ds_estado" placeholder="Estado (Opcional - Ex: SP)" autocomplete="address-level1" value="<?= htmlspecialchars(isset($_POST['ds_estado']) ? $_POST['ds_estado'] : '') ?>">
                <input type="text" name="ds_pais_origem" placeholder="País de Origem (Opcional - Ex: Brasil)" value="<?= htmlspecialchars(isset($_POST['ds_pais_origem']) ? $_POST['ds_pais_origem'] : 'Brasil') ?>">
                <button type="submit" class="button primary">Criar Conta</button>
                <p>Já tem uma conta? <a href="login.php">Faça Login</a></p>
            </form>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>
</body>
</html>
