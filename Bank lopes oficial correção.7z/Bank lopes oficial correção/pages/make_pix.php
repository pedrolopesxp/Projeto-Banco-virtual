<?php
// www/pages/make_pix.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

// Verifica se o usuário está logado.
if (!isset($_SESSION['user_id'])) {
    set_message("Você precisa estar logado para fazer um PIX.", "error");
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$userName = htmlspecialchars($_SESSION['user_name'] ?? 'Usuário');

// Lógica para obter o saldo atual do usuário em Reais
$current_real_balance = 0;
try {
    $stmt_balance = $pdo->prepare("SELECT vl_saldo_real FROM tb_conta WHERE id_usuario = ?");
    $stmt_balance->execute([$user_id]);
    $account_data = $stmt_balance->fetch(PDO::FETCH_ASSOC);
    if ($account_data) {
        $current_real_balance = $account_data['vl_saldo_real'];
    }
} catch (PDOException $e) {
    error_log("Erro ao buscar saldo BRL para PIX: " . $e->getMessage());
    set_message("Erro ao carregar seu saldo em Reais. Tente novamente.", "error");
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pix_key_type = trim(isset($_POST['pix_key_type']) ? $_POST['pix_key_type'] : '');
    $pix_key = trim(isset($_POST['pix_key']) ? $_POST['pix_key'] : '');
    $amount_brl = floatval(str_replace(',', '.', trim(isset($_POST['amount_brl']) ? $_POST['amount_brl'] : '0')));
    $description = trim(isset($_POST['description']) ? $_POST['description'] : '');

    if (empty($pix_key_type) || empty($pix_key) || $amount_brl <= 0) {
        set_message("Por favor, preencha o tipo de chave, a chave PIX e a quantidade.", "error");
    } elseif ($amount_brl > $current_real_balance) {
        set_message("Saldo em Reais insuficiente para o PIX.", "error");
    } else {
        try {
            $pdo->beginTransaction();

            // Simulação de uma taxa de PIX (se aplicável, buscaria de tb_taxa)
            $pix_fee = 0; // PIX geralmente não tem taxa para PJ
            // Em um sistema real, aqui haveria uma integração com um PSP (Payment Service Provider)
            // para validar a chave, enviar o PIX e receber um retorno.

            // Atualizar saldo da conta do remetente
            $new_balance = $current_real_balance - ($amount_brl + $pix_fee);
            $stmt_update_sender = $pdo->prepare("UPDATE tb_conta SET vl_saldo_real = ? WHERE id_usuario = ?");
            $stmt_update_sender->execute([$new_balance, $user_id]);

            // Registrar transação na tb_transacao
            $stmt_log_transaction = $pdo->prepare("
                INSERT INTO tb_transacao (tp_tipo, tp_metodo_pagamento, id_remetente, vl_quantidade_real, vl_taxa, ds_status, ds_descricao)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt_log_transaction->execute([
                'PIX Enviado',
                'PIX',
                $user_id,
                $amount_brl,
                $pix_fee,
                'Concluída', // Em um ambiente real, seria 'Processando'
                "PIX para chave " . $pix_key . " (" . $pix_key_type . ")" . (empty($description) ? "" : " - " . $description)
            ]);

            set_message("PIX de R$ " . number_format($amount_brl, 2, ',', '.') . " enviado com sucesso para a chave " . htmlspecialchars($pix_key) . "!", "success");
            $pdo->commit();
            redirect('dashboard.php'); // Redireciona para o dashboard após sucesso

        } catch (PDOException $e) {
            $pdo->rollBack();
            error_log("Erro ao fazer PIX: " . $e->getMessage());
            set_message("Ocorreu um erro ao fazer o PIX: " . $e->getMessage(), "error");
        }
    }
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fazer PIX - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Bank Lopes</div>
            <nav>
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li>Olá, <?= $userName ?></li>
                    <li><a href="logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="form-container">
            <h2>Fazer PIX</h2>
            <?php display_messages(); ?>
            <p>Seu saldo atual: <strong>R$ <?= htmlspecialchars(number_format($current_real_balance, 2, ',', '.')) ?></strong></p>

            <form action="make_pix.php" method="POST">
                <div class="form-group">
                    <label for="pix_key_type">Tipo de Chave PIX:</label>
                    <select id="pix_key_type" name="pix_key_type" required>
                        <option value="">Selecione o tipo de chave</option>
                        <option value="CPF">CPF</option>
                        <option value="CNPJ">CNPJ</option>
                        <option value="E-mail">E-mail</option>
                        <option value="Telefone">Telefone</option>
                        <option value="Aleatória">Chave Aleatória</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="pix_key">Chave PIX:</label>
                    <input type="text" id="pix_key" name="pix_key" placeholder="Digite a chave PIX" required>
                </div>
                <div class="form-group">
                    <label for="amount_brl">Quantidade (R$):</label>
                    <input type="number" step="0.01" id="amount_brl" name="amount_brl" placeholder="Ex: 50.00" required min="0.01">
                </div>
                <div class="form-group">
                    <label for="description">Descrição (Opcional):</label>
                    <input type="text" id="description" name="description" placeholder="Uma breve descrição da transação">
                </div>
                <button type="submit" class="button primary">Confirmar PIX</button>
            </form>
            <p><a href="dashboard.php">Voltar para o Dashboard</a></p>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>
</body>
</html>
